package com.epam.training_portal.hooks;

public class  RestAssuredHooks {
}
