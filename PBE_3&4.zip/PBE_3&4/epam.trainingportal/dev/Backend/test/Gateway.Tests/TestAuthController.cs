﻿using System.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.TestHost;
using Microsoft.AspNetCore.Mvc.Testing;

namespace Gateway.Tests
{
    [TestClass]
    public sealed class TestAuthController
    {
        private HttpClient _client;

        [TestInitialize]
        public void Init()
        {
            var factory = new WebApplicationFactory<Program>();
            _client = factory.CreateClient();
        }

        [TestMethod]
        public async Task Should_Return_401_Without_Token()
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "/Auth");

            var response = await _client.SendAsync(request);

            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
        }

        [TestCleanup]
        public void Cleanup()
        {
            _client?.Dispose();
        }
    }
}
