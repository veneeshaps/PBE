using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("[controller]")]
[Authorize]
public class AuthController : ControllerBase
{
    [HttpGet]
    public IActionResult GetUserInfo()
    {
        var userName = User.Identity?.Name;
        var claims = User.Claims.Select(c => new { c.Type, c.Value });

        return Ok(new
        {
            UserName = userName,
            Claims = claims
        });
    }

    [HttpGet("admin")]
    [Authorize(Roles = "Admin")]
    public IActionResult AdminEndpoint()
    {
        return Ok("This is an admin-only endpoint");
    }

    [HttpGet("user-groups")]
    public IActionResult GetUserGroups()
    {
        var groups = User.Claims
            .Where(c => c.Type == "groups")
            .Select(c => c.Value)
            .ToList();

        return Ok(groups);
    }

    [HttpGet("Debug")]
    public IActionResult DebugToken()
    {
        var scopes = User.Claims
            .Where(c => c.Type == "scp")
            .Select(c => c.Value);

        return Ok(new { scopes });
    }
}