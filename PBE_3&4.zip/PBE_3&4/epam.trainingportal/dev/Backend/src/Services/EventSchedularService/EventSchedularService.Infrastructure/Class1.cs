﻿namespace EventSchedularService.Infrastructure
{
    public class Class1
    {

    }
}
