﻿
namespace EventSchedularService.Domain
{
    public class Class1
    {

    }
}
