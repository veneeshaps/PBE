﻿namespace EventSchedularService.Application
{
    public class Class1
    {

    }
}
