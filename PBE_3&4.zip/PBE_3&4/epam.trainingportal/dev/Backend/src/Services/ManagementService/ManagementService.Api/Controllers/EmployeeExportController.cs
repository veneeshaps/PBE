﻿using ManagementService.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ManagementService.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeExportController : ControllerBase
    {
        private readonly IEmployeeExportService _employeeExportService;

        public EmployeeExportController(IEmployeeExportService employeeExportService)
        {
            _employeeExportService = employeeExportService;
        }

        [HttpGet("export")]
        public async Task<IActionResult> ExportEmployees()
        {
            var fileContents = await _employeeExportService.ExportEmployeesToExcelAsync();

            if (fileContents == null || fileContents.Length == 0)
            {
                return StatusCode(500, "Exporting employees failed. Please try again.");
            }

            return File(fileContents,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                $"EmployeeData_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx");
        }
    }
}
