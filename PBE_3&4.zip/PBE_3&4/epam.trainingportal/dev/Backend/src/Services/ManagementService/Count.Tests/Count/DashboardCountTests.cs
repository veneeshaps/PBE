﻿using ManagementService.Application.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;

namespace ManagementService.Tests.Count
{
    [TestClass]
    public class DashboardCountTests
    {
        private Mock<IDashboardRepository> _mockRepo;

        [TestInitialize]
        public void Setup()
        {
            _mockRepo = new Mock<IDashboardRepository>();
        }

        [TestMethod]
        public async Task CountActiveUsersAsync_ReturnsExpectedCount()
        {
            // Arrange
            _mockRepo.Setup(repo => repo.CountActiveUsersAsync()).ReturnsAsync(5);

            // Act
            var result = await _mockRepo.Object.CountActiveUsersAsync();

            // Assert
            Assert.AreEqual(5, result);
        }

        [TestMethod]
        public async Task CountActiveEventsAsync_ReturnsExpectedCount()
        {
            // Arrange
            _mockRepo.Setup(repo => repo.CountActiveEventsAsync()).ReturnsAsync(3);

            // Act
            var result = await _mockRepo.Object.CountActiveEventsAsync();

            // Assert
            Assert.AreEqual(3, result);
        }
    }
}
