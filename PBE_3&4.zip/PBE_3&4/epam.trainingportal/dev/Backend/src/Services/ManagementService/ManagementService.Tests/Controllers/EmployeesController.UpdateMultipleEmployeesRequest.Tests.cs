﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ManagementService.Api.Controllers;
using ManagementService.Application.DTOs;
using ManagementService.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

namespace ManagementService.Tests.Controllers {
    [TestClass]
    public class EmployeesControllerMultipleUpdateTests {
        private Mock<IEmployeeService>? _mockEmployeeService = null!;
        private EmployeesController? _controller = null!;

        [TestInitialize]
        public void Setup() {
            _mockEmployeeService = new Mock<IEmployeeService>();
            _controller = new EmployeesController(_mockEmployeeService.Object);
        }

        [TestMethod]
        public async Task EditMultiple_ReturnsOk_WhenUpdateIsSuccessful() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
                    new EmployeeIdentifier { EmployeeId = 1, Email = "test1@example.com" },
                    new EmployeeIdentifier { EmployeeId = 2, Email = "test2@example.com" }
                ],
                Role = "2",
                Domain = "3",
                Status = "1"
            };

            var serviceResponse = new UpdateMultipleEmployeesResponse {
                Success = true,
                Message = "Fields Updated Successfully."
            };

            _mockEmployeeService?.Setup(s => s.UpdateMultipleEmployeesAsync(request))
                                .ReturnsAsync(serviceResponse);

            // Act
            var result = await _controller!.EditMultiple(request) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);

            var apiResponse = result.Value as ApiResponse<object>;
            Assert.IsTrue(apiResponse?.Success);
            Assert.AreEqual(serviceResponse.Message, apiResponse?.Message);
        }

        [TestMethod]
        public async Task EditMultiple_ReturnsBadRequest_WhenInputsAreInvalid() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
                    new() { EmployeeId = 1, Email = "test1@example.com" }
                ],
                Role = "invalid",
                Domain = "3",
                Status = "1"
            };

            var serviceResponse = new UpdateMultipleEmployeesResponse {
                Success = false,
                Message = "Invalid Inputs",
                Errors = [
                    new ErrorDto { Code = "InvalidRoleId", Message = "Invalid Role value: invalid", Field = "Role" }
                ]
            };

            _mockEmployeeService?.Setup(s => s.UpdateMultipleEmployeesAsync(request))
                                .ReturnsAsync(serviceResponse);

            // Act
            var result = await _controller!.EditMultiple(request) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(400, result.StatusCode);

            var apiResponse = result.Value as ApiResponse<object>;
            Assert.IsFalse(apiResponse?.Success);
            Assert.AreEqual(serviceResponse.Message, apiResponse?.Message);
            Assert.IsNotNull(apiResponse?.Errors);
            Assert.AreEqual("InvalidRoleId", apiResponse?.Errors[0].Code);
        }

        [TestMethod]
        public async Task EditMultiple_ReturnsInternalServerError_WhenExceptionIsThrown() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
                    new EmployeeIdentifier { EmployeeId = 1, Email = "test@example.com" }
                ],
                Status = "1"
            };

            _mockEmployeeService?.Setup(s => s.UpdateMultipleEmployeesAsync(request))
                                .ThrowsAsync(new Exception("Unexpected error"));

            // Act
            var result = await _controller!.EditMultiple(request) as ObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(500, result.StatusCode);

            var apiResponse = result.Value as ApiResponse<object>;
            Assert.IsFalse(apiResponse?.Success);
            Assert.AreEqual("Something went wrong. Try again later.", apiResponse?.Message);
            Assert.IsNotNull(apiResponse?.Errors);
            Assert.AreEqual("ServerError", apiResponse.Errors[0].Code);
        }

        [TestMethod]
        public async Task EditMultiple_ReturnsOkWithPartialErrors_WhenSomeUpdatesFail() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
            new EmployeeIdentifier { EmployeeId = 1, Email = "test1@example.com" },
            new EmployeeIdentifier { EmployeeId = 999, Email = "notfound@example.com" }
        ],
                Role = "2"
            };

            var serviceResponse = new UpdateMultipleEmployeesResponse {
                Success = true,
                Message = "Role Changed to Bench Successfully.",
                Errors = [
            new() {
                Code = "EmployeeNotFound",
                Message = "Employee with ID 999 and Email notfound@example.com not found.",
                Field = "Employee"
            }
        ]
            };

            _mockEmployeeService?.Setup(s => s.UpdateMultipleEmployeesAsync(request))
                                .ReturnsAsync(serviceResponse);

            // Act
            var result = await _controller!.EditMultiple(request) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);

            var apiResponse = result.Value as ApiResponse<object>;
            Assert.IsNotNull(apiResponse);
            Assert.IsTrue(apiResponse.Success);
            Assert.AreEqual(serviceResponse.Message, apiResponse.Message);

            // Check that errors are properly propagated
            Assert.IsNotNull(apiResponse.Errors);
            Assert.AreEqual(1, apiResponse.Errors.Count);
            Assert.AreEqual("EmployeeNotFound", apiResponse.Errors[0].Code);
            Assert.AreEqual("Employee with ID 999 and Email notfound@example.com not found.", apiResponse.Errors[0].Message);
        }
    }
}