﻿using ManagementService.Application.DTOs;
using ManagementService.Application.Interfaces;
using Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ManagementService.Infrastructure.Helpers;

namespace ManagementService.Application.Services {
    public class EmployeeService : IEmployeeService {

        private readonly ApplicationDbContext _context;
        private readonly IEmployeeRepository _repository;

        public EmployeeService(IEmployeeRepository repository, ApplicationDbContext context)
        {
            _context = context;
            _repository = repository;

        }

        public async Task<UpdateEmployeeFieldResponse> UpdateEmployeeFieldAsync(UpdateEmployeeFieldRequest request) {
            var email = request.Email?.Trim();
            var field = request.FieldToUpdate?.Trim().ToLower();
            var value = request.NewValue?.Trim();

            var employee = await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == request.EmployeeId && e.Email == email);
            if (employee == null) {
                return InvalidResponse("EmployeeNotFound", $"Employee not found.");
            }

            switch (field) {
                case "domain":
                    if (!int.TryParse(value, out int domainId)) {
                        return InvalidResponse("InvalidDomainId", $"Invalid Domain");
                    }
                    if (employee.DomainId == domainId) {
                        return AlreadyUpdatedResponse("DomainAlreadyUpdated", $"Employee's domain is already set to {await GetDomainName(domainId)}.");
                    }
                    var domain = await _context.Domains.FirstOrDefaultAsync(d => d.DomainId == domainId);
                    if (domain == null) {
                        return InvalidResponse("DomainNotFound", $"Domain does not exist.");
                    }
                    employee.DomainId = domainId;
                    break;

                case "role":
                    if (!int.TryParse(value, out int roleId)) {
                        return InvalidResponse("InvalidRoleId", $"Invalid Role");
                    }
                    if (employee.RoleId == roleId) {
                        return AlreadyUpdatedResponse("RoleAlreadyUpdated", $"Employee's role is already set to {await GetRoleName(roleId)}.");
                    }
                    var role = await _context.Roles.FirstOrDefaultAsync(r => r.RoleId == roleId);
                    if (role == null) {
                        return InvalidResponse("RoleNotFound", $"Role does not exist.");
                    }
                    employee.RoleId = roleId;
                    break;

                case "status":
                    if (!(value == "0" || value == "1")) {
                        return InvalidResponse("InvalidStatus", $"Status must be Active or Deactive.");
                    }
                    bool newStatus = value == "1";
                    if (employee.IsDeactivated == newStatus) {
                        return AlreadyUpdatedResponse("StatusAlreadyUpdated", $"Employee's status is already set to {(newStatus ? "Deactivated" : "Active")}.");
                    }
                    employee.IsDeactivated = newStatus;
                    break;

                default:
                    return InvalidResponse("InvalidField", $"Invalid field '{field}' to update.");
            }

            employee.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            string message = field switch {
                "domain" => $"Domain updated to {await GetDomainName(employee.DomainId)} successfully.",
                "role" => $"Role updated to {await GetRoleName(employee.RoleId)} successfully.",
                "status" => $"Status updated to {(employee.IsDeactivated ? "Deactivated" : "Active")} successfully.",
                _ => $"{field} updated successfully."
            };

            return new UpdateEmployeeFieldResponse {
                Success = true,
                Message = message
            };
        }

        public async Task<UpdateMultipleEmployeesResponse> UpdateMultipleEmployeesAsync(UpdateMultipleEmployeesRequest request) {
            var errors = new List<ErrorDto>();
            int updateCount = 0;

            // Trim and validate inputs before processing
            string? trimmedRole = request.Role?.Trim();
            string? trimmedDomain = request.Domain?.Trim();
            string? trimmedStatus = request.Status?.Trim();

            int? roleId = null;
            int? domainId = null;
            bool? newStatus = null;

            if (!string.IsNullOrWhiteSpace(trimmedRole)) {
                if (!int.TryParse(trimmedRole, out int rId)) {
                    errors.Add(new ErrorDto {
                        Code = "InvalidRoleId",
                        Message = $"Invalid Role value: {trimmedRole}",
                        Field = "Role"
                    });
                }
                else {
                    var roleExists = await _context.Roles.AnyAsync(r => r.RoleId == rId);
                    if (!roleExists) {
                        errors.Add(new ErrorDto {
                            Code = "RoleNotFound",
                            Message = $"Role with ID {rId} does not exist.",
                            Field = "Role"
                        });
                    }
                    else {
                        roleId = rId;
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(trimmedDomain)) {
                if (!int.TryParse(trimmedDomain, out int dId)) {
                    errors.Add(new ErrorDto {
                        Code = "InvalidDomainId",
                        Message = $"Invalid Domain value: {trimmedDomain}",
                        Field = "Domain"
                    });
                }
                else {
                    var domainExists = await _context.Domains.AnyAsync(d => d.DomainId == dId);
                    if (!domainExists) {
                        errors.Add(new ErrorDto {
                            Code = "DomainNotFound",
                            Message = $"Domain with ID {dId} does not exist.",
                            Field = "Domain"
                        });
                    }
                    else {
                        domainId = dId;
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(trimmedStatus)) {
                if (!(trimmedStatus == "0" || trimmedStatus == "1")) {
                    errors.Add(new ErrorDto {
                        Code = "InvalidStatus",
                        Message = "Status must be 0 for Active or 1 for Deactive.",
                        Field = "Status"
                    });
                }
                else {
                    newStatus = trimmedStatus == "1";
                }
            }

            if (errors.Count > 0) {
                return new UpdateMultipleEmployeesResponse {
                    Success = false,
                    Message = "Invalid Inputs",
                    Errors = errors
                };
            }

            foreach (var identifier in request.Employees) {
                var email = identifier.Email?.Trim();
                var employee = await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == identifier.EmployeeId && e.Email == email);
                if (employee == null) {
                    errors.Add(new ErrorDto {
                        Code = "EmployeeNotFound",
                        Message = $"Employee with ID {identifier.EmployeeId} and Email {email} not found.",
                        Field = "Employee"
                    });
                    continue;
                }

                if (roleId.HasValue && employee.RoleId != roleId.Value) {
                    employee.RoleId = roleId.Value;
                }

                if (domainId.HasValue && employee.DomainId != domainId.Value) {
                    employee.DomainId = domainId.Value;
                }

                if (newStatus.HasValue && employee.IsDeactivated != newStatus.Value) {
                    employee.IsDeactivated = newStatus.Value;
                }

                employee.UpdatedAt = DateTime.UtcNow;
                updateCount++;
            }

            await _context.SaveChangesAsync();

            bool overallSuccess = errors.Count == 0;
            string message;

            if (!overallSuccess && updateCount == 0) {
                return new UpdateMultipleEmployeesResponse {
                    Success = false,
                    Message = "Invalid Inputs",
                    Errors = errors
                };
            }

            if (roleId.HasValue && !domainId.HasValue && !newStatus.HasValue)
                message = $"Role Changed to {(await GetRoleName(roleId.Value))} Successfully.";
            else if (!roleId.HasValue && domainId.HasValue && !newStatus.HasValue)
                message = $"Domain Changed to {(await GetDomainName(domainId.Value))} Successfully.";
            else if (!roleId.HasValue && !domainId.HasValue && newStatus.HasValue)
                message = $"Status Changed to {(newStatus.Value ? "Deactive" : "Active")} Successfully.";
            else
                message = "Fields Updated Successfully.";

            return new UpdateMultipleEmployeesResponse {
                Success = true,
                Message = message,
                Errors = errors.Count > 0 ? errors : null
            };
        }

        private async Task<string> GetDomainName(int domainId) {
            return (await _context.Domains.FirstOrDefaultAsync(d => d.DomainId == domainId))?.Name ?? "Unknown";
        }

        private async Task<string> GetRoleName(int roleId) {
            return (await _context.Roles.FirstOrDefaultAsync(r => r.RoleId == roleId))?.Name ?? "Unknown";
        }

        private static UpdateEmployeeFieldResponse InvalidResponse(string code, string message) {
            return new UpdateEmployeeFieldResponse {
                Success = false,
                Message = message,
                Errors = [
                    new() {
                        Code = code,
                        Message = message
                    }
                ]
            };
        }

        private static UpdateEmployeeFieldResponse AlreadyUpdatedResponse(string code, string message) {
            return new UpdateEmployeeFieldResponse {
                Success = true,
                Message = message,
                Errors = [
                    new() {
                        Code = code,
                        Message = message
                    }
                ]
            };
        }

        public async Task<List<GetEmployeesRequest>> GetAllEmployeesAsync() {
            return await _context.Employees
                .Include(e => e.Domain)
                .Include(e => e.Role)
                .Select(e => new GetEmployeesRequest {
                    EmployeeId = e.EmployeeId,
                    Name = e.FirstName + " " + e.LastName,
                    Email = e!.Email,
                    Domain = new DomainDto {
                        DomainId = e.DomainId,
                        Name = e!.Domain!.Name
                    },
                    Role = new RoleDto {
                        RoleId = e.RoleId,
                        Name = e!.Role!.Name
                    },
                    IsDeactivated = e.IsDeactivated ? 1 : 0
                })
                .ToListAsync();
        }

        public async Task<(bool success, string message)> AddEmployeeAsync(Employee employee)
        {
            if (string.IsNullOrWhiteSpace(employee.Email) || !employee.Email.EndsWith("@epam.com"))
            {
                return (false, "Invalid email. Must be a non-empty email ending with '@epam.com'.");
            }

            bool emailExists = await _context.Employees.AnyAsync(e => e.Email == employee.Email);
            if (emailExists)
            {
                return (false, $"Email '{employee.Email}' already exists in the database.");
            }

            //bool empIdExists = await _context.Employees.AnyAsync(e => e.EmployeeId == employee.EmployeeId);
            //if (empIdExists)
            //{
            //    return (false, $"Employee ID '{employee.EmployeeId}' already exists in the database.");
            //}

            var domain = await _context.Domains
                .Where(d => d.DomainId == employee.DomainId)
                .Select(d => d.DomainId)
                .FirstOrDefaultAsync();

            if (domain == 0)
            {
                return (false, $"Invalid DomainId: {employee.DomainId}. No matching domain found.");
            }

            var role = await _context.Roles
                .Where(r => r.RoleId == employee.RoleId)
                .Select(r => r.RoleId)
                .FirstOrDefaultAsync();

            if (role == 0)
            {
                return (false, $"Invalid RoleId: {employee.RoleId}. No matching role found.");
            }

            employee.DomainId = domain;
            employee.RoleId = role;

            try
            {
                _context.Employees.Add(employee);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return (false, $"Failed to save employee to the database. Error: {ex.Message}");
            }

            try
            {
                ExcelHelper.WriteEmployeeToExcel(employee);
            }
            catch (Exception)
            {
                return (true, "Employee saved to database, but failed to write to Excel.");
            }

            return (true, "Employee added to database and Excel successfully.");
        }

        // ✅ Modified to return only required fields using DTOs
        public async Task<List<DomainDto>> GetAllDomainsAsync()
        {

            var domains =  await _context.Domains
                .Select(d => new DomainDto
                {
                    DomainId = d.DomainId,
                    Name = d.Name
                })
                .ToListAsync();

            return domains;
        }

        public async Task<MasterDataRequest> GetMasterDataAsync() {
            var domains = await _context.Domains
                .Select(d => new DomainDto {
                    DomainId = d.DomainId,
                    Name = d.Name
                })
                .ToListAsync();

            var roles = await _context.Roles
                .Select(r => new RoleDto {
                    RoleId = r.RoleId,
                    Name = r.Name
                })
                .ToListAsync();

            return new MasterDataRequest {
                Domains = domains,
                Roles = roles
            };
        }


        public async Task<List<RoleDto>> GetAllRolesAsync()
        {
            return await _context.Roles
                .Select(r => new RoleDto
                {
                    RoleId = r.RoleId,
                    Name = r.Name
                })
                .ToListAsync();
        }

        public async Task<IEnumerable<EmployeeDto>> SearchEmployeesAsync(string name)
        {
            var employees = await _repository.SearchEmployeesByNameAsync(name);

            return employees.Select(e => new EmployeeDto
            {
                FullName = $"{e.FirstName} {e.LastName}",
                Email = e.Email,
                Role = e.Role?.Name,
                Domain = e.Domain?.Name,
                Status = e.IsDeactivated ? "Inactive" : "Active"
            });
        }
    }
}
