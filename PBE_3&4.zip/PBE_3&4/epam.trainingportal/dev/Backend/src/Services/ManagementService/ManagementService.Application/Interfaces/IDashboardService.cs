﻿namespace ManagementService.Application.Interfaces
{
    public interface IDashboardService
    {
        Task<int> GetTotalUsersAsync();
        Task<int> GetTotalActiveEventsAsync();
    }
}
