﻿using ManagementService.Application.DTOs;
using ManagementService.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ManagementService.Api.Controllers {
    [Route("api/v1/[controller]")]
    [ApiController]
    public class EmployeesController(IEmployeeService employeeService) : ControllerBase {
        private readonly IEmployeeService _employeeService = employeeService;

        [HttpPatch("edit")]
        public async Task<IActionResult> EditField([FromBody] UpdateEmployeeFieldRequest request) {
            try {
                var response = await _employeeService.UpdateEmployeeFieldAsync(request);

                if (!response.Success) {
                    return BadRequest(new ApiResponse<object> {
                        Success = false,
                        StatusCode = 400,
                        Message = response.Message,
                        Errors = response.Errors,
                        Timestamp = DateTime.UtcNow.ToString("O")
                    });
                }

                return Ok(new ApiResponse<object> {
                    Success = true,
                    StatusCode = 200,
                    Message = response.Message,
                    Timestamp = DateTime.UtcNow.ToString("O")
                });
            }
            catch {
                return StatusCode(500, new ApiResponse<object> {
                    Success = false,
                    StatusCode = 500,
                    Message = "Something went wrong. Try again later.",
                    Errors = [
                        new ErrorDto {
                            Code = "ServerError",
                            Message = "Something went wrong. Try again later."
                        }
                    ],
                    Timestamp = DateTime.UtcNow.ToString("O")
                });
            }
        }

        [HttpPatch("edit-multiple")]
        public async Task<IActionResult> EditMultiple([FromBody] UpdateMultipleEmployeesRequest request) {
            try {
                var response = await _employeeService.UpdateMultipleEmployeesAsync(request);

                if (!response.Success) {
                    return BadRequest(new ApiResponse<object> {
                        Success = false,
                        StatusCode = 400,
                        Message = response.Message,
                        Errors = response.Errors,
                        Timestamp = DateTime.UtcNow.ToString("O")
                    });
                }

                return Ok(new ApiResponse<object> {
                    Success = true,
                    StatusCode = 200,
                    Message = response.Message,
                    Errors = response.Errors,
                    Timestamp = DateTime.UtcNow.ToString("O")
                });
            }
            catch {
                return StatusCode(500, new ApiResponse<object> {
                    Success = false,
                    StatusCode = 500,
                    Message = "Something went wrong. Try again later.",
                    Errors = [
                        new ErrorDto {
                            Code = "ServerError",
                            Message = "Something went wrong. Try again later."
                        }
                    ],
                    Timestamp = DateTime.UtcNow.ToString("O")
                });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllEmployees() {
            try {
                var employees = await _employeeService.GetAllEmployeesAsync();
                return Ok(new ApiResponse<List<GetEmployeesRequest>> {
                    Success = true,
                    StatusCode = 200,
                    Message = "Employees fetched successfully.",
                    Data = employees,
                    Timestamp = DateTime.UtcNow.ToString("O")
                });
            }
            catch {
                return StatusCode(500, new ApiResponse<object> {
                    Success = false,
                    StatusCode = 500,
                    Message = "Something went wrong. Try again later.",
                    Errors = [
                        new ErrorDto {
                    Code = "ServerError",
                    Message = "Something went wrong. Try again later."
                }
                    ],
                    Timestamp = DateTime.UtcNow.ToString("O")
                });
            }
        }

        [HttpGet("masterdata")]
        public async Task<IActionResult> GetMasterData() {
            try {
                var data = await _employeeService.GetMasterDataAsync();
                return Ok(new ApiResponse<MasterDataRequest> {
                    Success = true,
                    StatusCode = 200,
                    Message = "Master data fetched successfully.",
                    Data = data,
                    Timestamp = DateTime.UtcNow.ToString("O")
                });
            }
            catch {
                return StatusCode(500, new ApiResponse<object> {
                    Success = false,
                    StatusCode = 500,
                    Message = "Something went wrong. Try again later.",
                    Errors = [
                        new ErrorDto {
                    Code = "ServerError",
                    Message = "Something went wrong. Try again later."
                }
                    ],
                    Timestamp = DateTime.UtcNow.ToString("O")
                });
            }
        }


    }
}
