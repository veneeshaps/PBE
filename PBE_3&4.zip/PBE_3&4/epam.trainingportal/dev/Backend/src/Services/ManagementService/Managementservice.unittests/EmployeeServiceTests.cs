﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ManagementService.Infrastructure.Services;
using Entities;
using ManagementService.Application.DTOs;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ManagementService.Tests
{
    [TestClass]
    public class EmployeeServiceTests
    {
        private ApplicationDbContext _context;
        private IEmployeeService _employeeService;

        [TestInitialize]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDbContext(options);

            _context.Domains.Add(new Domain { DomainId = 1, Name = "Engineering" });
            _context.Roles.Add(new Role { RoleId = 1, Name = "Developer" });

            _context.SaveChanges();

            _employeeService = new EmployeeService(_context);
        }

        [TestMethod]
        public async Task AddEmployeeAsync_ShouldAddEmployee_WhenValid()
        {
            // Arrange
            var employee = new Employee
            {
                Email = "alice@epam.com",
                FirstName = "Alice",
                LastName = "Smith",
                DomainId = 1,
                RoleId = 1,
                DateOfJoining = DateTime.Now.AddYears(-1),
                IsDeactivated = false,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            // Act
            var result = await _employeeService.AddEmployeeAsync(employee);

            // Assert
            Assert.IsTrue(result.success);
            Assert.AreEqual("Employee added to database and Excel successfully.", result.message);
        }


        [TestMethod]
        public async Task GetAllDomainsAsync_ShouldReturnListOfDomains()
        {
            // Act
            var domains = await _employeeService.GetAllDomainsAsync();

            // Assert
            Assert.IsNotNull(domains);
            Assert.AreEqual(1, domains.Count);
            Assert.AreEqual("Engineering", domains[0].Name);
        }

        [TestMethod]
        public async Task GetAllRolesAsync_ShouldReturnListOfRoles()
        {
            // Act
            var roles = await _employeeService.GetAllRolesAsync();

            // Assert
            Assert.IsNotNull(roles);
            Assert.AreEqual(1, roles.Count);
            Assert.AreEqual("Developer", roles[0].Name);
        }

        [TestCleanup]
        public void Cleanup()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }
    }
}
