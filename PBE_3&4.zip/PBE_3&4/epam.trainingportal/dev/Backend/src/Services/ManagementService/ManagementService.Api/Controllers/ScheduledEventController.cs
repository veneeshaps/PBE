﻿using ManagementService.Application.DTO.Events;
using ManagementService.Application.Interfaces;
using ManagementService.Infrastructure.Repositories;
using ManagementService.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;

namespace ManagementService.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ScheduledEventController : ControllerBase
    {
        private readonly IScheduledEventService _eventService;
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IEventExportService _exportService;

        public ScheduledEventController(IScheduledEventService eventService, IEmployeeRepository employeeRepository, IEventExportService exportService)
        {
            _eventService = eventService;
            _employeeRepository = employeeRepository;
            _exportService = exportService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateScheduledEvent([FromBody] CreateScheduledEventDto dto)
        {
            var employeeId = dto.CreatedByEmployeeId;
            //Temp check to verify if this is called by an Admin!
            var employee = await _employeeRepository.GetByIdAsync(employeeId);
            if (employee == null || employee.Role?.Name != "Admin")
            {
                return StatusCode(403, new { message = "Access denied: Only admins can create scheduled events." });
            }

            //check for conflict
            var conflictResult = await _eventService.CheckForConflictsAsync(dto);

            if (conflictResult.HasConflict)
            {
                return Conflict(new
                {
                    message = "Scheduling conflict detected.",
                    conflicts = conflictResult.ConflictingEvents
                });
            }

            try
            {
                await _eventService.CreateScheduledEventAsync(dto);
                return StatusCode(201, new { message = "Scheduled event created successfully." });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception)
            {
                return StatusCode(500, new { message = "An unexpected error occurred while creating the scheduled event." });
            }


        }

        [HttpGet("getAllDomains")]
        public async Task<IActionResult> GetAllDomains()
        {
            var domains = await _eventService.GetAllDomainsAsync();
             
            return Ok(domains);
        }

        [HttpGet("getAllEventTypes")]
        public async Task<IActionResult> GettAllEventTypes()
        {
            var eventTypes = await _eventService.GetAllEventTypesAsync();
            return Ok(eventTypes);
        }

        [HttpGet("allByAdmin/{id:int}")]
        public async Task<IActionResult> GetAllEventsCreatedByAdmin(int id)
        {
            var employee = await _employeeRepository.GetByIdAsync(id);
            if (employee == null || employee.Role?.Name != "Admin")
            {
                return StatusCode(403, "Access denied: Only admins can fetch scheduled events.");
            }

            var events = await _eventService.GetAllScheduledEventsCreatedByAdminAsync(id);
            return Ok(events);
        }



        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetEventById(int id)
        {
            var scheduledEvent = await _eventService.GetScheduledEventByIdAsync(id);
            if (scheduledEvent == null) return NotFound(new {message ="Event not found."});
            return Ok(scheduledEvent);
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateScheduledEvent([FromBody] UpdateScheduledEventDto dto)
        {
            var result = await _eventService.UpdateScheduledEventAsync(dto);
            if (!result) return NotFound(new { message = "Event not found." });
            return Ok(new { message = "Scheduled event updated successfully." });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteScheduledEvent(int id)
        {
            var success = await _eventService.DeleteScheduledEventAsync(id);
            if (!success)
                return NotFound(new { message = "Scheduled event not found" });

            return Ok(new { message = "Scheduled event deleted successfully" });
        }

        [HttpGet("export/{id:int}")]
        public async Task<IActionResult> Export(int id)
        {
            var employee = await _employeeRepository.GetByIdAsync(id);
            if (employee == null || employee.Role?.Name != "Admin")
            {
                return StatusCode(403, "Access denied: Only admins can export data!.");
            }

            var fileContent = await _exportService.ExportScheduledEventsToExcelAsync(id);
            var fileName = $"EventSchedule_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

            return File(fileContent,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName);
        }

       [HttpPut("update-status")]
public async Task<IActionResult> UpdateStatus([FromBody] UpdateEventStatusDto dto)
{
    var success = await _eventService.UpdateEventStatusAsync(dto);

    if (!success)
        return NotFound(new { message = "Scheduled event not found." });

    return Ok(new { message = "Status updated successfully." });
}

    }
}
