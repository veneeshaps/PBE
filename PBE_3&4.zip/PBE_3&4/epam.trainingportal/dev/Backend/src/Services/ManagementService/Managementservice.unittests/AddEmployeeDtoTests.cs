﻿using ManagementService.Application.DTOs;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ManagementService.Tests.DTOs
{
    [TestClass]
    public class AddEmployeeDtoTests
    {
        private bool IsModelValid(AddEmployeeDto model, out List<ValidationResult> results)
        {
            var context = new ValidationContext(model, null, null);
            results = new List<ValidationResult>();
            return Validator.TryValidateObject(model, context, results, true);
        }

        [TestMethod]
        public void AddEmployeeDto_ShouldBeValid_WithProperData()
        {
            var dto = new AddEmployeeDto
            {
                Email = "john.doe@epam.com",
                FirstName = "John",
                LastName = "Doe",
                DomainId = 1,
                RoleId = 2,
                DateOfJoining = DateTime.Today,
                IsDeactivated = false,
                CreatedAt = DateTime.Today,
                UpdatedAt = DateTime.Today
            };

            var isValid = IsModelValid(dto, out var results);
            Assert.IsTrue(isValid);
            Assert.AreEqual(0, results.Count);
        }

       

        [TestMethod]
        public void AddEmployeeDto_ShouldBeInvalid_WhenDateOfJoiningInFuture()
        {
            var dto = new AddEmployeeDto
            {
                Email = "future.person@epam.com",
                FirstName = "Future",
                LastName = "Person",
                DomainId = 1,
                RoleId = 2,
                DateOfJoining = DateTime.Today.AddDays(5),
                IsDeactivated = false,
                CreatedAt = DateTime.Today,
                UpdatedAt = DateTime.Today
            };

            // Future joining date might be valid in some systems, adjust if needed
            var isValid = IsModelValid(dto, out var results);
            Assert.IsTrue(isValid); // Or Assert.IsFalse if your business logic disallows future dates
        }
    }
}
