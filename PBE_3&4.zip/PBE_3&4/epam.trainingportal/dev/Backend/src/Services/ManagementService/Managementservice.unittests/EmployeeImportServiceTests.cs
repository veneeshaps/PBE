﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Entities;
using ManagementService.Application.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

using OfficeOpenXml;

namespace ManagementService.Tests.Services
{
    [TestClass]
    public class EmployeeImportServiceTests
    {
        private ApplicationDbContext _context;
        private EmployeeImportService _service;

        [TestInitialize]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique DB for each test
                .Options;

            _context = new ApplicationDbContext(options);
            _service = new EmployeeImportService(_context);
        }

       


        private IFormFile CreateValidExcelFile()
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            var stream = new MemoryStream();
            using (var package = new ExcelPackage(stream))
            {
                var ws = package.Workbook.Worksheets.Add("Employees");

                ws.Cells[1, 1].Value = "Email";
                ws.Cells[1, 2].Value = "EmployeeId";
                ws.Cells[1, 3].Value = "FirstName";
                ws.Cells[1, 4].Value = "LastName";
                ws.Cells[1, 5].Value = "DomainId";
                ws.Cells[1, 6].Value = "RoleId";
                ws.Cells[1, 7].Value = "DateOfJoining";
                ws.Cells[1, 8].Value = "IsDeactivated";
                ws.Cells[1, 9].Value = "CreatedAt";
                ws.Cells[1, 10].Value = "UpdatedAt";

                ws.Cells[2, 1].Value = "john.doe@epam.com";
                ws.Cells[2, 3].Value = "John";
                ws.Cells[2, 4].Value = "Doe";
                ws.Cells[2, 5].Value = 1;
                ws.Cells[2, 6].Value = 1;
                ws.Cells[2, 7].Value = "10-01-2020";
                ws.Cells[2, 8].Value = "false";
                ws.Cells[2, 9].Value = "10-01-2020";
                ws.Cells[2, 10].Value = "10-01-2020";

                package.Save();
            }

            stream.Position = 0;
            return new FormFile(stream, 0, stream.Length, "file", "employees.xlsx");
        }
    }
}
