using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ManagementService.Domains.Entities
{
    public class Emp_Domain
    {
        [Key]
        public int DomainId { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; }

        // ✅ Add this navigation property
        public ICollection<ScheduledEventDomain> ScheduledEventDomains { get; set; }
    }
}
