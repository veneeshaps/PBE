using Entities;
using ManagementService.Application.DTO.Employee;
using ManagementService.Application.DTOs;
using ManagementService.Application.Interfaces;
using ManagementService.Application.Services;
using ManagementService.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;
namespace ManagementService.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IEmployeeService _employeeService;

        public EmployeeController(IEmployeeRepository employeeRepository, IEmployeeService employeeService)
        {
            _employeeRepository = employeeRepository;
            _employeeService = employeeService;
        }


        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var employees = await _employeeRepository.GetAllAsync();
            return Ok(employees);
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var employee = await _employeeRepository.GetByIdWithDetailsAsync(id);

            if (employee == null)
                return NotFound();

            var dto = new EmployeeDetailsDto
            {
                EmployeeId = employee.EmployeeId,
                Email = employee.Email,
                FullName = $"{employee.FirstName} {employee.LastName}",
                RoleName = employee.Role?.Name,
                DomainName = employee.Domain?.Name,
                DateOfJoining = employee.DateOfJoining,
                IsDeactivated = employee.IsDeactivated,
                CreatedAt = employee.CreatedAt,
                UpdatedAt = employee.UpdatedAt
            };

            return Ok(dto);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Employee employee)
        {
            await _employeeRepository.AddAsync(employee);
            await _employeeRepository.SaveAsync();
            return CreatedAtAction(nameof(GetById), new { id = employee.EmployeeId }, employee);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, Employee updated)
        {
            var employee = await _employeeRepository.GetByIdAsync(id);
            if (employee == null) return NotFound();

            // Update all modifiable properties
            employee.Email = updated.Email;
            employee.FirstName = updated.FirstName;
            employee.LastName = updated.LastName;
            employee.DomainId = updated.DomainId;
            employee.RoleId = updated.RoleId;
            employee.DateOfJoining = updated.DateOfJoining;
            employee.IsDeactivated = updated.IsDeactivated;
            employee.UpdatedAt = DateTime.UtcNow;

            _employeeRepository.Update(employee);
            await _employeeRepository.SaveAsync();

            return NoContent();
        }


        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var employee = await _employeeRepository.GetByIdAsync(id);
            if (employee == null) return NotFound();

            _employeeRepository.Delete(employee);
            await _employeeRepository.SaveAsync();
            return NoContent();
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddEmployee([FromBody] AddEmployeeDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var employee = new Employee
            {
                Email = dto.Email,
                // EmployeeId = dto.EmployeeId,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                DomainId = dto.DomainId,
                RoleId = dto.RoleId,
                DateOfJoining = dto.DateOfJoining,
                IsDeactivated = dto.IsDeactivated,
                CreatedAt = dto.CreatedAt,
                UpdatedAt = dto.UpdatedAt
            };

            var result = await _employeeService.AddEmployeeAsync(employee);

            if (!result.success)
                return BadRequest(new { success = false, message = result.message });

            return Ok(new { success = true, message = result.message });
            return Ok(new { message = result.message });
        }

        //newly added
        [HttpGet("domains")]

        public async Task<ActionResult<List<DomainDto>>> GetDomains()
        {
            var domains = await _employeeService.GetAllDomainsAsync();
            return Ok(domains);
        }

        [HttpGet("roles")]

        public async Task<ActionResult<List<RoleDto>>> GetRoles()
        {
            var roles = await _employeeService.GetAllRolesAsync();
            return Ok(roles);
        }

        [HttpGet("search")]
        public async Task<IActionResult> Search([FromQuery] string name)
        {
            var result = await _employeeService.SearchEmployeesAsync(name);
            if (!result.Any())
                return NotFound("No results found.");
            return Ok(new ApiResponse<IEnumerable<EmployeeDto>>
            {
                Success = true,
                StatusCode = 200,
                Message = "Employees retrieved successfully",
                Data = result,
                Errors = null,
                Timestamp = DateTime.UtcNow.ToLongDateString(),
                Metadata = null
            });

        }
    }
}