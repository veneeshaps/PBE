﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementService.Application.Interfaces;
using Microsoft.EntityFrameworkCore;
using Entities;

public class EventExportService : IEventExportService
{
    private readonly ApplicationDbContext _context;

    public EventExportService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<byte[]> ExportScheduledEventsToExcelAsync(int id)
    {
        var events = await _context.ScheduledEvents
            .Where(e => e.CreatedByEmployeeId == id)
            .Include(e => e.Event)
            .Include(e => e.ScheduledEventDomains)
                .ThenInclude(sd => sd.Domain)
            .Include(e => e.Attendances)
            .ToListAsync();

        using var memoryStream = new MemoryStream();

        using (SpreadsheetDocument document = SpreadsheetDocument.Create(memoryStream, SpreadsheetDocumentType.Workbook, true))
        {
            // Create workbook and worksheet
            WorkbookPart workbookPart = document.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();
            WorksheetPart worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            worksheetPart.Worksheet = new Worksheet(new SheetData());

            Sheets sheets = document.WorkbookPart.Workbook.AppendChild(new Sheets());
            Sheet sheet = new Sheet()
            {
                Id = document.WorkbookPart.GetIdOfPart(worksheetPart),
                SheetId = 1,
                Name = "Event Schedule"
            };
            sheets.Append(sheet);

            SheetData sheetData = worksheetPart.Worksheet.GetFirstChild<SheetData>();

            // Header Row
            Row headerRow = new Row();
            string[] headers = { "Scheduled Event Id","Event Name", "Date", "Start Time", "End Time", "Event Type", "Domains", "Total Attendees" ,"Status"};
            foreach (var header in headers)
            {
                headerRow.Append(CreateCell(header));
            }
            sheetData.AppendChild(headerRow);

            // Data Rows
            foreach (var e in events)
            {
                Row dataRow = new Row();
                dataRow.Append(CreateCell(e.ScheduledEventId.ToString()));
                dataRow.Append(CreateCell(e.Name));
                dataRow.Append(CreateCell(e.Date.ToShortDateString()));
                dataRow.Append(CreateCell(e.StartTime.ToString(@"hh\:mm")));
                dataRow.Append(CreateCell(e.EndTime.ToString(@"hh\:mm")));
                dataRow.Append(CreateCell(e.Event?.Name ?? "N/A"));
                dataRow.Append(CreateCell(string.Join(", ", e.ScheduledEventDomains.Select(d => d.Domain.Name))));
                dataRow.Append(CreateCell((e.Attendances?.Count ?? 0).ToString()));
                dataRow.Append(CreateCell(e.Status));

                sheetData.AppendChild(dataRow);
            }

            workbookPart.Workbook.Save();
        }

        return memoryStream.ToArray();
    }

    private Cell CreateCell(string value)
    {
        return new Cell()
        {
            DataType = CellValues.String,
            CellValue = new CellValue(value)
        };
    }
}
