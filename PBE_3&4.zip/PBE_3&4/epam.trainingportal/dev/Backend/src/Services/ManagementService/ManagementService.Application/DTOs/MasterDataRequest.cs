﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.DTOs
{
    public class MasterDataRequest {
        public List<DomainDto> Domains { get; set; } = new();
        public List<RoleDto> Roles { get; set; } = new();
    }

}
