﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.DTO.Events
{
    public class UpdateEventStatusDto
    {
        public int ScheduledEventId { get; set; }
        public string Status { get; set; }
    }

}
