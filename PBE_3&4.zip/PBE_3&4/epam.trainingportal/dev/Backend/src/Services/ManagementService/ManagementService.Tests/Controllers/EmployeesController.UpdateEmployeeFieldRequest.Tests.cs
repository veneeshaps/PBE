﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ManagementService.Api.Controllers;
using ManagementService.Application.DTOs;
using ManagementService.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

namespace ManagementService.Tests.Controllers {
    [TestClass]
    public class EmployeesControllerTests {
        private Mock<IEmployeeService>? _mockEmployeeService = null!;
        private EmployeesController? _controller = null!;

        [TestInitialize]
        public void Setup() {
            _mockEmployeeService = new Mock<IEmployeeService>();
            _controller = new EmployeesController(_mockEmployeeService.Object);
        }

        [TestMethod]
        public async Task EditField_ReturnsOk_WhenUpdateIsSuccessful() {
            // Arrange
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 1,
                Email = "test@example.com",
                FieldToUpdate = "domain",
                NewValue = "1"
            };

            var serviceResponse = new UpdateEmployeeFieldResponse {
                Success = true,
                Message = "Domain updated to Java successfully"
            };

            _mockEmployeeService?.Setup(s => s.UpdateEmployeeFieldAsync(request))
                                .ReturnsAsync(serviceResponse);

            // Act
            var result = await _controller!.EditField(request) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);

            var apiResponse = result.Value as ApiResponse<object>;
            Assert.IsTrue(apiResponse?.Success);
            Assert.AreEqual(serviceResponse.Message, apiResponse?.Message);
        }

        [TestMethod]
        public async Task EditField_ReturnsBadRequest_WhenUpdateFails() {
            // Arrange
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 999,
                Email = "wrong@example.com",
                FieldToUpdate = "domain",
                NewValue = "5"
            };

            var serviceResponse = new UpdateEmployeeFieldResponse {
                Success = false,
                Message = "Domain does not exist",
                Errors =
                [
                    new ErrorDto { Code = "DomainNotFound", Message = "Domain does not exist" }
                ]
            };

            _mockEmployeeService?.Setup(s => s.UpdateEmployeeFieldAsync(request))
                                .ReturnsAsync(serviceResponse);

            // Act
            var result = await _controller!.EditField(request) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(400, result.StatusCode);

            var apiResponse = result.Value as ApiResponse<object>;
            Assert.IsFalse(apiResponse?.Success);
            Assert.AreEqual(serviceResponse.Message, apiResponse?.Message);
            Assert.IsNotNull(apiResponse?.Errors);
        }

        [TestMethod]
        public async Task EditField_ReturnsInternalServerError_WhenExceptionIsThrown() {
            // Arrange
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 1,
                Email = "test@example.com",
                FieldToUpdate = "status",
                NewValue = "1"
            };

            _mockEmployeeService?.Setup(s => s.UpdateEmployeeFieldAsync(request))
                                .ThrowsAsync(new Exception("Unexpected error"));

            // Act
            var result = await _controller!.EditField(request) as ObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(500, result.StatusCode);

            var apiResponse = result.Value as ApiResponse<object>;
            Assert.IsFalse(apiResponse?.Success);
            Assert.AreEqual("Something went wrong. Try again later.", apiResponse?.Message);
            Assert.IsNotNull(apiResponse?.Errors);
            Assert.AreEqual("ServerError", apiResponse.Errors[0].Code);
        }
    }
}