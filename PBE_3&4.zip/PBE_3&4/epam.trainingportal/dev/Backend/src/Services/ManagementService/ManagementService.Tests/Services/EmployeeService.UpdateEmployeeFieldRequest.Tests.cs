﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ManagementService.Application.Services;
using ManagementService.Application.DTOs;
using Microsoft.EntityFrameworkCore;
using Entities;
using System.Threading.Tasks;
using ManagementService.Infrastructure.Repositories;

namespace ManagementService.Tests.Services {
    [TestClass]
    public class EmployeeServiceTests {
        private ApplicationDbContext? _context = null!;
        private EmployeeRepository? _repository = null!;
        private EmployeeService? _employeeService = null!;

        [TestInitialize]
        public void Setup() {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // FIXED
                .EnableSensitiveDataLogging()
                .Options;

            _context = new ApplicationDbContext(options);
            _context.Database.EnsureCreated();

            _context.Domains.Add(new Domain { DomainId = 1, Name = "Java" });
            _context.Roles.Add(new Role { RoleId = 1, Name = "Intern" });
            _context.Employees.Add(new Employee {
                EmployeeId = 100,
                Email = "test@example.com",
                FirstName = "Test",
                LastName = "User",
                DomainId = 1,
                RoleId = 1,
                IsDeactivated = false
            });
            _context.SaveChanges();

            _repository = new EmployeeRepository(_context);

            _employeeService = new EmployeeService(_repository, _context);
        }

        [TestMethod]
        public async Task UpdateEmployeeFieldAsync_ShouldNotUpdateDomain_AndReturnAlreadyUpdatedMessage() {
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 100,
                Email = "test@example.com",
                FieldToUpdate = "domain",
                NewValue = "1" // Same as existing
            };

            var result = await _employeeService!.UpdateEmployeeFieldAsync(request);

            Assert.IsTrue(result.Success);
            Assert.AreEqual("Employee's domain is already set to Java.", result.Message);
            Assert.IsNotNull(result.Errors);
            Assert.AreEqual(1, result.Errors.Count);
            Assert.AreEqual("DomainAlreadyUpdated", result.Errors[0].Code);
        }

        [TestMethod]
        public async Task UpdateEmployeeFieldAsync_ShouldUpdateRole() {
            var newRole = new Role { RoleId = 2, Name = "Bench" };
            _context?.Roles.Add(newRole);
            await _context!.SaveChangesAsync();

            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 100,
                Email = "test@example.com",
                FieldToUpdate = "role",
                NewValue = "2"
            };

            var result = await _employeeService!.UpdateEmployeeFieldAsync(request);

            Assert.IsTrue(result.Success);
            Assert.AreEqual("Role updated to Bench successfully.", result.Message);
        }

        [TestMethod]
        public async Task UpdateEmployeeFieldAsync_ShouldUpdateStatusToDeactivated() {
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 100,
                Email = "test@example.com",
                FieldToUpdate = "status",
                NewValue = "1"
            };

            var result = await _employeeService!.UpdateEmployeeFieldAsync(request);

            Assert.IsTrue(result.Success);
            Assert.AreEqual("Status updated to Deactivated successfully.", result.Message);
        }

        [TestMethod]
        public async Task UpdateEmployeeFieldAsync_ShouldReturnError_WhenInvalidField() {
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 100,
                Email = "test@example.com",
                FieldToUpdate = "invalidField",
                NewValue = "123"
            };

            var result = await _employeeService!.UpdateEmployeeFieldAsync(request);

            Assert.IsFalse(result.Success);
            Assert.AreEqual("Invalid field 'invalidfield' to update.", result.Message);
        }

        [TestMethod]
        public async Task UpdateEmployeeFieldAsync_ShouldReturnError_WhenEmployeeNotFound() {
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 999,
                Email = "wrong@example.com",
                FieldToUpdate = "domain",
                NewValue = "1"
            };

            var result = await _employeeService!.UpdateEmployeeFieldAsync(request);

            Assert.IsFalse(result.Success);
            Assert.AreEqual("Employee not found.", result.Message);
        }

        [TestMethod]
        public async Task UpdateEmployeeFieldAsync_ShouldReturnError_WhenInvalidDomainId() {
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 100,
                Email = "test@example.com",
                FieldToUpdate = "domain",
                NewValue = "999"
            };

            var result = await _employeeService!.UpdateEmployeeFieldAsync(request);

            Assert.IsFalse(result.Success);
            Assert.AreEqual("Domain does not exist.", result.Message);
        }

        [TestMethod]
        public async Task UpdateEmployeeFieldAsync_ShouldReturnError_WhenInvalidRoleId() {
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 100,
                Email = "test@example.com",
                FieldToUpdate = "role",
                NewValue = "999"
            };

            var result = await _employeeService!.UpdateEmployeeFieldAsync(request);

            Assert.IsFalse(result.Success);
            Assert.AreEqual("Role does not exist.", result.Message);
        }

        [TestMethod]
        public async Task UpdateEmployeeFieldAsync_ShouldNotUpdateStatus_AndReturnAlreadyUpdatedMessage() {
            var request = new UpdateEmployeeFieldRequest {
                EmployeeId = 100,
                Email = "test@example.com",
                FieldToUpdate = "status",
                NewValue = "0" // Same as existing (false)
            };

            var result = await _employeeService!.UpdateEmployeeFieldAsync(request);

            Assert.IsTrue(result.Success);
            Assert.AreEqual("Employee's status is already set to Active.", result.Message);
            Assert.IsNotNull(result.Errors);
            Assert.AreEqual(1, result.Errors.Count);
            Assert.AreEqual("StatusAlreadyUpdated", result.Errors[0].Code);
        }
    }
}