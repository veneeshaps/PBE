﻿using Entities;
using ManagementService.Application.DTOs;
using ManagementService.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;

namespace ManagementService.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;

        public EmployeeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddEmployee([FromBody] AddEmployeeDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var employee = new Employee
            {
                Email = dto.Email,
               // EmployeeId = dto.EmployeeId,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                DomainId = dto.DomainId,
                RoleId = dto.RoleId,
                DateOfJoining = dto.DateOfJoining,
                IsDeactivated = dto.IsDeactivated,
                CreatedAt = dto.CreatedAt,
                UpdatedAt = dto.UpdatedAt
            };

            var result = await _employeeService.AddEmployeeAsync(employee);

            if (!result.success)
                return BadRequest(new { success = false, message = result.message });

            return Ok(new { success = true, message = result.message });
            return Ok(new { message = result.message });
        }

        //newly added
        [HttpGet("domains")]

        public async Task<ActionResult<List<DomainDto>>> GetDomains()
        {
            var domains = await _employeeService.GetAllDomainsAsync();
            return Ok(domains);
        }

        [HttpGet("roles")]

        public async Task<ActionResult<List<RoleDto>>> GetRoles()
        {
            var roles = await _employeeService.GetAllRolesAsync();
            return Ok(roles);
        }




        //till here
    }
}