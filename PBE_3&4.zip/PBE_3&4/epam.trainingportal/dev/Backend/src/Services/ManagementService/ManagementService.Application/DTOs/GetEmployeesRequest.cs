﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.DTOs
{
    public class GetEmployeesRequest {
        public int EmployeeId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DomainDto Domain { get; set; } = default!;
        public RoleDto Role { get; set; } = default!;
        public int IsDeactivated { get; set; }
    }

    public class DomainDto {
        public int DomainId { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
