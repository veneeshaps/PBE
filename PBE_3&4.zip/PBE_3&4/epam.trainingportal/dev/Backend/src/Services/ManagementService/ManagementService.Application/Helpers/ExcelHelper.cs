﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClosedXML.Excel;
using Entities;

namespace ManagementService.Infrastructure.Helpers
{
    public static class ExcelHelper
    {
        private static readonly string filePath = "EmployeeRecords.xlsx";

        public static void WriteEmployeeToExcel(Employee employee)
        {
            var fileExists = File.Exists(filePath);
            using var workbook = fileExists ? new XLWorkbook(filePath) : new XLWorkbook();
            var worksheet = fileExists ? workbook.Worksheet(1) : workbook.AddWorksheet("Employees");

            if (!fileExists)
            {
                worksheet.Cell(1, 1).Value = "Email";
                worksheet.Cell(1, 2).Value = "EmployeeId";
                worksheet.Cell(1, 3).Value = "FirstName";
                worksheet.Cell(1, 4).Value = "LastName";
                worksheet.Cell(1, 5).Value = "DomainId";
                worksheet.Cell(1, 6).Value = "RoleId";
                worksheet.Cell(1, 7).Value = "DateOfJoining";
                worksheet.Cell(1, 8).Value = "IsDeactivated";
                worksheet.Cell(1, 9).Value = "CreatedAt";
                worksheet.Cell(1, 10).Value = "UpdatedAt";
            }

            var lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 1;
            var newRow = lastRow + 1;

            worksheet.Cell(newRow, 1).Value = employee.Email;
            worksheet.Cell(newRow, 2).Value = employee.EmployeeId;
            worksheet.Cell(newRow, 3).Value = employee.FirstName;
            worksheet.Cell(newRow, 4).Value = employee.LastName;
            worksheet.Cell(newRow, 5).Value = employee.DomainId;
            worksheet.Cell(newRow, 6).Value = employee.RoleId;
            worksheet.Cell(newRow, 7).Value = employee.DateOfJoining.ToString("dd/MM/yyyy");
            worksheet.Cell(newRow, 8).Value = employee.IsDeactivated;
            worksheet.Cell(newRow, 9).Value = employee.CreatedAt;
            worksheet.Cell(newRow, 10).Value = employee.UpdatedAt;

            workbook.SaveAs(filePath);
        }
    }
}
