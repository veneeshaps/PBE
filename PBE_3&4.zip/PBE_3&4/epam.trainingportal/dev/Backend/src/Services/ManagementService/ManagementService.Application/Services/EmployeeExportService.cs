﻿using OfficeOpenXml;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ManagementService.Application.Interfaces;
using Entities;

namespace ManagementService.Application.Services
{
    public class EmployeeExportService : IEmployeeExportService
    {
        private readonly ApplicationDbContext _context;

        public EmployeeExportService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<byte[]> ExportEmployeesToExcelAsync()
        {
            var employees = await _context.Employees
                .Include(e => e.Domain)
                .Include(e => e.Role)
                .ToListAsync();

            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Employees");

            // Headers
            worksheet.Cells[1, 1].Value = "Email";
            worksheet.Cells[1, 2].Value = "FirstName";
            worksheet.Cells[1, 3].Value = "LastName";
            worksheet.Cells[1, 4].Value = "Domain";
            worksheet.Cells[1, 5].Value = "Role";
            worksheet.Cells[1, 6].Value = "DateOfJoining";
            worksheet.Cells[1, 7].Value = "IsDeactivated";
            worksheet.Cells[1, 8].Value = "CreatedAt";
            worksheet.Cells[1, 9].Value = "UpdatedAt";

            int row = 2;
            foreach (var emp in employees)
            {
                worksheet.Cells[row, 1].Value = emp.Email;
                worksheet.Cells[row, 2].Value = emp.FirstName;
                worksheet.Cells[row, 3].Value = emp.LastName;
                worksheet.Cells[row, 4].Value = emp.Domain?.Name;
                worksheet.Cells[row, 5].Value = emp.Role?.Name;
                worksheet.Cells[row, 6].Value = emp.DateOfJoining.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                worksheet.Cells[row, 7].Value = emp.IsDeactivated;
                worksheet.Cells[row, 8].Value = emp.CreatedAt.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                worksheet.Cells[row, 9].Value = emp.UpdatedAt.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                row++;
            }

            return package.GetAsByteArray();
        }
    }
}
