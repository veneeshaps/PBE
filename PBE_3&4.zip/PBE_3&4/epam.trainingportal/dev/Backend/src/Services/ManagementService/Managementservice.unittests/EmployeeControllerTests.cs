﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ManagementService.Api.Controllers;
using ManagementService.Application.Interfaces;
using ManagementService.Application.DTOs;
using ManagementService.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;

[TestClass]
public class EmployeeControllerTests
{
    private Mock<IEmployeeService> _mockService;
    private EmployeeController _controller;

    [TestInitialize]
    public void Setup()
    {
        _mockService = new Mock<IEmployeeService>();
        _controller = new EmployeeController(_mockService.Object);
    }

    [TestMethod]
    public async Task AddEmployee_InvalidModel_ReturnsBadRequest()
    {
        _controller.ModelState.AddModelError("Email", "Required");
        var result = await _controller.AddEmployee(new AddEmployeeDto());
        Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
    }
}