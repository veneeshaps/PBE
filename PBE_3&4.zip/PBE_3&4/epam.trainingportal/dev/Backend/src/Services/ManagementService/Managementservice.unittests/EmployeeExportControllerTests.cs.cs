﻿using ManagementService.Api.Controllers;
using ManagementService.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Threading.Tasks;

namespace ManagementService.Tests.Controllers
{
    [TestClass]
    public class EmployeeExportControllerTests
    {
        private Mock<IEmployeeExportService> _mockExportService;
        private EmployeeExportController _controller;

        [TestInitialize]
        public void Setup()
        {
            _mockExportService = new Mock<IEmployeeExportService>();
            _controller = new EmployeeExportController(_mockExportService.Object);
        }

        [TestMethod]
        public async Task ExportEmployees_ShouldReturnFile_WhenExportIsSuccessful()
        {
            // Arrange
            var fakeFileBytes = new byte[] { 1, 2, 3, 4 };
            _mockExportService
                .Setup(s => s.ExportEmployeesToExcelAsync())
                .ReturnsAsync(fakeFileBytes);

            // Act
            var result = await _controller.ExportEmployees();

            // Assert
            var fileResult = result as FileContentResult;
            Assert.IsNotNull(fileResult);
            Assert.AreEqual("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileResult.ContentType);
            Assert.AreEqual(fakeFileBytes, fileResult.FileContents);
            Assert.IsTrue(fileResult.FileDownloadName.StartsWith("EmployeeData_"));
            Assert.IsTrue(fileResult.FileDownloadName.EndsWith(".xlsx"));
        }

        [TestMethod]
        public async Task ExportEmployees_ShouldReturn500_WhenExportFails()
        {
            // Arrange
            _mockExportService
                .Setup(s => s.ExportEmployeesToExcelAsync())
                .ReturnsAsync((byte[]?)null);

            // Act
            var result = await _controller.ExportEmployees();

            // Assert
            var statusResult = result as ObjectResult;
            Assert.IsNotNull(statusResult);
            Assert.AreEqual(500, statusResult.StatusCode);
            Assert.AreEqual("Exporting employees failed. Please try again.", statusResult.Value);
        }

        [TestMethod]
        public async Task ExportEmployees_ShouldReturn500_WhenEmptyFileReturned()
        {
            // Arrange
            _mockExportService
                .Setup(s => s.ExportEmployeesToExcelAsync())
                .ReturnsAsync(Array.Empty<byte>());

            // Act
            var result = await _controller.ExportEmployees();

            // Assert
            var statusResult = result as ObjectResult;
            Assert.IsNotNull(statusResult);
            Assert.AreEqual(500, statusResult.StatusCode);
            Assert.AreEqual("Exporting employees failed. Please try again.", statusResult.Value);
        }
    }
}
