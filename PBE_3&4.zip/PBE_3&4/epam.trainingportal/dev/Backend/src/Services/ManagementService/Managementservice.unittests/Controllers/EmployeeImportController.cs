﻿using ManagementService.Application.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ManagementService.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeImportController : ControllerBase
    {
        private readonly IEmployeeImportService _employeeImportService;

        public EmployeeImportController(IEmployeeImportService employeeImportService)
        {
            _employeeImportService = employeeImportService;
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadExcel(IFormFile file)
        {
            var (isSuccess, errors) = await _employeeImportService.ImportEmployeesFromExcelAsync(file);

            if (isSuccess)
            {
                if (errors.Any())
                {
                    // Success with warnings
                    return Ok(new
                    {
                        Message = "Import completed with some warnings",
                        Errors = errors
                    });
                }
                return Ok(new
                {
                    Message = "Employees imported successfully."
                });
            }
            else
            {
                return BadRequest(new
                {
                    Message = "Failed to import employee data.",
                    Errors = errors
                });
            }
        }
    }
}
