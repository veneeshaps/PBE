﻿using System.Threading.Tasks;
using Entities;
using ManagementService.Application.DTOs;

namespace ManagementService.Application.Interfaces {
    public interface IEmployeeService {
        Task<UpdateEmployeeFieldResponse> UpdateEmployeeFieldAsync(UpdateEmployeeFieldRequest request);
        Task<UpdateMultipleEmployeesResponse> UpdateMultipleEmployeesAsync(UpdateMultipleEmployeesRequest request);
        Task<List<GetEmployeesRequest>> GetAllEmployeesAsync();
        Task<MasterDataRequest> GetMasterDataAsync();
        Task<(bool success, string message)> AddEmployeeAsync(Employee employee);

        Task<List<DomainDto>> GetAllDomainsAsync();

        Task<List<RoleDto>> GetAllRolesAsync();

        Task<IEnumerable<EmployeeDto>> SearchEmployeesAsync(string name);

    }
}
