﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.DTO.Events
{
    public class ConflictResult
    {
        public bool HasConflict { get; set; }
        public List<ConflictingEventDto> ConflictingEvents { get; set; }
    }
}
