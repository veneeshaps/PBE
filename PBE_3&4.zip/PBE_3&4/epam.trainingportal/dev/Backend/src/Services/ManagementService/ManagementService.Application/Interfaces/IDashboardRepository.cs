﻿namespace ManagementService.Application.Interfaces
{
    public interface IDashboardRepository
    {
        Task<int> CountActiveUsersAsync();        // IsDeactivated == false
        Task<int> CountActiveEventsAsync();       // Status == "Active"
    }
}
