using ManagementService.Domains.Entities;

public class Attendance
{
    public int EmployeeId { get; set; }
    public DateTime Date { get; set; }
    public bool IsPresent { get; set; }

    // Navigation (optional)
    public Employee Employee { get; set; }
    public ScheduledEvent ScheduledEvent { get; set; }
}