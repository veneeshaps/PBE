﻿using ManagementService.Application.DTO.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.Interfaces
{
    public interface IScheduledEventService
    {
        Task CreateScheduledEventAsync(CreateScheduledEventDto dto);
        Task<ConflictResult> CheckForConflictsAsync(CreateScheduledEventDto dto);
        Task<List<ScheduledEventDto>> GetAllScheduledEventsCreatedByAdminAsync(int id);
        Task<ScheduledEventDto?> GetScheduledEventByIdAsync(int id);
        Task<bool> UpdateScheduledEventAsync(UpdateScheduledEventDto dto);
        Task<bool> DeleteScheduledEventAsync(int id);
        Task<bool> UpdateEventStatusAsync(UpdateEventStatusDto dto);
        Task<List<EventTypesDto>> GetAllEventTypesAsync();
        Task<List<DomainsTypesDto>> GetAllDomainsAsync();


    }
}
