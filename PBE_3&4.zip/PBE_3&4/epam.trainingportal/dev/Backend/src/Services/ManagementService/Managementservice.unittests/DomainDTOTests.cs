﻿using ManagementService.Application.DTOs;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ManagementService.Tests.DTOs
{
    [TestClass]
    public class DomainDtoTests
    {
        [TestMethod]
        public void DomainDto_ShouldCreateObject_WithValidData()
        {
            // Arrange
            var dto = new DomainDto
            {
                DomainId = 1,
                Name = "Engineering"
            };

            // Act & Assert
            Assert.AreEqual(1, dto.DomainId);
            Assert.AreEqual("Engineering", dto.Name);
        }

        [TestMethod]
        public void DomainDto_ShouldHaveDefaultValues_WhenInstantiated()
        {
            // Arrange
            var dto = new DomainDto();

            // Act & Assert
            Assert.AreEqual(0, dto.DomainId);
            Assert.IsNull(dto.Name);
        }
    }
}
