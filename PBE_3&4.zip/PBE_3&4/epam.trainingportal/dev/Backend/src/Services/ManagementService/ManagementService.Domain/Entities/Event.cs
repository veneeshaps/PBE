using System.ComponentModel.DataAnnotations;
using ManagementService.Domains.Entities;

namespace Entities
{
    public class Event
    {
        [Key]
        public int EventId { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; }

        public ICollection<ScheduledEvent> ScheduledEvents { get; set; }
    }
}
