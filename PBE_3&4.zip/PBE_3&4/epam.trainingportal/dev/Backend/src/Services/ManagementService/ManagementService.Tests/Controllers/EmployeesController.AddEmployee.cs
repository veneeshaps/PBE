﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using ManagementService.Api.Controllers;
using ManagementService.Application.DTOs;
using ManagementService.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace ManagementService.Tests.Controllers
{
    [TestClass]
    public class AddEmployee
    {
        private Mock<IEmployeeRepository> _mockRepo;
        private Mock<IEmployeeService> _mockService;
        private EmployeeController _controller;

        [TestInitialize]
        public void Setup()
        {
            _mockRepo = new Mock<IEmployeeRepository>();
            _mockService = new Mock<IEmployeeService>();
            _controller = new EmployeeController(_mockRepo.Object, _mockService.Object);
        }

        [TestMethod]
        public async Task GetAll_ReturnsListOfEmployees()
        {
            _mockRepo.Setup(r => r.GetAllAsync()).ReturnsAsync(new List<Employee>());

            var result = await _controller.GetAll();

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
        }


        [TestMethod]
        public async Task AddEmployee_ReturnsOk_WhenSuccessful()
        {
            var dto = new AddEmployeeDto
            {
                Email = "john.doe@epam.com",
                FirstName = "John",
                LastName = "Doe",
                DomainId = 1,
                RoleId = 1,
                DateOfJoining = DateTime.Now,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                IsDeactivated = false
            };

            _mockService.Setup(s => s.AddEmployeeAsync(It.IsAny<Employee>()))
                        .ReturnsAsync((true, "Employee added successfully."));

            var result = await _controller.AddEmployee(dto);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task AddEmployee_ReturnsBadRequest_WhenInvalid()
        {
            _controller.ModelState.AddModelError("Email", "Required");

            var dto = new AddEmployeeDto();

            var result = await _controller.AddEmployee(dto);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task GetRoles_ReturnsRolesList()
        {
            _mockService.Setup(s => s.GetAllRolesAsync()).ReturnsAsync(new List<RoleDto>());

            var result = await _controller.GetRoles();

            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task GetDomains_ReturnsDomainList()
        {
            _mockService.Setup(s => s.GetAllDomainsAsync()).ReturnsAsync(new List<DomainDto>());

            var result = await _controller.GetDomains();

            Assert.IsInstanceOfType(result.Result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task Search_ReturnsNotFound_IfNoMatch()
        {
            _mockService.Setup(s => s.SearchEmployeesAsync("unknown")).ReturnsAsync(new List<EmployeeDto>());

            var result = await _controller.Search("unknown");

            Assert.IsInstanceOfType(result, typeof(NotFoundObjectResult));
        }
    }
}
