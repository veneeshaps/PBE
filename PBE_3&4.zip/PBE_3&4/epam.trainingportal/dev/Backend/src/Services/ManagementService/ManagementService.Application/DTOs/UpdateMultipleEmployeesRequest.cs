﻿using System.Collections.Generic;

namespace ManagementService.Application.DTOs {
    public class EmployeeIdentifier {
        public int EmployeeId { get; set; }
        public string? Email { get; set; }
    }

    public class UpdateMultipleEmployeesRequest {
        public List<EmployeeIdentifier> Employees { get; set; } = [];

        public string? Role { get; set; }
        public string? Domain { get; set; }
        public string? Status { get; set; }
    }
}
