﻿namespace ManagementService.Domains
{
    public class Class1
    {

    }
}
