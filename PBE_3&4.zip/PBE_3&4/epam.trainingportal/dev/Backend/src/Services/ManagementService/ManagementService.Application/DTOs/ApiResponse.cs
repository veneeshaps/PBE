﻿using System;
using System.Collections.Generic;

namespace ManagementService.Application.DTOs {
    public class ApiResponse<T> {
        public bool Success { get; set; }
        public int StatusCode { get; set; }
        public string? Message { get; set; }
        public T? Data { get; set; }
        public List<ErrorDto>? Errors { get; set; }
        public required string Timestamp { get; set; }
        public object? Metadata { get; set; }
    }
}