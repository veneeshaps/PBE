﻿using ManagementService.Application.Interfaces;
using System.Threading.Tasks;

namespace ManagementService.Application.Services
{
    public class DashboardService : IDashboardService
    {
        private readonly IDashboardRepository _dashboardRepository;

        public DashboardService(IDashboardRepository dashboardRepository)
        {
            _dashboardRepository = dashboardRepository;
        }

        public async Task<int> GetTotalUsersAsync()
        {
            return await _dashboardRepository.CountActiveUsersAsync();
        }

        public async Task<int> GetTotalActiveEventsAsync()
        {
            return await _dashboardRepository.CountActiveEventsAsync();
        }
    }
}
