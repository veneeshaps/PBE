﻿using System.Collections.Generic;

namespace ManagementService.Application.DTOs {
    public class UpdateEmployeeFieldResponse {
        public bool Success { get; set; }
        public string? Message { get; set; }
        public List<ErrorDto>? Errors { get; set; }
    }

    public class ErrorDto {
        public required string Code { get; set; }
        public required string Message { get; set; }
        public string? Field { get; set; }
    }
}