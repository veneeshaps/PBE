﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.DTO.Events
{
    public class CreateScheduledEventDto
    {
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public int EventId { get; set; }
        public int CreatedByEmployeeId { get; set; }
        public List<int> DomainIds { get; set; }
    }
}
