﻿using ManagementService.Application.DTO.Events;
using ManagementService.Application.Interfaces;
using ManagementService.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.IO;
using System.Drawing;
using System.ComponentModel;
using Entities;
using ApplicationDbContext = Entities.ApplicationDbContext;

namespace ManagementService.Infrastructure.Services
{
    public class ScheduledEventService : IScheduledEventService
    {
        private readonly ApplicationDbContext _context;

        public ScheduledEventService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task CreateScheduledEventAsync(CreateScheduledEventDto dto)
        {
            var currentDate = DateTime.UtcNow.Date;
            var currentYear = currentDate.Year;

            if (dto.Date.Date < DateTime.UtcNow.Date)
            {
                throw new ArgumentException("Scheduled date cannot be in the past.");
            }
            if (dto.Date.Year != currentYear)
            {
                throw new ArgumentException($"Scheduled date must be within the current year ({currentYear}).");
            }

            if (dto.EndTime <= dto.StartTime)
            {
                throw new ArgumentException("End time must be after start time.");
            }

            var scheduledEvent = new ScheduledEvent
            {
                Name = dto.Name,
                Date = dto.Date,
                StartTime = dto.StartTime,
                EndTime = dto.EndTime,
                EventId = dto.EventId,
                CreatedByEmployeeId = dto.CreatedByEmployeeId,
                Status = "Scheduled",
                ScheduledEventDomains = new List<ScheduledEventDomain>(),
                Attendances = new List<Attendance>()
            };

            foreach (var domainId in dto.DomainIds)
            {
                scheduledEvent.ScheduledEventDomains.Add(new ScheduledEventDomain
                {
                    DomainId = domainId,
                    ScheduledEvent = scheduledEvent
                });
            }

            await _context.ScheduledEvents.AddAsync(scheduledEvent);
            await _context.SaveChangesAsync();

            var employees = await _context.Employees
                .Where(e => dto.DomainIds.Contains(e.DomainId) && !e.IsDeactivated)
                .ToListAsync();

            foreach (var emp in employees)
            {
                var attendance = new Attendance
                {
                    ScheduledEventId = scheduledEvent.ScheduledEventId,
                    EmployeeId = emp.EmployeeId,
                    IsPresent = false
                };
                _context.Attendances.Add(attendance);
            }

            await _context.SaveChangesAsync();
        }

        public async Task<ConflictResult> CheckForConflictsAsync(CreateScheduledEventDto dto)
        {
            // Overlapping time
            var overlappingEvents = await _context.ScheduledEvents
                .Include(e => e.ScheduledEventDomains) 
                .Where(e => e.Date == dto.Date &&
                    ((dto.StartTime >= e.StartTime && dto.StartTime < e.EndTime) ||
                     (dto.EndTime > e.StartTime && dto.EndTime <= e.EndTime) ||
                     (dto.StartTime <= e.StartTime && dto.EndTime >= e.EndTime)))
                .ToListAsync();

            var conflictingEvents = overlappingEvents
                .Where(e => e.ScheduledEventDomains
                    .Any(ed => dto.DomainIds.Contains(ed.DomainId)))
                .ToList();

            var result = new ConflictResult
            {
                HasConflict = conflictingEvents.Any(),
                ConflictingEvents = conflictingEvents.Select(e => new ConflictingEventDto
                {
                    EventId = e.EventId,
                    Name = e.Name,
                    Date = e.Date,
                    StartTime = e.StartTime,
                    EndTime = e.EndTime
                }).ToList()
            };

            return result;
        }

        public async Task<List<ScheduledEventDto>> GetAllScheduledEventsCreatedByAdminAsync(int id)
        {
            var events = await _context.ScheduledEvents
                .Where(e => e.CreatedByEmployeeId == id)
                .Include(e => e.CreatedByEmployee)
                .Include(e => e.ScheduledEventDomains)
                    .ThenInclude(se => se.Domain)
                .Include(e => e.Event)
                .ToListAsync();

            return events.Select(e => new ScheduledEventDto
            {
                ScheduledEventId = e.ScheduledEventId,
                Name = e.Name,
                Date = e.Date,
                StartTime = e.StartTime,
                EndTime = e.EndTime,
                CreatedBy = $"{e.CreatedByEmployee.FirstName} {e.CreatedByEmployee.LastName}",
                Domains = e.ScheduledEventDomains.Select(se => se.Domain.Name).ToList(),
                Status = e.Status,
                EventType = e.Event.Name
            }).ToList();
        }

        public async Task<List<EventTypesDto>> GetAllEventTypesAsync()
        {
            return await _context.Events
                .Select(d => new EventTypesDto
                {
                    EventId = d.EventId,
                    EventName = d.Name
                }).ToListAsync();
        }
        public async Task<List<DomainsTypesDto>> GetAllDomainsAsync()
        {
            return await _context.Domains
                .Select(d => new DomainsTypesDto
                {
                    DomainId = d.DomainId,
                    DomainName = d.Name
                }).ToListAsync();
        }


        public async Task<ScheduledEventDto?> GetScheduledEventByIdAsync(int id)
        {
            var e = await _context.ScheduledEvents
                .Include(e => e.CreatedByEmployee)
                .Include(e => e.ScheduledEventDomains)
                    .ThenInclude(se => se.Domain)
                .Include(e => e.Event) 
                .FirstOrDefaultAsync(e => e.ScheduledEventId == id);

            if (e == null) return null;

            return new ScheduledEventDto
            {
                ScheduledEventId = e.ScheduledEventId,
                Name = e.Name,
                Date = e.Date,
                StartTime = e.StartTime,
                EndTime = e.EndTime,
                CreatedBy = $"{e.CreatedByEmployee.FirstName} {e.CreatedByEmployee.LastName}",
                Domains = e.ScheduledEventDomains.Select(se => se.Domain.Name).ToList(),
                Status = e.Status,
                EventType = e.Event.Name 
            };
        }



        public async Task<bool> UpdateScheduledEventAsync(UpdateScheduledEventDto dto)
        {
            var scheduledEvent = await _context.ScheduledEvents
                .Include(e => e.ScheduledEventDomains)
                .Include(e => e.Attendances)
                .FirstOrDefaultAsync(e => e.ScheduledEventId == dto.ScheduledEventId);

            if (scheduledEvent == null) return false;

            scheduledEvent.Name = dto.Name;
            scheduledEvent.Date = dto.Date;
            scheduledEvent.StartTime = dto.StartTime;
            scheduledEvent.EndTime = dto.EndTime;
            scheduledEvent.Status = dto.Status;
            scheduledEvent.EventId = dto.EventId;
            

            scheduledEvent.ScheduledEventDomains.Clear();

            foreach (var domainId in dto.DomainIds)
            {
                scheduledEvent.ScheduledEventDomains.Add(new ScheduledEventDomain
                {
                    ScheduledEventId = scheduledEvent.ScheduledEventId,
                    DomainId = domainId
                });
            }

            var updatedEmployees = await _context.Employees
        .Where(e => dto.DomainIds.Contains(e.DomainId) && !e.IsDeactivated)
        .ToListAsync();

            var updatedEmployeeIds = updatedEmployees.Select(e => e.EmployeeId).ToHashSet();
            
            var attendancesToRemove = scheduledEvent.Attendances
        .Where(a => !updatedEmployeeIds.Contains(a.EmployeeId))
        .ToList();

            _context.Attendances.RemoveRange(attendancesToRemove);

            var existingAttendanceIds = scheduledEvent.Attendances
        .Select(a => a.EmployeeId)
        .ToHashSet();

            var newEmployeesToAdd = updatedEmployees
                .Where(e => !existingAttendanceIds.Contains(e.EmployeeId))
                .ToList();

            foreach (var emp in newEmployeesToAdd)
            {
                var attendance = new Attendance
                {
                    ScheduledEventId = scheduledEvent.ScheduledEventId,
                    EmployeeId = emp.EmployeeId,
                    IsPresent = false
                };
                _context.Attendances.Add(attendance);
            }

            await _context.SaveChangesAsync();
            return true;
        }
        public async Task<bool> DeleteScheduledEventAsync(int id)
        {
            var scheduledEvent = await _context.ScheduledEvents
                .Include(e => e.Attendances)
                .Include(e => e.ScheduledEventDomains)
                .FirstOrDefaultAsync(e => e.ScheduledEventId == id);

            if (scheduledEvent == null) return false;

            // Remove related attendances
            _context.Attendances.RemoveRange(scheduledEvent.Attendances);

            // Remove related domain associations
            _context.ScheduledEventDomains.RemoveRange(scheduledEvent.ScheduledEventDomains);

            // Remove the scheduled event itself
            _context.ScheduledEvents.Remove(scheduledEvent);

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateEventStatusAsync(UpdateEventStatusDto dto)
        {
            var scheduledEvent = await _context.ScheduledEvents
                .FirstOrDefaultAsync(e => e.ScheduledEventId == dto.ScheduledEventId);

            if (scheduledEvent == null)
                return false;

            scheduledEvent.Status = dto.Status;
            await _context.SaveChangesAsync();

            return true;
        }


    }
}
