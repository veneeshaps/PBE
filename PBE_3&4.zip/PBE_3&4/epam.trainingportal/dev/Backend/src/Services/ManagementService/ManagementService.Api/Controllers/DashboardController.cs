﻿using ManagementService.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ManagementService.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DashboardController : Controller
    {
        private readonly IDashboardService _dashboardService;

        public DashboardController(IDashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }

        [HttpGet("metrics")]
        public async Task<IActionResult> GetMetrics()
        {
            var result = new
            {
                totalUsers = await _dashboardService.GetTotalUsersAsync(),
                activeEvents = await _dashboardService.GetTotalActiveEventsAsync()
            };
            return Ok(result);
        }
    }
}
