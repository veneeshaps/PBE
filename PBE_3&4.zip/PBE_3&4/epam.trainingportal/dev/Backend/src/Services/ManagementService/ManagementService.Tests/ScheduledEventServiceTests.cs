﻿using ManagementService.Application.DTO.Events;
using Entities;
using ManagementService.Infrastructure.Persistence;
using ManagementService.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApplicationDbContext = Entities.ApplicationDbContext;

namespace EventManagement.Tests
{
    [TestClass]
    public class ScheduledEventServiceTests
    {
        private ApplicationDbContext _context;
        private ScheduledEventService _service;
        private int _seededAdminId = 2;

        [TestInitialize]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString()) // Ensure isolation between tests
                .Options;

            _context = new ApplicationDbContext(options);

            // Seed basic data
            var domain = new Domain { DomainId = 10, Name = "Backend" };
            var employee = new Employee
            {
                EmployeeId = _seededAdminId,
                FirstName = "Alice",
                LastName = "Smith",
                Email = "alice@example.com",
                DomainId = 10,
                RoleId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var role = new Role { RoleId = 1, Name = "Admin" };

            _context.Domains.Add(domain);
            _context.Employees.Add(employee);
            _context.Roles.Add(role);
            _context.Events.AddRange(
                new Event { EventId = 1, Name = "Code Review" },
                new Event { EventId = 2, Name = "Design Session" },
                new Event { EventId = 3, Name = "Workshop" },
                new Event { EventId = 4, Name = "Training" },
                new Event { EventId = 5, Name = "Retrospective" },
                new Event { EventId = 6, Name = "Team Sync" }
            );

            _context.SaveChanges();

            _service = new ScheduledEventService(_context);
        }

        [TestMethod]
        public async Task CreateScheduledEventAsync_CreatesEvent_And_Attendances()
        {
            var dto = new CreateScheduledEventDto
            {
                Name = "Code Review",
                Date = DateTime.Today,
                StartTime = new TimeSpan(10, 0, 0),
                EndTime = new TimeSpan(11, 0, 0),
                EventId = 1,
                CreatedByEmployeeId = _seededAdminId,
                DomainIds = new List<int> { 10 }
            };

            await _service.CreateScheduledEventAsync(dto);

            var scheduledEvent = await _context.ScheduledEvents.FirstOrDefaultAsync();
            Assert.IsNotNull(scheduledEvent);
            Assert.AreEqual("Code Review", scheduledEvent.Name);

            var attendance = await _context.Attendances.FirstOrDefaultAsync();
            Assert.IsNotNull(attendance);
            Assert.AreEqual(_seededAdminId, attendance.EmployeeId);
        }

        [TestMethod]
        public async Task CheckForConflictsAsync_DetectsConflict()
        {
            var existingEvent = new ScheduledEvent
            {
                ScheduledEventId = 1,
                Name = "Existing",
                Date = DateTime.Today,
                StartTime = new TimeSpan(10, 0, 0),
                EndTime = new TimeSpan(11, 0, 0),
                Status = "Pending",
                ScheduledEventDomains = new List<ScheduledEventDomain>
                {
                    new ScheduledEventDomain { DomainId = 10 }
                }
            };

            _context.ScheduledEvents.Add(existingEvent);
            _context.SaveChanges();

            var dto = new CreateScheduledEventDto
            {
                Name = "Conflict",
                Date = DateTime.Today,
                StartTime = new TimeSpan(10, 30, 0),
                EndTime = new TimeSpan(11, 30, 0),
                DomainIds = new List<int> { 10 }
            };

            var result = await _service.CheckForConflictsAsync(dto);

            Assert.IsTrue(result.HasConflict);
            Assert.AreEqual("Existing", result.ConflictingEvents[0].Name);
        }

        [TestMethod]
        public async Task GetAllScheduledEventsAsync_ReturnsScheduledEvents()
        {
            await _service.CreateScheduledEventAsync(new CreateScheduledEventDto
            {
                Name = "Design Session",
                Date = DateTime.Today,
                StartTime = new TimeSpan(12, 0, 0),
                EndTime = new TimeSpan(13, 0, 0),
                EventId = 2,
                CreatedByEmployeeId = _seededAdminId,
                DomainIds = new List<int> { 10 }
            });

            var events = await _service.GetAllScheduledEventsCreatedByAdminAsync(_seededAdminId);

            Assert.AreEqual(1, events.Count);
            Assert.AreEqual("Design Session", events[0].Name);
        }

        [TestMethod]
        public async Task GetScheduledEventByIdAsync_ReturnsCorrectEvent()
        {
            await _service.CreateScheduledEventAsync(new CreateScheduledEventDto
            {
                Name = "Workshop",
                Date = DateTime.Today,
                StartTime = new TimeSpan(9, 0, 0),
                EndTime = new TimeSpan(10, 0, 0),
                EventId = 3,
                CreatedByEmployeeId = _seededAdminId,
                DomainIds = new List<int> { 10 }
            });

            var id = _context.ScheduledEvents.First().ScheduledEventId;
            var result = await _service.GetScheduledEventByIdAsync(id);

            Assert.IsNotNull(result);
            Assert.AreEqual("Workshop", result.Name);
        }

        [TestMethod]
        public async Task UpdateScheduledEventAsync_UpdatesEvent()
        {
            await _service.CreateScheduledEventAsync(new CreateScheduledEventDto
            {
                Name = "Original Name",
                Date = DateTime.Today,
                StartTime = new TimeSpan(9, 0, 0),
                EndTime = new TimeSpan(10, 0, 0),
                EventId = 4,
                CreatedByEmployeeId = _seededAdminId,
                DomainIds = new List<int> { 10 }
            });

            var id = _context.ScheduledEvents.First().ScheduledEventId;

            var result = await _service.UpdateScheduledEventAsync(new UpdateScheduledEventDto
            {
                ScheduledEventId = id,
                Name = "Updated Name",
                Date = DateTime.Today,
                StartTime = new TimeSpan(14, 0, 0),
                EndTime = new TimeSpan(15, 0, 0),
                Status = "Rescheduled",
                DomainIds = new List<int> { 10 },
                EventId = 3
            });

            var updated = await _context.ScheduledEvents.FindAsync(id);

            Assert.IsTrue(result);
            Assert.AreEqual("Updated Name", updated.Name);
            Assert.AreEqual("Rescheduled", updated.Status);
        }

        [TestMethod]
        public async Task DeleteScheduledEventAsync_RemovesEvent()
        {
            await _service.CreateScheduledEventAsync(new CreateScheduledEventDto
            {
                Name = "Delete Me",
                Date = DateTime.Today,
                StartTime = new TimeSpan(16, 0, 0),
                EndTime = new TimeSpan(17, 0, 0),
                EventId = 5,
                CreatedByEmployeeId = _seededAdminId,
                DomainIds = new List<int> { 10 }
            });

            var id = _context.ScheduledEvents.First().ScheduledEventId;

            var result = await _service.DeleteScheduledEventAsync(id);

            Assert.IsTrue(result);
            Assert.IsFalse(_context.ScheduledEvents.Any(e => e.ScheduledEventId == id));
        }

        [TestMethod]
        public async Task UpdateEventStatusAsync_UpdatesStatus()
        {
            await _service.CreateScheduledEventAsync(new CreateScheduledEventDto
            {
                Name = "Status Test",
                Date = DateTime.Today,
                StartTime = new TimeSpan(18, 0, 0),
                EndTime = new TimeSpan(19, 0, 0),
                EventId = 6,
                CreatedByEmployeeId = _seededAdminId,
                DomainIds = new List<int> { 10 }
            });

            var id = _context.ScheduledEvents.First().ScheduledEventId;

            var result = await _service.UpdateEventStatusAsync(new UpdateEventStatusDto
            {
                ScheduledEventId = id,
                Status = "Cancelled"
            });

            Assert.IsTrue(result);
            Assert.AreEqual("Cancelled", _context.ScheduledEvents.First().Status);
        }
    }
}
