﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ManagementService.Api.Controllers;
using ManagementService.Application.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace ManagementService.Tests.Controllers
{
    [TestClass]
    public class EmployeeImportControllerTests
    {
        private Mock<IEmployeeImportService> _mockImportService;
        private EmployeeImportController _controller;

        [TestInitialize]
        public void Setup()
        {
            _mockImportService = new Mock<IEmployeeImportService>();
            _controller = new EmployeeImportController(_mockImportService.Object);
        }

        private IFormFile CreateDummyFile(string fileName = "test.xlsx")
        {
            var content = "Dummy content";
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(content));
            return new FormFile(stream, 0, stream.Length, "file", fileName)
            {
                Headers = new HeaderDictionary(),
                ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            };
        }

        [TestMethod]
        public async Task UploadExcel_ShouldReturnOk_WhenImportIsSuccessful()
        {
            // Arrange
            var file = CreateDummyFile();
            _mockImportService
                .Setup(s => s.ImportEmployeesFromExcelAsync(file))
                .ReturnsAsync((true, new List<string>()));

            // Act
            var result = await _controller.UploadExcel(file);

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);
            Assert.IsTrue(okResult.Value.ToString().Contains("Employees imported successfully"));
        }

        [TestMethod]
        public async Task UploadExcel_ShouldReturnOkWithWarnings_WhenSuccessButHasErrors()
        {
            // Arrange
            var file = CreateDummyFile();
            var errors = new List<string> { "Row 2: Invalid email" };

            _mockImportService
                .Setup(s => s.ImportEmployeesFromExcelAsync(file))
                .ReturnsAsync((true, errors));

            // Act
            var result = await _controller.UploadExcel(file);

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);
            Assert.IsTrue(okResult.Value.ToString().Contains("Import completed with some warnings"));
        }

        [TestMethod]
        public async Task UploadExcel_ShouldReturnBadRequest_WhenImportFails()
        {
            // Arrange
            var file = CreateDummyFile();
            var errors = new List<string> { "Invalid file format" };

            _mockImportService
                .Setup(s => s.ImportEmployeesFromExcelAsync(file))
                .ReturnsAsync((false, errors));

            // Act
            var result = await _controller.UploadExcel(file);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            Assert.IsNotNull(badRequestResult);
            Assert.AreEqual(400, badRequestResult.StatusCode);
            Assert.IsTrue(badRequestResult.Value.ToString().Contains("Failed to import employee data"));
        }
    }
}
