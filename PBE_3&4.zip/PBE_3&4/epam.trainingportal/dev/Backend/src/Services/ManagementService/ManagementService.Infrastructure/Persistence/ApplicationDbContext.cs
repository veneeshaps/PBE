﻿using Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace ManagementService.Infrastructure.Persistence
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        // DbSet for each entity
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<ScheduledEvent> ScheduledEvents { get; set; }
        public DbSet<Attendance> Attendances { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Domain> Domains { get; set; }
        public DbSet<ScheduledEventDomain> ScheduledEventDomains { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Many-to-Many: ScheduledEvent <-> Domain (Junction Table)
            modelBuilder.Entity<ScheduledEventDomain>()
                .HasKey(se => new { se.ScheduledEventId, se.DomainId });

            modelBuilder.Entity<ScheduledEventDomain>()
                .HasOne(se => se.ScheduledEvent)
                .WithMany(e => e.ScheduledEventDomains)
                .HasForeignKey(se => se.ScheduledEventId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<ScheduledEventDomain>()
                .HasOne(se => se.Domain)
                .WithMany(d => d.ScheduledEventDomains)
                .HasForeignKey(se => se.DomainId)
                .OnDelete(DeleteBehavior.Cascade);

            // Many-to-Many: Attendance (ScheduledEvent <-> Employee)
            modelBuilder.Entity<Attendance>()
                .HasKey(a => new { a.ScheduledEventId, a.EmployeeId });

            modelBuilder.Entity<Attendance>()
                .HasOne(a => a.ScheduledEvent)
                .WithMany(e => e.Attendances)
                .HasForeignKey(a => a.ScheduledEventId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Attendance>()
                .HasOne(a => a.Employee)
                .WithMany(e => e.Attendances)
                .HasForeignKey(a => a.EmployeeId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-Many: Employee <-> Role
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Role)
                .WithMany(r => r.Employees)
                .HasForeignKey(e => e.RoleId)
                .OnDelete(DeleteBehavior.Restrict);

            // One-to-Many: Employee <-> Domain
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Domain)
                .WithMany(d => d.Employees)
                .HasForeignKey(e => e.DomainId)
                .OnDelete(DeleteBehavior.Restrict);

            // One-to-Many: ScheduledEvent <-> Event
            modelBuilder.Entity<ScheduledEvent>()
                .HasOne(se => se.Event)
                .WithMany(e => e.ScheduledEvents)
                .HasForeignKey(se => se.EventId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-Many: ScheduledEvent <-> Employee (CreatedBy)
            modelBuilder.Entity<ScheduledEvent>()
                .HasOne(se => se.CreatedByEmployee)
                .WithMany(e => e.CreatedScheduledEvents)
                .HasForeignKey(se => se.CreatedByEmployeeId)
                .OnDelete(DeleteBehavior.Restrict);

            base.OnModelCreating(modelBuilder);
        }
    }
}



