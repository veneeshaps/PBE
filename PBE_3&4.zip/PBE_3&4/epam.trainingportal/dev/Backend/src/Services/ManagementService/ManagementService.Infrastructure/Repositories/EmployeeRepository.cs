﻿using Entities;
using ManagementService.Application.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Infrastructure.Repositories
{
    public class EmployeeRepository : GenericRepository<Employee>, IEmployeeRepository
    {
        public EmployeeRepository(ApplicationDbContext context) : base(context)
        {

        }

        public async Task<Employee?> GetByIdAsync(int id)
        {
            return await _context.Employees
                .Include(e => e.Role)
                .Include(e => e.Domain)
                .Include(e => e.Attendances)
                .Include(e => e.CreatedScheduledEvents)
                .FirstOrDefaultAsync(e => e.EmployeeId == id);
        }
        public async Task<Employee?> GetByIdWithDetailsAsync(int id)
        {
            return await _context.Employees
                .Include(e => e.Role)
                .Include(e => e.Domain)
                .FirstOrDefaultAsync(e => e.EmployeeId == id);
        }

        public async Task<IEnumerable<Employee>> SearchEmployeesByNameAsync(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                // Return all employees, including related entities (Role and Domain)
                return await _context.Employees
                    .Include(e => e.Role)
                    .Include(e => e.Domain)
                    .ToListAsync();
            }

            name = name.ToLower();

            return await _context.Employees
                .Include(e => e.Role)
                .Include(e => e.Domain)
                .Where(e =>
                    e.FirstName.ToLower().StartsWith(name) ||
                    e.LastName.ToLower().StartsWith(name) ||
                    (e.FirstName + " " + e.LastName).ToLower().StartsWith(name) ||
                    (e.Email.Contains("@") &&
                     e.Email.Substring(0, e.Email.IndexOf("@")).ToLower().StartsWith(name))
                )
                .ToListAsync();
        }
    }
}
