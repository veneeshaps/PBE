﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.Interfaces
{
    public interface IEventExportService
    {
        Task<byte[]> ExportScheduledEventsToExcelAsync(int id);
    }

}
