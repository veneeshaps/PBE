﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.Interfaces
{
    public interface IEmployeeExportService
    {
        Task<byte[]> ExportEmployeesToExcelAsync();
    }
}
