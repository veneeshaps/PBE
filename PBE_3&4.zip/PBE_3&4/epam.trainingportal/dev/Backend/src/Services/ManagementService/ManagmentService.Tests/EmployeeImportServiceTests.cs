﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System;
using OfficeOpenXml; // <- EPPlus
using ManagementService.Application.Interfaces;
using ManagementService.Application.Services;

namespace ManagementService.Tests.Services
{
    [TestClass]
    public class EmployeeImportServiceTests
    {
        private Mock<IEmployeeRepository> _employeeRepoMock;
        private Mock<IDomainRepository> _domainRepoMock;
        private EmployeeImportService _service;

        [TestInitialize]
        public void Setup()
        {
            _employeeRepoMock = new Mock<IEmployeeRepository>();
            _domainRepoMock = new Mock<IDomainRepository>();
            _service = new EmployeeImportService(_employeeRepoMock.Object, _domainRepoMock.Object);
        }

        private IFormFile CreateFakeExcelFile(string content, string fileName = "test.xlsx")
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            var stream = new MemoryStream();
            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Employees");
                var rows = content.Split('\n');

                for (int i = 0; i < rows.Length; i++)
                {
                    var cells = rows[i].Split(',');
                    for (int j = 0; j < cells.Length; j++)
                    {
                        worksheet.Cells[i + 1, j + 1].Value = cells[j];
                    }
                }

                package.SaveAs(stream);
            }

            stream.Position = 0;
            return new FormFile(stream, 0, stream.Length, "file", fileName)
            {
                Headers = new HeaderDictionary(),
                ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            };
        }

        [TestMethod]
        public async Task Import_ShouldFail_WhenFileIsNull()
        {
            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(null);
            Assert.IsFalse(success);
            Assert.IsTrue(errors.Contains("File is empty"));
        }

        [TestMethod]
        public async Task Import_ShouldFail_WhenFileIsNotXlsx()
        {
            var file = CreateFakeExcelFile("dummy", "test.csv");
            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(file);
            Assert.IsFalse(success);
            Assert.IsTrue(errors.Contains("Invalid file format"));
        }

        [TestMethod]
        public async Task Import_ShouldFail_WhenEmailIsNotEpam()
        {
            var file = CreateFakeExcelFile("123,john@gmail.com,John,Doe,1,1,2024-01-01,false,2024-01-01,2024-01-01");
            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(file);
            Assert.IsFalse(success);
            Assert.IsTrue(errors.Any(e => e.Contains("email must be from epam.com")));
        }

        [TestMethod]
        public async Task Import_ShouldFail_WhenAnyFieldIsMissing()
        {
            var file = CreateFakeExcelFile(",,John,Doe,1,1,2024-01-01,false,2024-01-01,2024-01-01");
            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(file);
            Assert.IsFalse(success);
            Assert.IsTrue(errors.Any(e => e.Contains("Required field missing")));
        }

        [TestMethod]
        public async Task Import_ShouldFail_WhenEmployeeIdIsDuplicate()
        {
            _employeeRepoMock.Setup(r => r.ExistsAsync(It.IsAny<int>())).ReturnsAsync(true);

            var file = CreateFakeExcelFile("100,john@epam.com,John,Doe,1,1,2024-01-01,false,2024-01-01,2024-01-01");
            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(file);
            Assert.IsFalse(success);
            Assert.IsTrue(errors.Any(e => e.Contains("Employee ID already exists")));
        }

        [TestMethod]
        public async Task Import_ShouldPass_WithValidSingleEmployee()
        {
            _employeeRepoMock.Setup(r => r.ExistsAsync(It.IsAny<int>())).ReturnsAsync(false);

            var file = CreateFakeExcelFile("101,john@epam.com,John,Doe,1,1,2024-01-01,false,2024-01-01,2024-01-01");
            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(file);
            Assert.IsTrue(success);
            Assert.AreEqual(0, errors.Count);
        }

        [TestMethod]
        public async Task Import_ShouldFail_WhenMultipleEmailsAreInvalid()
        {
            var file = CreateFakeExcelFile(
                "102,john@epam.com,John,Doe,1,1,2024-01-01,false,2024-01-01,2024-01-01\n" +
                "103,doe@gmail.com,Jane,Doe,1,1,2024-01-01,false,2024-01-01,2024-01-01"
            );

            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(file);
            Assert.IsFalse(success);
            Assert.IsTrue(errors.Any(e => e.Contains("email must be from epam.com")));
        }

        [TestMethod]
        public async Task Import_ShouldPass_WithMultipleValidEmployees()
        {
            _employeeRepoMock.Setup(r => r.ExistsAsync(It.IsAny<int>())).ReturnsAsync(false);

            var file = CreateFakeExcelFile(
                "201,jane@epam.com,Jane,Doe,2,1,2024-01-01,false,2024-01-01,2024-01-01\n" +
                "202,john@epam.com,John,Smith,3,2,2024-01-01,false,2024-01-01,2024-01-01"
            );

            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(file);
            Assert.IsTrue(success);
            Assert.AreEqual(0, errors.Count);
        }

        [TestMethod]
        public async Task Import_ShouldFail_WhenFileIsEmpty()
        {
            var file = CreateFakeExcelFile("");
            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(file);
            Assert.IsFalse(success);
            Assert.IsTrue(errors.Contains("File is empty"));
        }

        [TestMethod]
        public async Task Import_ShouldFail_WhenDateFormatIsInvalid()
        {
            var file = CreateFakeExcelFile("105,john@epam.com,John,Doe,1,1,invalid-date,false,2024-01-01,2024-01-01");
            var (success, errors) = await _service.ImportEmployeesFromExcelAsync(file);
            Assert.IsFalse(success);
            Assert.IsTrue(errors.Any(e => e.Contains("Invalid date format")));
        }
    }
}
