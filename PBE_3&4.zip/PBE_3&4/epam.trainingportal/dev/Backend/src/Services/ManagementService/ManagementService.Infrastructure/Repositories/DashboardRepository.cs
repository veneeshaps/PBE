﻿using System.Threading.Tasks;
using ManagementService.Application.Interfaces;
using Microsoft.EntityFrameworkCore;
// Make sure Entities project is referenced
using Entities;
namespace ManagementService.Infrastructure.Repositories
{
    public class DashboardRepository : IDashboardRepository
    {
        private readonly ApplicationDbContext _context;

        public DashboardRepository(ApplicationDbContext context)
        {
            _context = context;
        }
        //until database returning the result, count(The thread will not be blocked)
        public async Task<int> CountActiveUsersAsync()
        {
            return await _context.Employees.CountAsync(e => !e.IsDeactivated);
        }

        public async Task<int> CountActiveEventsAsync()
        {
            return await _context.ScheduledEvents.CountAsync(e => e.Status == "Ongoing");
        }
    }
}
