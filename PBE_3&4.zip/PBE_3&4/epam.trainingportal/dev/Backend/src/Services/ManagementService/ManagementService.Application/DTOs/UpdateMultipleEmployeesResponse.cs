﻿using System.Collections.Generic;

namespace ManagementService.Application.DTOs {
    public class UpdateMultipleEmployeesResponse {
        public bool Success { get; set; }
        public string? Message { get; set; }
        public List<ErrorDto>? Errors { get; set; }
    }
}
