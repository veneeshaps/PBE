﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ManagementService.Application.Services;
using ManagementService.Application.DTOs;
using Microsoft.EntityFrameworkCore;
using Entities;
using System.Threading.Tasks;
using System.Collections.Generic;
using ManagementService.Infrastructure.Repositories;

namespace ManagementService.Tests.Services {
    [TestClass]
    public class EmployeeServiceMultipleUpdateTests {
        private ApplicationDbContext? _context = null!;
        private EmployeeRepository? _repository = null!;
        private EmployeeService? _employeeService = null!;

        [TestInitialize]
        public void Setup() {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options;

            _context = new ApplicationDbContext(options);
            _context.Database.EnsureCreated();

            // Seed test data
            _context.Domains.AddRange(
                new Domain { DomainId = 1, Name = "Java" },
                new Domain { DomainId = 2, Name = ".NET" }
            );

            _context.Roles.AddRange(
                new Role { RoleId = 1, Name = "Intern" },
                new Role { RoleId = 2, Name = "Bench" }
            );

            _context.Employees.AddRange(
                new Employee {
                    EmployeeId = 1,
                    Email = "test1@example.com",
                    FirstName = "Test1",
                    LastName = "User",
                    DomainId = 1,
                    RoleId = 1,
                    IsDeactivated = false
                },
                new Employee {
                    EmployeeId = 2,
                    Email = "test2@example.com",
                    FirstName = "Test2",
                    LastName = "User",
                    DomainId = 1,
                    RoleId = 1,
                    IsDeactivated = false
                }
            );

            _context.SaveChanges();

            _repository = new EmployeeRepository(_context);

            _employeeService = new EmployeeService(_repository, _context);
        }

        [TestMethod]
        public async Task UpdateMultipleEmployeesAsync_ShouldUpdateRoleForAllValidEmployees() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
                    new() { EmployeeId = 1, Email = "test1@example.com" },
                    new() { EmployeeId = 2, Email = "test2@example.com" }
                ],
                Role = "2" // Bench role
            };

            // Act
            var result = await _employeeService!.UpdateMultipleEmployeesAsync(request);

            // Assert
            Assert.IsTrue(result.Success);
            Assert.AreEqual("Role Changed to Bench Successfully.", result.Message);

            var employee1 = await _context!.Employees.FindAsync(1);
            var employee2 = await _context.Employees.FindAsync(2);
            Assert.AreEqual(2, employee1?.RoleId);
            Assert.AreEqual(2, employee2?.RoleId);
        }

        [TestMethod]
        public async Task UpdateMultipleEmployeesAsync_ShouldReturnErrorsForNotFoundEmployees() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
                    new EmployeeIdentifier { EmployeeId = 1, Email = "test1@example.com" },
                    new EmployeeIdentifier { EmployeeId = 999, Email = "notfound@example.com" }
                ],
                Domain = "2" // .NET domain
            };

            // Act
            var result = await _employeeService!.UpdateMultipleEmployeesAsync(request);

            // Assert
            Assert.IsTrue(result.Success);
            Assert.AreEqual("Domain Changed to .NET Successfully.", result.Message);
            Assert.IsNotNull(result.Errors);
            Assert.AreEqual(1, result.Errors.Count);
            Assert.AreEqual("EmployeeNotFound", result.Errors[0].Code);

            var employee1 = await _context!.Employees.FindAsync(1);
            Assert.AreEqual(2, employee1?.DomainId);
        }

        [TestMethod]
        public async Task UpdateMultipleEmployeesAsync_ShouldReturnError_WhenInvalidRoleId() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
                    new EmployeeIdentifier { EmployeeId = 1, Email = "test1@example.com" }
                ],
                Role = "999" // Invalid role
            };

            // Act
            var result = await _employeeService!.UpdateMultipleEmployeesAsync(request);

            // Assert
            Assert.IsFalse(result.Success);
            Assert.AreEqual("Invalid Inputs", result.Message);
            Assert.IsNotNull(result.Errors);
            Assert.AreEqual(1, result.Errors.Count);
            Assert.AreEqual("RoleNotFound", result.Errors[0].Code);
        }

        [TestMethod]
        public async Task UpdateMultipleEmployeesAsync_ShouldUpdateStatusOnly() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
                    new EmployeeIdentifier { EmployeeId = 1, Email = "test1@example.com" },
                    new EmployeeIdentifier { EmployeeId = 2, Email = "test2@example.com" }
                ],
                Status = "1" // Deactivate
            };

            // Act
            var result = await _employeeService!.UpdateMultipleEmployeesAsync(request);

            // Assert
            Assert.IsTrue(result.Success);
            Assert.AreEqual("Status Changed to Deactive Successfully.", result.Message);

            var employee1 = await _context!.Employees.FindAsync(1);
            var employee2 = await _context.Employees.FindAsync(2);
            Assert.IsTrue(employee1?.IsDeactivated);
            Assert.IsTrue(employee2?.IsDeactivated);
        }

        [TestMethod]
        public async Task UpdateMultipleEmployeesAsync_ShouldReturnError_WhenNoValidUpdates() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
                    new EmployeeIdentifier { EmployeeId = 999, Email = "notfound@example.com" }
                ],
                Role = "2"
            };

            // Act
            var result = await _employeeService!.UpdateMultipleEmployeesAsync(request);

            // Assert
            Assert.IsFalse(result.Success);
            Assert.AreEqual("Invalid Inputs", result.Message);
            Assert.IsNotNull(result.Errors);
            Assert.AreEqual(1, result.Errors.Count);
            Assert.AreEqual("EmployeeNotFound", result.Errors[0].Code);
        }

        [TestMethod]
        public async Task UpdateMultipleEmployeesAsync_ShouldUpdateMultipleFields() {
            // Arrange
            var request = new UpdateMultipleEmployeesRequest {
                Employees = [
                    new EmployeeIdentifier { EmployeeId = 1, Email = "test1@example.com" }
                ],
                Role = "2",
                Domain = "2",
                Status = "1"
            };

            // Act
            var result = await _employeeService!.UpdateMultipleEmployeesAsync(request);

            // Assert
            Assert.IsTrue(result.Success);
            Assert.AreEqual("Fields Updated Successfully.", result.Message);

            var employee = await _context!.Employees.FindAsync(1);
            Assert.AreEqual(2, employee?.RoleId);
            Assert.AreEqual(2, employee?.DomainId);
            Assert.IsTrue(employee?.IsDeactivated);
        }
    }
}