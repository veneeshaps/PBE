﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.Interfaces
{
    public interface IEmployeeRepository : IGenericRepository<Employee>
    {
        public Task<Employee?> GetByIdWithDetailsAsync(int id);

        Task<IEnumerable<Employee>> SearchEmployeesByNameAsync(string name);
    }

}
