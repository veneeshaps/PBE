﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ManagementService.Application.Interfaces;
using Entities;

using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;

namespace ManagementService.Application.Services
{

        public class EmployeeImportService : IEmployeeImportService
    {
        private readonly ApplicationDbContext _context;

        public EmployeeImportService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<(bool isSuccess, List<string> errors)> ImportEmployeesFromExcelAsync(IFormFile file)
        {
            var errors = new List<string>();

            if (file == null || Path.GetExtension(file.FileName).ToLower() != ".xlsx")
            {
                errors.Add("Invalid file format. Please upload a .xlsx file.");
                return (false, errors);
            }

            using var stream = new MemoryStream();
            await file.CopyToAsync(stream);
            using var package = new ExcelPackage(stream);
            var worksheet = package.Workbook.Worksheets.FirstOrDefault();

            if (worksheet == null)
            {
                errors.Add("Worksheet not found in the uploaded Excel file.");
                return (false, errors);
            }

            int rowCount = worksheet.Dimension.Rows;
            var existingEmails = await _context.Employees.Select(e => e.Email).ToListAsync();
            var dateFormats = new[] { "dd-MM-yyyy", "dd/MM/yyyy" };

            for (int row = 2; row <= rowCount; row++)
            {
                try
                {
                    string email = worksheet.Cells[row, 1].Text?.Trim();
                    if (string.IsNullOrWhiteSpace(email) || !email.EndsWith("@epam.com"))
                    {
                        errors.Add($"Row {row}: Invalid or missing email.");
                        continue;
                    }

                    if (existingEmails.Contains(email))
                    {
                        errors.Add($"Row {row}: Email '{email}' already exists.");
                        continue;
                    }

                    string firstName = worksheet.Cells[row, 2].Text?.Trim();
                    if (string.IsNullOrWhiteSpace(firstName) || !firstName.All(char.IsLetter))
                    {
                        errors.Add($"Row {row}: Invalid First Name.");
                        continue;
                    }

                    string lastName = worksheet.Cells[row, 3].Text?.Trim();
                    if (string.IsNullOrWhiteSpace(lastName) || !lastName.All(char.IsLetter))
                    {
                        errors.Add($"Row {row}: Invalid Last Name.");
                        continue;
                    }

                    if (!int.TryParse(worksheet.Cells[row, 4].Text, out int domainId))
                    {
                        errors.Add($"Row {row}: Invalid DomainId.");
                        continue;
                    }

                    if (!int.TryParse(worksheet.Cells[row, 5].Text, out int roleId))
                    {
                        errors.Add($"Row {row}: Invalid RoleId.");
                        continue;
                    }

                    if (!DateTime.TryParseExact(worksheet.Cells[row, 6].Text, dateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var joiningDate))
                    {
                        errors.Add($"Row {row}: Invalid DateOfJoining format. Use dd-MM-yyyy or dd/MM/yyyy.");
                        continue;
                    }

                    if (!bool.TryParse(worksheet.Cells[row, 7].Text, out bool isDeactivated))
                    {
                        errors.Add($"Row {row}: Invalid IsDeactivated. Must be 'true' or 'false'.");
                        continue;
                    }

                    if (!DateTime.TryParseExact(worksheet.Cells[row, 8].Text, dateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var createdAt))
                    {
                        errors.Add($"Row {row}: Invalid CreatedAt format. Use dd-MM-yyyy or dd/MM/yyyy.");
                        continue;
                    }

                    if (!DateTime.TryParseExact(worksheet.Cells[row, 9].Text, dateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var updatedAt))
                    {
                        errors.Add($"Row {row}: Invalid UpdatedAt format. Use dd-MM-yyyy or dd/MM/yyyy.");
                        continue;
                    }

                    var employee = new Employee
                    {
                        Email = email,
                        FirstName = firstName,
                        LastName = lastName,
                        DomainId = domainId,
                        RoleId = roleId,
                        DateOfJoining = joiningDate,
                        IsDeactivated = isDeactivated,
                        CreatedAt = createdAt,
                        UpdatedAt = updatedAt
                    };

                    _context.Employees.Add(employee);
                }
                catch (Exception ex)
                {
                    errors.Add($"Row {row}: Unexpected error - {ex.Message}");
                    continue;
                }
            }

            if (!errors.Any())
            {
                await _context.SaveChangesAsync();
                return (true, new List<string>());
            }

            return (false, errors);
        }
    }
}
