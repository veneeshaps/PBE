﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.DTOs {
    public class UpdateEmployeeFieldRequest {

        public int EmployeeId { get; set; }
        public string? Email { get; set; }
        public string? FieldToUpdate { get; set; }
        public string? NewValue { get; set; }

    }
}
