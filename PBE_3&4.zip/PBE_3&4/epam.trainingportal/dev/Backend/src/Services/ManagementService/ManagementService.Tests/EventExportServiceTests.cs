﻿using ManagementService.Infrastructure.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Entities;

namespace EventManagement.Tests
{
    [TestClass]
    public class EventExportServiceTests
    {
        private ApplicationDbContext _context;
        private EventExportService _service;

        [TestInitialize]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "EventExportTestDb")
                .Options;

            _context = new ApplicationDbContext(options);

            // Seed data
            var domain = new Domain { DomainId = 1, Name = "Dotnet" };
            var scheduledEvent = new ScheduledEvent
            {
                ScheduledEventId = 1,
                Name = "Tech Talk",
                Date = DateTime.Today,
                StartTime = new TimeSpan(10, 0, 0),
                EndTime = new TimeSpan(11, 0, 0),
                Status = "Scheduled",
                Event = new Event { EventId = 1, Name = "Weekly Seminar" },
                ScheduledEventDomains = new List<ScheduledEventDomain>
                {
                    new ScheduledEventDomain { Domain = domain }
                },
                Attendances = new List<Attendance>
                {
                    new Attendance { EmployeeId = 101, IsPresent = true }
                }
            };

            _context.ScheduledEvents.Add(scheduledEvent);
            _context.SaveChanges();

            _service = new EventExportService(_context);
        }

        [TestMethod]
        public async Task ExportScheduledEventsToExcelAsync_ReturnsByteArray()
        {
            // Act
            var result = await _service.ExportScheduledEventsToExcelAsync(2);

            // Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(byte[]));
            Assert.IsTrue(result.Length > 0);
        }
    }
}
