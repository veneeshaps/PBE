﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ManagementService.Application.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System.IO;
using OfficeOpenXml;
using System;
using Entities;
using System.Linq;
using ManagementService.Application.Interfaces;
using Moq;
using Microsoft.AspNetCore.Mvc;
using ManagementService.Api.Controllers;
using NuGet.Packaging;

namespace ManagementService.Tests.Services
{
    [TestClass]
    public class EmployeeImportServiceTests
    {
        private ApplicationDbContext _context;
        private EmployeeImportService _service;

        private Mock<IEmployeeRepository> _repositoryMock;
        private EmployeeService _searchService;

        [TestInitialize]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDbContext(options);

            _context.Domains.Add(new Domain { DomainId = 1, Name = "Engineering" });
            _context.Roles.Add(new Role { RoleId = 1, Name = "Developer" });
            _context.SaveChanges();

            _repositoryMock = new Mock<IEmployeeRepository>();
            _searchService = new EmployeeService(_repositoryMock.Object, _context);

            _service = new EmployeeImportService(_context);
        }

        [TestCleanup]
        public void Cleanup()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }

        [TestMethod]
        public async Task InvalidFileExtension_ReturnsError()
        {
            var fileMock = new FormFile(new MemoryStream(), 0, 0, "file", "invalid.txt");

            var (isSuccess, errors) = await _service.ImportEmployeesFromExcelAsync(fileMock);

            Assert.IsFalse(isSuccess);
            Assert.IsTrue(errors.Contains("Invalid file format. Please upload a .xlsx file."));
        }

        [TestMethod]
        public async Task Import_WithInvalidFileExtension_ReturnsError()
        {
            var fileMock = new FormFile(new MemoryStream(), 0, 0, "file", "test.txt");

            var (isSuccess, errors) = await _service.ImportEmployeesFromExcelAsync(fileMock);

            Assert.IsFalse(isSuccess);
            Assert.IsTrue(errors.Any(e => e.Contains("Invalid file format")));
        }




        [TestMethod]

        public async Task MissingRequiredFieldsReturnsErrors()
        {
            ExcelPackage.License.SetNonCommercialOrganization("EPAM");

            using var stream = new MemoryStream();
            using (var package = new ExcelPackage(stream))
            {
                var sheet = package.Workbook.Worksheets.Add("Employees");
                sheet.Cells[1, 1].Value = "Email";
                sheet.Cells[1, 2].Value = "FirstName";
                sheet.Cells[1, 3].Value = "LastName";
                sheet.Cells[1, 4].Value = "DomainId";
                sheet.Cells[1, 5].Value = "RoleId";
                sheet.Cells[1, 6].Value = "DateOfJoining";
                sheet.Cells[1, 7].Value = "IsDeactivated";
                sheet.Cells[1, 8].Value = "CreatedAt";
                sheet.Cells[1, 9].Value = "UpdatedAt";

                // Email is invalid
                sheet.Cells[2, 1].Value = "wrongemail.com";
                sheet.Cells[2, 2].Value = "John";
                sheet.Cells[2, 3].Value = "Doe";
                sheet.Cells[2, 4].Value = 1;
                sheet.Cells[2, 5].Value = 2;
                sheet.Cells[2, 6].Value = "01-01-2023";
                sheet.Cells[2, 7].Value = "false";
                sheet.Cells[2, 8].Value = "01-01-2023";
                sheet.Cells[2, 9].Value = "01-01-2023";

                package.Save();
            }

            stream.Position = 0;
            var file = new FormFile(stream, 0, stream.Length, "file", "test.xlsx");

            var (isSuccess, errors) = await _service.ImportEmployeesFromExcelAsync(file);

            Assert.IsFalse(isSuccess);
            Assert.IsTrue(errors.Any(e => e.Contains("Invalid or missing email")));
        }
         [TestMethod]
      
        public async Task InvalidEmailDomainReturnsError()
        {

            ExcelPackage.License.SetNonCommercialOrganization("EPAM");
            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Employees");

            worksheet.Cells[1, 1].Value = "Email";
            worksheet.Cells[1, 2].Value = "FirstName";
            worksheet.Cells[1, 3].Value = "LastName";
            worksheet.Cells[1, 4].Value = "DomainId";
            worksheet.Cells[1, 5].Value = "RoleId";
            worksheet.Cells[1, 6].Value = "DateOfJoining";
            worksheet.Cells[1, 7].Value = "IsDeactivated";
            worksheet.Cells[1, 8].Value = "CreatedAt";
            worksheet.Cells[1, 9].Value = "UpdatedAt";

            worksheet.Cells[2, 1].Value = "jane.doe@gmail.com";  // Invalid domain
            worksheet.Cells[2, 2].Value = "Jane";
            worksheet.Cells[2, 3].Value = "Doe";
            worksheet.Cells[2, 4].Value = 1;
            worksheet.Cells[2, 5].Value = 2;
            worksheet.Cells[2, 6].Value = "01-01-2023";
            worksheet.Cells[2, 7].Value = "false";
            worksheet.Cells[2, 8].Value = "01-01-2023";
            worksheet.Cells[2, 9].Value = "01-01-2023";

            using var stream = new MemoryStream();
            package.SaveAs(stream);
            stream.Position = 0;

            var file = new FormFile(stream, 0, stream.Length, "file", "test.xlsx");

            var (isSuccess, errors) = await _service.ImportEmployeesFromExcelAsync(file);

            Assert.IsFalse(isSuccess);
            Assert.IsTrue(errors.Any(e => e.Contains("email")));
        }



        [TestMethod]
        public async Task ValidExcelFile_ReturnsSuccess()
        {

            ExcelPackage.License.SetNonCommercialOrganization("EPAM");
            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Employees");

            worksheet.Cells[1, 1].Value = "Email";
            worksheet.Cells[1, 2].Value = "FirstName";
            worksheet.Cells[1, 3].Value = "LastName";
            worksheet.Cells[1, 4].Value = "DomainId";
            worksheet.Cells[1, 5].Value = "RoleId";
            worksheet.Cells[1, 6].Value = "DateOfJoining";
            worksheet.Cells[1, 7].Value = "IsDeactivated";
            worksheet.Cells[1, 8].Value = "CreatedAt";
            worksheet.Cells[1, 9].Value = "UpdatedAt";

            worksheet.Cells[2, 1].Value = "john.doe@epam.com";
            worksheet.Cells[2, 2].Value = "John";
            worksheet.Cells[2, 3].Value = "Doe";
            worksheet.Cells[2, 4].Value = 1;
            worksheet.Cells[2, 5].Value = 2;
            worksheet.Cells[2, 6].Value = "01-01-2023";
            worksheet.Cells[2, 7].Value = "false";
            worksheet.Cells[2, 8].Value = "01-01-2023";
            worksheet.Cells[2, 9].Value = "01-01-2023";

            using var stream = new MemoryStream();
            package.SaveAs(stream);
            stream.Position = 0;

            var file = new FormFile(stream, 0, stream.Length, "file", "test.xlsx");

            var (isSuccess, errors) = await _service.ImportEmployeesFromExcelAsync(file);

            Assert.IsTrue(isSuccess);
            Assert.AreEqual(0, errors.Count);
        }


        [TestMethod]
       
        public async Task AllFieldsMissing_ReturnsErrors()
        {
            ExcelPackage.License.SetNonCommercialOrganization("EPAM");
            var stream = new MemoryStream();
            using (var package = new ExcelPackage(stream))
            {
              
                var sheet = package.Workbook.Worksheets.Add("Employees");
                sheet.Cells.LoadFromArrays(new object[][] {
            new object[] { "Email", "FirstName", "LastName", "DomainId", "RoleId", "DateOfJoining", "IsDeactivated", "CreatedAt", "UpdatedAt" },
            new object[] { "", "", "", "", "", "", "", "", "" }
        });
                package.Save();
            }
            stream.Position = 0;
            var file = new FormFile(stream, 0, stream.Length, "file", "emptyRow.xlsx");

            var (isSuccess, errors) = await _service.ImportEmployeesFromExcelAsync(file);

            Assert.IsFalse(isSuccess);
            Assert.IsTrue(errors.Any());
        }







        [TestMethod]
        public async Task SearchEmployeesAsync_WithValidName_ReturnsFilteredResults()
        {
           

            var employees = new List<Employee>
            {
                new Employee
                {
                    FirstName = "John",
                    LastName = "Doe",
                    Email = "john.doe@example.com",
                    Role = new Role { Name = "Admin" },
                    Domain = new Domain { Name = "IT" },
                    IsDeactivated = false
                }
            };

            _repositoryMock.Setup(r => r.SearchEmployeesByNameAsync("john"))
                           .ReturnsAsync(employees);

            var result = await _searchService.SearchEmployeesAsync("john");

            Assert.AreEqual(1, result.Count()); // Ensures one record is returned
            Assert.AreEqual("John Doe", result.First().FullName); //  Ensures full name is formatted properly
        }

        [TestMethod]
        public async Task SearchEmployeesAsync_WithBlankOrSpecialCharacters_ReturnsNoError()
        {
            //  Test: Validates that blank input or special characters return an empty result (no crash).

            var testInputs = new[] { "", "@#%!" };
            foreach (var input in testInputs)
            {
                _repositoryMock.Setup(r => r.SearchEmployeesByNameAsync(input))
                               .ReturnsAsync(new List<Employee>());

                var result = await _searchService.SearchEmployeesAsync(input);

                Assert.IsNotNull(result); //  Should not be null
                Assert.AreEqual(0, result.Count()); //  Should return empty list
            }
        }

        [TestMethod]
        public async Task SearchEmployeesAsync_WithNoMatchingResults_ReturnsEmptyList()
        {
            // 🧪 Test: Validates that when no employee matches the search query, an empty list is returned.

            _repositoryMock.Setup(r => r.SearchEmployeesByNameAsync("unknown"))
                           .ReturnsAsync(new List<Employee>()); // Simulating no match found

            var result = await _searchService.SearchEmployeesAsync("unknown");

            Assert.IsNotNull(result); //  Should not be null
            Assert.AreEqual(0, result.Count()); //  Should return empty list meaning "No results found"
        }
    }
}
