﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagementService.Application.DTO.Events
{
    public class ScheduledEventDto
    {
        public int ScheduledEventId { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public List<string> Domains { get; set; } // domain names
        public string CreatedBy { get; set; } // Employee name
        public string Status { get; set; }

        public string EventType { get; set; }

    }

}
