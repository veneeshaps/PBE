namespace ManagementService.Domains.Entities
{
    public class ScheduledEventDomain
    {
        public int ScheduledEventId { get; set; }
        public int DomainId { get; set; }

        // Navigation Properties
        public ScheduledEvent ScheduledEvent { get; set; }
        public Emp_Domain Domain { get; set; }
    }
}
