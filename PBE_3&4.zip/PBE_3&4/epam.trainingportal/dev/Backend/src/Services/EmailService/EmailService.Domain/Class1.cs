﻿namespace EmailService.Domain
{
    public class Class1
    {

    }
}
