﻿namespace EmailService.Infrastructure
{
    public class Class1
    {

    }
}
