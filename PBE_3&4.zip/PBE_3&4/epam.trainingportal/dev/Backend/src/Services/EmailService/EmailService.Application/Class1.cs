﻿namespace EmailService.Application
{
    public class Class1
    {

    }
}
