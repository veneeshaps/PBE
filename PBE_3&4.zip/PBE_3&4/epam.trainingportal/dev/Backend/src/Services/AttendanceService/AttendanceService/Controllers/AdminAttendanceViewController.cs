﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System;
using AttendanceService.Application.Interfaces;



namespace AttendanceService.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminAttendanceViewController : ControllerBase
    {
        private readonly IAttendanceSer _attendanceService;

        public AdminAttendanceViewController(IAttendanceSer attendanceService)
        {
            _attendanceService = attendanceService;
        }

        // Get attendance for the current running event
        [HttpGet("current/{AdminMail}")]
        public async Task<IActionResult> GetCurrentEventAttendance(string AdminMail)
        {
            return await _attendanceService.GetCurrentEventAttendance(AdminMail);
        }

        // Get attendance summary
        [HttpGet("summary/{AdminMail}")]
        public async Task<IActionResult> GetAttendanceSummary(string AdminMail)
        {
            return await _attendanceService.GetAttendanceSummary(AdminMail);
        }

        // Get attendance by Scheduled Event Name
        [HttpGet("by-schedule-name/{AdminMail}/{scheduleEventName}")]
        public async Task<IActionResult> GetAttendanceByScheduleName(string AdminMail, string scheduleEventName)
        {
            return await _attendanceService.GetAttendanceByScheduleName(AdminMail, scheduleEventName);
        }
    }
}
