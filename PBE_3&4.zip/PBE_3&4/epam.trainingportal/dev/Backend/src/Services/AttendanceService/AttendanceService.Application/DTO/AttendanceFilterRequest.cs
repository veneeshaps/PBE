﻿public class AttendanceFilterRequest
{
    public int EmployeeId { get; set; }
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public string? EventName { get; set; }
    public bool? IsPresent { get; set; }
    public string? SortDirection { get; set; }
}
