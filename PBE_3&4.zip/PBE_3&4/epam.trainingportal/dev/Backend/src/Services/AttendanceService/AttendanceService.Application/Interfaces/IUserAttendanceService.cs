﻿using Entities;

namespace AttendanceService.Application.Interfaces
{
    public interface IUserAttendanceService
    {
        Task<(List<AttendanceDto> Records, int TotalCount)> GetFilteredAttendanceAsync(AttendanceFilterRequest request);
        Task<object> GetAttendanceHistoryAsync(int employeeId);
        Task<List<EventNameDto>> GetAllEventNamesAsync();
    }
}
