﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AttendanceService.Application.Services;

namespace AttendanceService.Application.Interfaces
{
    public interface IAttendanceSer
    {
        Task<IActionResult> GetCurrentEventAttendance(string AdminMail);
        Task<IActionResult> GetAttendanceSummary(string AdminMail);
        Task<IActionResult> GetAttendanceByScheduleName(string AdminMail, string scheduleEventName);
    }
}
