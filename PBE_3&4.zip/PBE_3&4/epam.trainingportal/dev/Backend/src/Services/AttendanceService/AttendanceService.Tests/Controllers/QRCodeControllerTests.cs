﻿using AttendanceService.API.Controllers;
using AttendanceService.Application.services;
using Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;
using System.Text.Json;
namespace AttendanceService.Tests.Controllers
{
    public class QRCodeControllerTests
    {
        private Mock<IQRCodeService>? _qrCodeServiceMock;


        private QRCodeController CreateController(string dbName, out ApplicationDbContext context)
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: dbName)
                .Options;

            context = new ApplicationDbContext(options);
            _qrCodeServiceMock = new Mock<IQRCodeService>();

            return new QRCodeController(_qrCodeServiceMock.Object, context);
        }

        [Fact]
        public void GenerateQRCode_ReturnsBadRequest_WhenEventIdIsNull()
        {
            var controller = CreateController("Db1", out _);
            var result = controller.GenerateQRCode(string.Empty); // or "test content"

            var badRequest = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(400, badRequest.StatusCode);
        }

        [Fact]
        public void GenerateQRCode_ReturnsBadRequest_WhenEventIdIsNotInteger()
        {
            var controller = CreateController("Db2", out _);
            var result = controller.GenerateQRCode("abc");
            var badRequest = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(400, badRequest.StatusCode);
        }

        [Fact]
        public void GenerateQRCode_ReturnsNotFound_WhenEventDoesNotExist()
        {
            var controller = CreateController("Db3", out _);
            var result = controller.GenerateQRCode("999");
            var notFound = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal(404, notFound.StatusCode);
        }

        [Fact]
        public void DecryptQRCode_ReturnsBadRequest_WhenEncryptedDataIsNull()
        {
            var controller = CreateController("Db4", out _);
            var result = controller.DecryptQRCode(null);
            var badRequest = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(400, badRequest.StatusCode);
        }

        [Fact]
        public void GenerateQRCode_ReturnsOk_WhenEventExists()
        {
            var controller = CreateController("Db5", out var context);
            context.Events.Add(new Event { EventId = 1, Name = "Sample Event" });
            context.SaveChanges();

            _qrCodeServiceMock!.Setup(s => s.GenerateQRCode("1")).Returns("fakeQRCodeBase64");


            var result = controller.GenerateQRCode("1");
            var okResult = Assert.IsType<OkObjectResult>(result);

            // Convert to JsonElement to extract data
            var json = JsonSerializer.Serialize(okResult.Value);
            using var doc = JsonDocument.Parse(json);
            var qrCode = doc.RootElement.GetProperty("qrCode").GetString();

            Assert.Equal("fakeQRCodeBase64", qrCode);
        }

        [Fact]
        public void GetAllEventIds_ReturnsListOfEvents()
        {
            var controller = CreateController("Db6", out var context);
            context.Events.Add(new Event { EventId = 1, Name = "Sample Event" });
            context.SaveChanges();

            var result = controller.GetAllEventIds();
            var okResult = Assert.IsType<OkObjectResult>(result);

            var list = Assert.IsAssignableFrom<IEnumerable<object>>(okResult.Value);
            Assert.Single(list);
        }

    }
}