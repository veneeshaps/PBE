﻿using AttendanceService.Application.DTOs;
using AttendanceService.Application.Interfaces;
using AttendanceService.Application.Models.Dtos;
using AttendanceService.Application.Models.Requests;
using AttendanceService.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace AttendanceService.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AttendanceController : ControllerBase
    {
        private readonly IAttendanceServices _attendanceService;
        private readonly IQrValidationService _qrValidationService;

        public AttendanceController(IAttendanceServices attendanceService, IQrValidationService qrValidationService)
        {
            _attendanceService = attendanceService;
            _qrValidationService = qrValidationService;
        }



        [HttpPost("mark")]
        public async Task<IActionResult> MarkAttendance([FromBody] MarkAttendanceRequest request)
        {
            if (string.IsNullOrEmpty(request.Fingerprint))
                return BadRequest("Device Identifier is required.");

            var result = await _attendanceService.MarkAttendanceAsync(request);

            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }

        [HttpPost("validate-qr")]
        public IActionResult ValidateQr([FromBody] QrValidationRequestDto request)
        {
            var result = _qrValidationService.ValidateQr(request);
            return Ok(result);
        }



    }
}
