﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttendanceService.Application.Models.Requests
{
    public class MarkAttendanceRequest
    {
        public int EventId { get; set; }
        public int EmployeeId { get; set; }
        public string? Fingerprint { get; set; }
    }

}
