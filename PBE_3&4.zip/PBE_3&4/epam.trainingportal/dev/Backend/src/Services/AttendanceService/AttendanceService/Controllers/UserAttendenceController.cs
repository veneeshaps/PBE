﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Entities;
using AttendanceService.Application.Interfaces;

namespace AttendanceService.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AttendanceController : ControllerBase
    {
        private readonly IUserAttendanceService _attendanceService;

        public AttendanceController(IUserAttendanceService attendanceService)
        {
            _attendanceService = attendanceService;
        }

        [HttpGet("filter/{employeeId}")]
        public async Task<IActionResult> GetFilteredAttendance(
            int employeeId,
            [FromQuery] DateTime? startDate,
            [FromQuery] DateTime? endDate,
            [FromQuery] string? eventName,
            [FromQuery] bool? isPresent,
            [FromQuery] string? sortDirection)
        {
            var request = new AttendanceFilterRequest
            {
                EmployeeId = employeeId,
                StartDate = startDate,
                EndDate = endDate,
                EventName = eventName,
                IsPresent = isPresent,
                SortDirection = sortDirection
            };

            var (records, totalCount) = await _attendanceService.GetFilteredAttendanceAsync(request);

            return Ok(new
            {
                events = records,
                totalCount
            });
        }

        [HttpGet("{employeeId}")]
        public async Task<IActionResult> GetAttendanceHistory(int employeeId)
        {
            var result = await _attendanceService.GetAttendanceHistoryAsync(employeeId);
            return Ok(result);
        }

        [HttpGet("events")]
        public async Task<IActionResult> GetAllEventNames()
        {
            var result = await _attendanceService.GetAllEventNamesAsync();
            return Ok(result);
        }
    }
}
