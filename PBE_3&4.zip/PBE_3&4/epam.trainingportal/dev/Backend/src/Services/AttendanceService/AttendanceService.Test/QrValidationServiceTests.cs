﻿using AttendanceService.Application.DTOs;
using AttendanceService.Application.Services;
using Xunit;

namespace AttendanceService.Test
{
    public class QrValidationServiceTests
    {
        private readonly QrValidationService _service;

        public QrValidationServiceTests()
        {
            _service = new QrValidationService();
        }

        [Fact]
        public void ValidateQr_ShouldReturnValid_WhenTimestampWithin3Seconds()
        {
            // Arrange
            var now = DateTime.UtcNow.Ticks;
            var request = new QrValidationRequestDto
            {
                Timestamp = now,
                EventId = 1
            };

            // Act
            var result = _service.ValidateQr(request);

            // Assert
            Assert.True(result.IsValid);
            Assert.Null(result.Message);
        }

        [Fact]
        public void ValidateQr_ShouldReturnInvalid_WhenTimestampIsTooOld()
        {
            // Arrange: More than 3 seconds old
            var oldTimestamp = DateTime.UtcNow.AddSeconds(-5).Ticks;
            var request = new QrValidationRequestDto
            {
                Timestamp = oldTimestamp,
                EventId = 1
            };

            // Act
            var result = _service.ValidateQr(request);

            // Assert
            Assert.False(result.IsValid);
            Assert.Equal("QR code has expired or is too early.", result.Message);
        }

        [Fact]
        public void ValidateQr_ShouldReturnInvalid_WhenTimestampIsFromFuture()
        {
            // Arrange: More than 3 seconds ahead
            var futureTimestamp = DateTime.UtcNow.AddSeconds(5).Ticks;
            var request = new QrValidationRequestDto
            {
                Timestamp = futureTimestamp,
                EventId = 1
            };

            // Act
            var result = _service.ValidateQr(request);

            // Assert
            Assert.False(result.IsValid);
            Assert.Equal("QR code has expired or is too early.", result.Message);
        }

        [Fact]
        public void ValidateQr_ShouldReturnInvalid_WhenTimestampIsOutOfRange()
        {
            // Arrange: An invalid timestamp (negative ticks to simulate error)
            var request = new QrValidationRequestDto
            {
                Timestamp = long.MaxValue, // Simulate an invalid datetime
                EventId = 1
            };

            // Act
            var result = _service.ValidateQr(request);

            // Assert
            Assert.False(result.IsValid);
            Assert.Equal("Invalid timestamp format (ticks).", result.Message);
        }
    }
}
