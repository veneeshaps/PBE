using System;
using AttendanceService.Application.Services;
using AttendanceService.Application.Interfaces;
using Entities;
using Microsoft.EntityFrameworkCore;
using AttendanceService.Infrastructure;
using AttendanceService.Application.services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("EPAM_TRAINING_PORTAL")));

// Register your application services
builder.Services.AddScoped<IAttendanceServices, AttendanceServices>();
builder.Services.AddScoped<IQRCodeService, QRCodeService>();
builder.Services.AddScoped<IUserAttendanceService, UserAttendanceService>();
builder.Services.AddInfrastructureServices(builder.Configuration);
builder.Services.AddScoped<IAttendanceSer, AttendanceSer>();
builder.Services.AddScoped<IQrValidationService, QrValidationService>();

// ? Allow all origins, headers, and methods (for dev/testing)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});


var app = builder.Build();

// Use Swagger UI
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Event QR Code API v1");
});

// ? Enable CORS middleware (MUST be before UseAuthorization)
app.UseCors("AllowAll");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

await app.RunAsync();
