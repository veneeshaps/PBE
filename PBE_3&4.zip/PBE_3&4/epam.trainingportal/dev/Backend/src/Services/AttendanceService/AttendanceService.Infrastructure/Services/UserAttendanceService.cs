﻿using Entities;
using Microsoft.EntityFrameworkCore;
using AttendanceService.Application.Interfaces;

public class UserAttendanceService : IUserAttendanceService
{
    private readonly ApplicationDbContext _context;

    public UserAttendanceService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<(List<AttendanceDto> Records, int TotalCount)> GetFilteredAttendanceAsync(AttendanceFilterRequest request)
    {
        if ((request.StartDate.HasValue && request.EndDate.HasValue && request.StartDate.Value > request.EndDate.Value) ||
        (request.StartDate.HasValue && request.StartDate.Value > DateTime.Now) ||
        (request.EndDate.HasValue && request.EndDate.Value > DateTime.Now))
        {
            return (new List<AttendanceDto>(), 0); 
        }
        var query = _context.Attendances
            .Where(a => a.EmployeeId == request.EmployeeId && a.ScheduledEvent.Status == "completed")
            .Include(a => a.ScheduledEvent)
            .AsQueryable();

        if (request.StartDate.HasValue)
            query = query.Where(a => a.ScheduledEvent.Date >= request.StartDate.Value.Date);
        if (request.EndDate.HasValue)
            query = query.Where(a => a.ScheduledEvent.Date <= request.EndDate.Value.Date);

        if (!string.IsNullOrWhiteSpace(request.EventName))
        {
            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Name == request.EventName);
            if (eventEntity != null)
            {
                query = query.Where(a => a.ScheduledEvent.EventId == eventEntity.EventId);
            }
            else if (request.EventName.Equals("other", StringComparison.OrdinalIgnoreCase))
            {
                var customEventId = await _context.Events
                    .Where(e => e.Name == "Custom")
                    .Select(e => e.EventId)
                    .FirstOrDefaultAsync();

                query = query.Where(a => a.ScheduledEvent.EventId == customEventId);
            }
            else
            {
                query = query.Where(a => a.ScheduledEvent.Name.Contains(request.EventName));
            }
        }

        if (request.IsPresent.HasValue)
            query = query.Where(a => a.IsPresent == request.IsPresent.Value);

        query = request.SortDirection == "asc"
            ? query.OrderBy(a => a.ScheduledEvent.Date)
            : query.OrderByDescending(a => a.ScheduledEvent.Date);

        var result = await query
            .Select(a => new AttendanceDto
            {
                Name = a.ScheduledEvent.Name,
                Date = a.ScheduledEvent.Date,
                StartTime = a.ScheduledEvent.StartTime,
                EndTime = a.ScheduledEvent.EndTime,
                IsPresent = a.IsPresent,
                EventId = a.ScheduledEvent.EventId
            })
            .ToListAsync();

        return (result, result.Count);
    }

    public async Task<object> GetAttendanceHistoryAsync(int employeeId)
    {
        var records = await _context.Attendances
            .Where(a => a.EmployeeId == employeeId && a.ScheduledEvent.Status == "Completed")
            .Include(a => a.ScheduledEvent)
            .ThenInclude(se => se.Event)
            .Select(a => new AttendanceDto
            {
                Name = a.ScheduledEvent.Name,
                Date = a.ScheduledEvent.Date,
                StartTime = a.ScheduledEvent.StartTime,
                EndTime = a.ScheduledEvent.EndTime,
                IsPresent = a.IsPresent,
                EventId = a.ScheduledEvent.EventId
            })
            .ToListAsync();

        var total = records.Count;
        var present = records.Count(a => a.IsPresent);
        var percentage = total == 0 ? 0 : (int)((double)present / total * 100);

        var eventStats = records
            .GroupBy(r => r.EventId)
            .Select(g => new
            {
                EventId = g.Key,
                EventName = _context.Events.Where(e => e.EventId == g.Key).Select(e => e.Name).FirstOrDefault(),
                TotalEvents = g.Count(),
                EventsAttended = g.Count(e => e.IsPresent),
                AttendancePercentage = g.Count() == 0 ? 0 : (int)((double)g.Count(e => e.IsPresent) / g.Count() * 100)
            })
            .ToList();

        return new
        {
            events = records,
            totalCount = total,
            eventsAttended = present,
            attendancePercentage = percentage,
            eventTypeStats = eventStats
        };
    }

    public async Task<List<EventNameDto>> GetAllEventNamesAsync()
    {
        return await _context.Events
            .Select(e => new EventNameDto
            {
                Name = e.Name
            })
            .ToListAsync();
    }
}
