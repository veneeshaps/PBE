﻿namespace AttendanceService.Application
{
    public class Class1
    {

    }
}
