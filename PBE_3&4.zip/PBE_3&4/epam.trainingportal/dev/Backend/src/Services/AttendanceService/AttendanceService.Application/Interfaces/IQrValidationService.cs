﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AttendanceService.Application.DTOs;

namespace AttendanceService.Application.Interfaces
{
    public interface IQrValidationService
    {
        QrValidationResponseDto ValidateQr(QrValidationRequestDto request);
    }
}
