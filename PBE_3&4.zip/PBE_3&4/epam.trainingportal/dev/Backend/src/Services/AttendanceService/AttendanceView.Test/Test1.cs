using AttendanceService.Api.Controllers;
using AttendanceService.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace AttendanceView.Test
{
    [TestClass]
    public sealed class Test1
    {
        private Mock<IAttendanceSer> _mockService;
        private AdminAttendanceViewController _controller;

        [TestInitialize]
        public void Setup()
        {
            _mockService = new Mock<IAttendanceSer>();

            // Mock the service methods
            _mockService.Setup(s => s.GetCurrentEventAttendance(It.IsAny<string>())).ReturnsAsync(new OkObjectResult("Mocked Attendance"));
            _mockService.Setup(s => s.GetAttendanceSummary(It.IsAny<string>())).ReturnsAsync(new OkObjectResult("Mocked Summary"));
            _mockService.Setup(s => s.GetAttendanceByScheduleName(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync((string email, string scheduleName) =>
                {
                    if (scheduleName == "Unknown Meeting")
                    {
                        return new NotFoundObjectResult($"Scheduled event with name '{scheduleName}' not found.");
                    }
                    return new OkObjectResult("Mocked Attendance by Schedule");
                });

            _controller = new AdminAttendanceViewController(_mockService.Object);
        }

        [TestMethod]
        public async Task GetCurrentEventAttendance_ReturnsOkResult()
        {
            // Act
            var result = await _controller.GetCurrentEventAttendance("sarthakravindra_chaure@epam.com");

            // Assert
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task GetAttendanceSummary_ReturnsSummary()
        {
            // Act
            var result = await _controller.GetAttendanceSummary("sarthakravindra_chaure@epam.com");

            // Assert
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task GetAttendanceByScheduleName_Valid_ReturnsOk()
        {
            // Act
            var result = await _controller.GetAttendanceByScheduleName("sarthakravindra_chaure@epam.com", "Coding Ambush");

            // Assert
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task GetAttendanceByScheduleName_InvalidName_ReturnsNotFound()
        {
            var result = await _controller.GetAttendanceByScheduleName("sarthakravindra_chaure@epam.com", "Unknown Meeting");

            // Assert
            Assert.IsInstanceOfType(result, typeof(NotFoundObjectResult));

            var notFoundResult = result as NotFoundObjectResult;
            Assert.AreEqual("Scheduled event with name 'Unknown Meeting' not found.", notFoundResult.Value);
        }
        

    }
}
