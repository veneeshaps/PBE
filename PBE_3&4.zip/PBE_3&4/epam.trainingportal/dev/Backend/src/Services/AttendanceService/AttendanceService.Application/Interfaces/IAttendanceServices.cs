﻿using AttendanceService.Application.Models.Dtos;
using AttendanceService.Application.Models.Requests;
using System.Threading.Tasks;

namespace AttendanceService.Application.Interfaces
{
    public interface IAttendanceServices
    {
        Task<AttendanceResultDto> MarkAttendanceAsync(MarkAttendanceRequest request);
    }
}
