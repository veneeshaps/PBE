﻿ public class EventNameDto
    {
        public string Name { get; set; } = string.Empty;
    }

