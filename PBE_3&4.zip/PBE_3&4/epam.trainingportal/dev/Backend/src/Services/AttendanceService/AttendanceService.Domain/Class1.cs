﻿namespace AttendanceService.Domain
{
    public class Class1
    {

    }
}
