﻿using AttendanceService.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Entities;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace AttendanceService.Application.Services
{
   public  class AttendanceSer : IAttendanceSer
    {
        private readonly ApplicationDbContext _context;

        public AttendanceSer(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> GetCurrentEventAttendance(string AdminMail)
        {
            int adminId = _context.Employees.Where(a => a.Email == AdminMail.ToLower()).Select(a => a.EmployeeId).FirstOrDefault();
            if (adminId == 0)
            {
                return new NotFoundObjectResult("No admin found.");
            }

            var now = DateTime.Now;
            var currentEvent = await _context.ScheduledEvents
                .FirstOrDefaultAsync(e =>
                    e.CreatedByEmployeeId == adminId &&
                    e.Date == now.Date &&
                    e.StartTime <= now.TimeOfDay &&
                    e.EndTime >= now.TimeOfDay);

            if (currentEvent == null)
                return new NotFoundObjectResult("No running event found for this admin.");

            var attendance = await _context.Attendances
                .Where(a => a.ScheduledEventId == currentEvent.ScheduledEventId)
                .Include(a => a.Employee)
                .ToListAsync();

            return new OkObjectResult(new
            {
                Event = new
                {
                    currentEvent.Name,
                    currentEvent.Date,
                    currentEvent.Status
                },
                Attendance = attendance.Select(a => new
                {
                    a.EmployeeId,
                    a.Employee.FirstName,
                    a.Employee.Email,
                    a.IsPresent
                })
            });
        }

        public async Task<IActionResult> GetAttendanceSummary(string AdminMail)
        {
            int adminId = _context.Employees.Where(a => a.Email == AdminMail.ToLower()).Select(a => a.EmployeeId).FirstOrDefault();
            if (adminId == 0)
            {
                return new NotFoundObjectResult("No admin found.");
            }

            var summary = await _context.ScheduledEvents
                .Where(e => e.CreatedByEmployeeId == adminId)
                .Select(e => new
                {
                    EventName = e.Name,
                    TotalInvited = _context.Attendances.Count(a => a.ScheduledEventId == e.ScheduledEventId),
                    PresentCount = _context.Attendances.Count(a => a.ScheduledEventId == e.ScheduledEventId && a.IsPresent),
                    AbsentCount = _context.Attendances.Count(a => a.ScheduledEventId == e.ScheduledEventId && !a.IsPresent)
                })
                .ToListAsync();

            if (!summary.Any())
                return new NotFoundObjectResult("No events found for this admin.");

            return new OkObjectResult(summary);
        }

        public async Task<IActionResult> GetAttendanceByScheduleName(string AdminMail, string scheduleEventName)
        {
            int adminId = _context.Employees.Where(a => a.Email == AdminMail.ToLower()).Select(a => a.EmployeeId).FirstOrDefault();
            if (adminId == 0)
            {
                return new NotFoundObjectResult("No admin found.");
            }

            var scheduledEvent = await _context.ScheduledEvents
                .FirstOrDefaultAsync(se =>
                    se.Name.ToLower() == scheduleEventName.ToLower() &&
                    se.CreatedByEmployeeId == adminId && se.Status == "Completed");

            if (scheduledEvent == null)
                return new NotFoundObjectResult($"Scheduled event with name '{scheduleEventName}' not found.");

            var attendance = await _context.Attendances
                .Where(a => a.ScheduledEventId == scheduledEvent.ScheduledEventId)
                .Include(a => a.Employee)
                .ToListAsync();

            return new OkObjectResult(new
            {
                Event = new
                {
                    scheduledEvent.Name,
                    scheduledEvent.Date,
                    scheduledEvent.Status
                },
                Attendance = attendance.Select(a => new
                {
                    a.EmployeeId,
                    a.Employee.FirstName,
                    a.Employee.Email,
                    a.IsPresent
                })
            });
        }
    }
}

