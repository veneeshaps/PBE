﻿using AttendanceService.Application.Interfaces;
using AttendanceService.Application.Models.Dtos;
using AttendanceService.Application.Models.Requests;
using Entities;
using Microsoft.EntityFrameworkCore;

namespace AttendanceService.Application.Services
{
    public class AttendanceServices(ApplicationDbContext context) : IAttendanceServices
    {
        private readonly ApplicationDbContext _context = context;

        public async Task<AttendanceResultDto> MarkAttendanceAsync(MarkAttendanceRequest request)
        {
            int eventId = request.EventId;
            int employeeId = request.EmployeeId;
            string? fingerprint = request.Fingerprint?.Trim();

            if (string.IsNullOrEmpty(fingerprint))
            {
                return new AttendanceResultDto
                {
                    Success = false,
                    Message = "Fingerprint is required for attendance verification."
                };
            }

            // 1. Validate Employee
            var employeeExists = await _context.Employees.AnyAsync(e => e.EmployeeId == employeeId);
            if (!employeeExists)
            {
                return new AttendanceResultDto { Success = false, Message = "Invalid Employee ID." };
            }

            // 2. Validate Event
            var eventExists = await _context.ScheduledEvents.AnyAsync(e => e.ScheduledEventId == eventId);
            if (!eventExists)
            {
                return new AttendanceResultDto { Success = false, Message = "Invalid Event ID." };
            }

            // 3. Check if fingerprint already used for this event
            var fingerprintUsed = await _context.DeviceAttendanceLogs
                .AnyAsync(d => d.ScheduledEventId == eventId && d.VisitorId == fingerprint);

            if (fingerprintUsed)
            {
                return new AttendanceResultDto
                {
                    Success = false,
                    Message = "Attendance already marked using this device. Possible proxy attempt."
                };
            }

            // 4. Check if employee already marked attendance
            var alreadyMarked = await _context.Attendances
                .AnyAsync(a => a.ScheduledEventId == eventId && a.EmployeeId == employeeId);

            if (alreadyMarked)
            {
                // ❗️Still log the fingerprint for auditing
                _context.DeviceAttendanceLogs.Add(new DeviceAttendanceLog
                {
                    ScheduledEventId = eventId,
                    EmployeeId = employeeId,
                    VisitorId = fingerprint,
                    Timestamp = DateTime.UtcNow
                });

                await _context.SaveChangesAsync();

                return new AttendanceResultDto
                {
                    Success = false,
                    Message = "Attendance already marked!"
                };
            }

            // 5. Mark Attendance
            _context.Attendances.Add(new Attendance
            {
                ScheduledEventId = eventId,
                EmployeeId = employeeId,
                IsPresent = true
            });

            // 6. Log Device Fingerprint
            _context.DeviceAttendanceLogs.Add(new DeviceAttendanceLog
            {
                ScheduledEventId = eventId,
                EmployeeId = employeeId,
                VisitorId = fingerprint,
                Timestamp = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();

            return new AttendanceResultDto
            {
                Success = true,
                Message = "Attendance marked successfully!"
            };
        }

    }
}
