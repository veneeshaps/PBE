using AttendanceService.Application.services;
using Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace AttendanceService.API.Controllers
{
    [Route("api/qrcode")]
    [ApiController]
    public class QRCodeController : ControllerBase
    {
        private readonly IQRCodeService _qrCodeService;
        private readonly ApplicationDbContext _context;

        public QRCodeController(IQRCodeService qrCodeService, ApplicationDbContext context)

        {
            _qrCodeService = qrCodeService;
            _context = context;
        }

        // ? Generate QR Code
        [HttpGet("generate")]
        public IActionResult GenerateQRCode([FromQuery] string eventId)
        {
            if (string.IsNullOrEmpty(eventId))
            {
                return BadRequest(new { error = "Event ID is required." });
            }

            if (!int.TryParse(eventId, out int parsedEventId))
            {
                return BadRequest(new { error = "Event ID must be a valid integer." });
            }

            try
            {
                // Check if the event exists and its status is Ongoing
                var eventStatus = _context.ScheduledEvents
                    .Where(se => se.ScheduledEventId == parsedEventId)
                    .Select(se => se.Status)
                    .FirstOrDefault();

                if (eventStatus == null)
                {
                    return NotFound(new { error = $"Event with ID '{parsedEventId}' does not exist." });
                }

                if (eventStatus != "Ongoing")
                {
                    return BadRequest(new { error = "QR Code generation is only allowed for ongoing events." });
                }

                // Generate the QR code
                var qrCode = _qrCodeService.GenerateQRCode(parsedEventId.ToString());
                return Ok(new { qrCode });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to generate QR Code.", details = ex.Message });
            }
        }




        // ? Decrypt QR Code
        [HttpGet("decrypt")]
        public IActionResult DecryptQRCode([FromQuery] string? encryptedData)
        {
            if (string.IsNullOrEmpty(encryptedData))
            {
                return BadRequest(new { error = "Encrypted data is required." });
            }

            try
            {
                var response = _qrCodeService.DecryptEventId(encryptedData);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = "Invalid or expired QR Code.", details = ex.Message });
            }
        }

        // ? Get All Event IDs (for dropdown)
        // ? Get All Ongoing Scheduled Event IDs (for dropdown)
        // ? Get all Ongoing Scheduled Event IDs
        [HttpGet("events")]
        public IActionResult GetOngoingScheduledEventIds()
        {
            try
            {
                var scheduledEventIds = _context.ScheduledEvents
                    .Where(se => se.Status == "Ongoing")
                    .Select(se => new
                    {
                        se.ScheduledEventId
                    })
                    .ToList();

                return Ok(scheduledEventIds);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to fetch scheduled events.", details = ex.Message });
            }
        }


    }
}
