﻿using System;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QRCoder;
using System.Security.Cryptography;

namespace AttendanceService.Application.services
{
    public class QRCodeService : IQRCodeService
    {
        private readonly IConfiguration _configuration;

        public QRCodeService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // ✅ Generate QR Code dynamically
        public string GenerateQRCode(string eventId)
        {
            string encryptionKey = _configuration["Encryption:Key"] ?? throw new InvalidOperationException("Encryption key is missing.");
            string encryptionIv = _configuration["Encryption:IV"] ?? throw new InvalidOperationException("Encryption IV is missing.");


            if (string.IsNullOrEmpty(encryptionKey) || string.IsNullOrEmpty(encryptionIv))
            {
                throw new Exception("Encryption key or IV is not configured.");
            }

            byte[] keyBytes = Convert.FromBase64String(encryptionKey);
            byte[] ivBytes = Convert.FromBase64String(encryptionIv);

            // Add dynamic content: Combine Event ID with current timestamp
            string dynamicContent = $"{eventId}_{DateTime.UtcNow.Ticks}";

            // Encrypt the dynamic content
            string encryptedDynamicContent = EncryptEventId(dynamicContent, keyBytes, ivBytes);

            // Generate QR Code
            using (var qrGenerator = new QRCodeGenerator())
            {
                QRCodeData qrCodeData = qrGenerator.CreateQrCode(encryptedDynamicContent, QRCodeGenerator.ECCLevel.Q);
                using (var qrCode = new PngByteQRCode(qrCodeData))
                {
                    byte[] qrCodeBytes = qrCode.GetGraphic(20);
                    return Convert.ToBase64String(qrCodeBytes); // Return as Base64-encoded image
                }
            }
        }

        // ✅ Encrypt the event ID (plus timestamp) using AES
        private static string EncryptEventId(string content, byte[] key, byte[] iv)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;

                using (var encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
                {
                    byte[] inputBytes = Encoding.UTF8.GetBytes(content);
                    byte[] encryptedBytes = encryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);
                    return Convert.ToBase64String(encryptedBytes);
                }
            }
        }

        // ✅ Decrypt the encrypted QR Code content (for decoding/scanning)
        public object DecryptEventId(string encryptedContent)
        {
            string encryptionKey = _configuration["Encryption:Key"]
    ?? throw new InvalidOperationException("Encryption key not found in configuration.");

            string encryptionIv = _configuration["Encryption:IV"]
                ?? throw new InvalidOperationException("Encryption IV not found in configuration.");


            if (string.IsNullOrEmpty(encryptionKey) || string.IsNullOrEmpty(encryptionIv))
            {
                throw new Exception("Encryption key or IV is not configured.");
            }

            byte[] keyBytes = Convert.FromBase64String(encryptionKey);
            byte[] ivBytes = Convert.FromBase64String(encryptionIv);

            using (var aes = Aes.Create())
            {
                aes.Key = keyBytes;
                aes.IV = ivBytes;

                using (var decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                {
                    byte[] encryptedBytes = Convert.FromBase64String(encryptedContent);
                    byte[] decryptedBytes = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);

                    string decryptedContent = Encoding.UTF8.GetString(decryptedBytes);

                    // Validate and split decrypted content (Event ID and timestamp)
                    string[] parts = decryptedContent.Split('_');
                    if (parts.Length != 2)
                    {
                        throw new Exception("Invalid QR code format.");
                    }

                    string eventId = parts[0];
                    long timestamp = long.Parse(parts[1]); // decrypting timestamp from QR !!!!

                    // Check if the QR code is expired (more than 3 seconds old)
                    long currentTicks = DateTime.UtcNow.Ticks;
                    if (Math.Abs(currentTicks - timestamp) > TimeSpan.FromSeconds(3).Ticks)
                    {
                        throw new Exception("QR Code has expired.");
                    }

                    return new {eventId,timestamp}; // Return the valid Event ID
                }
            }
        }
    }
}
