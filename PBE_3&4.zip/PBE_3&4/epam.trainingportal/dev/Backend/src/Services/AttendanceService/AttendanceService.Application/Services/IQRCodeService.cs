﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttendanceService.Application.services
{
    public interface IQRCodeService
    {
        string GenerateQRCode(string eventId);
        object DecryptEventId(string encryptedContent);
    }
}
