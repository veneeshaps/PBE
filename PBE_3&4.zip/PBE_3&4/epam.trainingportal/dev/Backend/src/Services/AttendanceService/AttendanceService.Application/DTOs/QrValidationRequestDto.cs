﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttendanceService.Application.DTOs
{
    public class QrValidationRequestDto
    {
        public int EventId { get; set; }
        public long Timestamp { get; set; } // Ticks from QR code
    }
}
