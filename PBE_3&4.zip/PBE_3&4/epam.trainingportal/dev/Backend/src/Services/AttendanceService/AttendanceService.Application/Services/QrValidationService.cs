﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AttendanceService.Application.DTOs;
using AttendanceService.Application.Interfaces;

namespace AttendanceService.Application.Services
{
    public class QrValidationService : IQrValidationService
    {
        public QrValidationResponseDto ValidateQr(QrValidationRequestDto request)
        {
            try
            {
                var qrDateTime = new DateTime(request.Timestamp, DateTimeKind.Utc);
                var currentUtc = DateTime.UtcNow;
                var timeDifference = (currentUtc - qrDateTime).TotalSeconds;

                if (Math.Abs(timeDifference) <= 3)
                {
                    return new QrValidationResponseDto
                    {
                        IsValid = true
                    };
                }

                return new QrValidationResponseDto
                {
                    IsValid = false,
                    Message = "QR code has expired or is too early."
                };
            }
            catch (ArgumentOutOfRangeException)
            {
                return new QrValidationResponseDto
                {
                    IsValid = false,
                    Message = "Invalid timestamp format (ticks)."
                };
            }
        }
    }
}
