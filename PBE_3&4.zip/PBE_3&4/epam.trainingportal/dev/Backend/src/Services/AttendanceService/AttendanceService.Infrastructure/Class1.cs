﻿namespace AttendanceService.Infrastructure
{
    public class Class1
    {

    }
}
