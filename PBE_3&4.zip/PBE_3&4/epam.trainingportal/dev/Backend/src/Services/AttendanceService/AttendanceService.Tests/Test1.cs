﻿using AttendanceService.Application.Interfaces;
using AttendanceService.Application.Models.Dtos;
using AttendanceService.Application.Models.Requests;
using AttendanceService.API.Controllers;
using Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using AttendanceService.Application.Services;

namespace AttendanceService.Tests
{
    [TestClass]
    public class AttendanceServiceTests
    {
        private ApplicationDbContext _context = null!;
        private AttendanceServices _attendanceService = null!;

        [TestInitialize]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDbContext(options);
            _attendanceService = new AttendanceServices(_context);
        }

        [TestCleanup]
        public void Cleanup()
        {
            _context.Dispose();
        }

        [TestMethod]
        public async Task MarkAttendanceAsync_ShouldReturnSuccess_WhenValidRequest()
        {
            var employeeId = 1;
            var eventId = 1;
            var domainId = 10;

            _context.Domains.Add(new Domain { DomainId = domainId, Name = "AI" });

            _context.Employees.Add(new Employee
            {
                EmployeeId = employeeId,
                DomainId = domainId,
                Email = "test@email.com",
                FirstName = "John",
                LastName = "Doe"
            });

            _context.ScheduledEvents.Add(new ScheduledEvent
            {
                ScheduledEventId = eventId,
                Name = "Tech Talk",
                Status = "Scheduled"
            });

            _context.ScheduledEventDomains.Add(new ScheduledEventDomain
            {
                ScheduledEventId = eventId,
                DomainId = domainId
            });

            await _context.SaveChangesAsync();

            var request = new MarkAttendanceRequest
            {
                EmployeeId = employeeId,
                EventId = eventId,
                Fingerprint = "device-fingerprint"
            };

            var result = await _attendanceService.MarkAttendanceAsync(request);

            Assert.IsTrue(result.Success);
            Assert.AreEqual("Attendance marked successfully!", result.Message);
        }

        [TestMethod]
        public async Task MarkAttendanceAsync_ShouldReturnFailure_WhenAlreadyMarked()
        {
            var employeeId = 1;
            var eventId = 1;
            var domainId = 5;
            var fingerprint = "device-fingerprint";

            _context.Domains.Add(new Domain { DomainId = domainId, Name = "Web" });

            _context.Employees.Add(new Employee
            {
                EmployeeId = employeeId,
                DomainId = domainId,
                Email = "already@marked.com",
                FirstName = "Already",
                LastName = "Marked"
            });

            _context.ScheduledEvents.Add(new ScheduledEvent
            {
                ScheduledEventId = eventId,
                Name = "Web Event",
                Status = "Completed"
            });

            _context.ScheduledEventDomains.Add(new ScheduledEventDomain
            {
                ScheduledEventId = eventId,
                DomainId = domainId
            });

            _context.Attendances.Add(new Attendance
            {
                EmployeeId = employeeId,
                ScheduledEventId = eventId,
                IsPresent = true
            });

            await _context.SaveChangesAsync();

            var request = new MarkAttendanceRequest
            {
                EmployeeId = employeeId,
                EventId = eventId,
                Fingerprint = fingerprint
            };

            var result = await _attendanceService.MarkAttendanceAsync(request);

            Assert.IsFalse(result.Success);
            Assert.AreEqual("Attendance already marked!", result.Message);
            Assert.IsTrue(await _context.DeviceAttendanceLogs.AnyAsync(l => l.VisitorId == fingerprint));
        }

        [TestMethod]
        public async Task MarkAttendanceAsync_ShouldReturnFailure_WhenInvalidEmployee()
        {
            var eventId = 1;

            _context.ScheduledEvents.Add(new ScheduledEvent
            {
                ScheduledEventId = eventId,
                Name = "Event X",
                Status = "Scheduled"
            });

            await _context.SaveChangesAsync();

            var request = new MarkAttendanceRequest
            {
                EventId = eventId,
                EmployeeId = 999,
                Fingerprint = "abc123"
            };

            var result = await _attendanceService.MarkAttendanceAsync(request);

            Assert.IsFalse(result.Success);
            Assert.AreEqual("Invalid Employee ID.", result.Message);
        }

        [TestMethod]
        public async Task MarkAttendanceAsync_ShouldReturnFailure_WhenFingerprintMissing()
        {
            var request = new MarkAttendanceRequest
            {
                EmployeeId = 1,
                EventId = 1,
                Fingerprint = "   "
            };

            var result = await _attendanceService.MarkAttendanceAsync(request);

            Assert.IsFalse(result.Success);
            Assert.AreEqual("Fingerprint is required for attendance verification.", result.Message);
        }
    }

    [TestClass]
    public class AttendanceControllerTests
    {
        private Mock<IAttendanceServices> _mockService = null!;
        private AttendanceController _controller = null!;

        [TestInitialize]
        public void Setup()
        {
            _mockService = new Mock<IAttendanceServices>();
            _controller = new AttendanceController(_mockService.Object);
        }

        [TestMethod]
        public async Task MarkAttendance_ReturnsBadRequest_WhenFingerprintMissing()
        {
            var request = new MarkAttendanceRequest { EmployeeId = 1, EventId = 1, Fingerprint = null! };

            var result = await _controller.MarkAttendance(request);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task MarkAttendance_ReturnsOk_WhenSuccessful()
        {
            var request = new MarkAttendanceRequest { EmployeeId = 1, EventId = 1, Fingerprint = "abc" };

            _mockService.Setup(s => s.MarkAttendanceAsync(request))
                .ReturnsAsync(new AttendanceResultDto { Success = true, Message = "Marked" });

            var result = await _controller.MarkAttendance(request);

            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual("Marked", ((AttendanceResultDto)okResult!.Value!).Message);
        }

        [TestMethod]
        public async Task MarkAttendance_ReturnsBadRequest_WhenServiceFails()
        {
            var request = new MarkAttendanceRequest { EmployeeId = 1, EventId = 1, Fingerprint = "abc" };

            _mockService.Setup(s => s.MarkAttendanceAsync(request))
                .ReturnsAsync(new AttendanceResultDto { Success = false, Message = "Already marked" });

            var result = await _controller.MarkAttendance(request);

            var badRequestResult = result as BadRequestObjectResult;
            Assert.IsNotNull(badRequestResult);
            Assert.AreEqual("Already marked", ((AttendanceResultDto)badRequestResult!.Value!).Message);
        }
    }
}
