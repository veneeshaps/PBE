﻿public class AttendanceDto
{
    public string Name { get; set; }
    public DateTime Date { get; set; }
    public TimeSpan StartTime { get; set; }
    public TimeSpan EndTime { get; set; }
    public bool IsPresent { get; set; }
    public int EventId { get; set; }
}
