﻿using Xunit;
using Moq;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using AttendanceService.Api.Controllers;
using AttendanceService.Application.Interfaces;
using Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace UserAttendanceService.Tests.Controllers
{
    public class UserAttendanceControllerTests
    {
        private readonly Mock<IUserAttendanceService> _mockService;
        private readonly AttendanceController _controller;

        public UserAttendanceControllerTests()
        {
            _mockService = new Mock<IUserAttendanceService>();
            _controller = new AttendanceController(_mockService.Object);
        }

        
        [Fact]
        public async Task GetFilteredAttendance_ReturnsOkWithExpectedResult()
        {
            // Arrange
            int employeeId = 1;
            var request = new AttendanceFilterRequest
            {
                EmployeeId = employeeId,
                StartDate = DateTime.Today.AddDays(-7),
                EndDate = DateTime.Today,
                EventName = "Test Event",
                IsPresent = true,
                SortDirection = "asc"
            };

            var expected = new
            {
                events = new List<AttendanceDto>
        {
            new AttendanceDto
            {
                Name = "Event 1",
                Date = DateTime.Today,
                StartTime = TimeSpan.FromHours(9),
                EndTime = TimeSpan.FromHours(10),
                IsPresent = true,
                EventId = 1
            }
        },
                totalCount = 1
            };

            _mockService
              .Setup(s => s.GetFilteredAttendanceAsync(It.Is<AttendanceFilterRequest>(r =>
                  r.EmployeeId == employeeId &&
                  r.StartDate == request.StartDate &&
                  r.EndDate == request.EndDate &&
                  r.EventName == request.EventName &&
                  r.IsPresent == request.IsPresent &&
                  r.SortDirection == request.SortDirection)))
              .ReturnsAsync((expected.events, expected.totalCount));

            // Act
            var result = await _controller.GetFilteredAttendance(
                employeeId,
                request.StartDate,
                request.EndDate,
                request.EventName,
                request.IsPresent,
                request.SortDirection
            );

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult.StatusCode.Should().Be(200);
            okResult.Value.Should().BeEquivalentTo(expected);
        }



        [Fact]
        public async Task GetFilteredAttendance_WithNoResults_ReturnsOkWithZeroCount()
        {
            // Arrange
            int employeeId = 1;
            var request = new AttendanceFilterRequest
            {
                EmployeeId = employeeId,
                StartDate = DateTime.Today.AddDays(-30),
                EndDate = DateTime.Today.AddDays(-15),
                EventName = "Non-existent Event",
                IsPresent = true,
                SortDirection = "asc"
            };

            var expected = new
            {
                events = new List<AttendanceDto>(),
                totalCount = 0
            };

            _mockService
                .Setup(s => s.GetFilteredAttendanceAsync(It.Is<AttendanceFilterRequest>(r =>
                    r.EmployeeId == employeeId &&
                    r.StartDate == request.StartDate &&
                    r.EndDate == request.EndDate &&
                    r.EventName == request.EventName &&
                    r.IsPresent == request.IsPresent &&
                    r.SortDirection == request.SortDirection)))
                .ReturnsAsync((expected.events, expected.totalCount));

            // Act
            var result = await _controller.GetFilteredAttendance(
                employeeId,
                request.StartDate,
                request.EndDate,
                request.EventName,
                request.IsPresent,
                request.SortDirection
            );

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult.StatusCode.Should().Be(200);
            okResult.Value.Should().BeEquivalentTo(expected);
        }



        [Fact]
        public async Task GetFilteredAttendance_WithInvalidDateRange_ReturnsOkWithZeroCount()
        {
            // Arrange
            int employeeId = 1;
            var request = new AttendanceFilterRequest
            {
                EmployeeId = employeeId,
                StartDate = DateTime.Today.AddDays(5),  // Future StartDate
                EndDate = DateTime.Today.AddDays(2),
                EventName = "Test Event",
                IsPresent = true,
                SortDirection = "asc"
            };

            var expected = new
            {
                events = new List<AttendanceDto>(),
                totalCount = 0
            };

            _mockService
                .Setup(s => s.GetFilteredAttendanceAsync(It.Is<AttendanceFilterRequest>(r =>
                    r.EmployeeId == employeeId &&
                    r.StartDate == request.StartDate &&
                    r.EndDate == request.EndDate &&
                    r.EventName == request.EventName &&
                    r.IsPresent == request.IsPresent &&
                    r.SortDirection == request.SortDirection)))
                .ReturnsAsync((expected.events, expected.totalCount));

            // Act
            var result = await _controller.GetFilteredAttendance(
                employeeId,
                request.StartDate,
                request.EndDate,
                request.EventName,
                request.IsPresent,
                request.SortDirection
            );

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult.StatusCode.Should().Be(200);
            okResult.Value.Should().BeEquivalentTo(expected);
        }



        [Fact]
        public async Task GetAttendanceHistory_ReturnsOkWithData()
        {
            // Arrange
            int employeeId = 1;
            var expected = new { events = new List<AttendanceDto>(), totalCount = 0 };

            _mockService
                .Setup(s => s.GetAttendanceHistoryAsync(employeeId))
                .ReturnsAsync(expected);

            // Act
            var result = await _controller.GetAttendanceHistory(employeeId);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be(200);
            okResult.Value.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public async Task GetAttendanceHistory_WithNoEvents_ReturnsOkWithZeroCount()
        {
            // Arrange
            int employeeId = 1;
            var expected = new
            {
                events = new List<AttendanceDto>(),
                totalCount = 0,
                eventsAttended = 0,
                attendancePercentage = 0,
                eventTypeStats = new List<object>()
            };

            _mockService
                .Setup(s => s.GetAttendanceHistoryAsync(employeeId))
                .ReturnsAsync(expected);

            // Act
            var result = await _controller.GetAttendanceHistory(employeeId);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be(200);
            okResult.Value.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public async Task GetAllEventNames_ReturnsOkWithList()
        {
            // Arrange
            var eventList = new List<EventNameDto>
            {
                new EventNameDto { Name = "Hackathon" },
                new EventNameDto { Name = "Workshop" }
            };

            _mockService
                .Setup(s => s.GetAllEventNamesAsync())
                .ReturnsAsync(eventList);

            // Act
            var result = await _controller.GetAllEventNames();

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be(200);
            okResult.Value.Should().BeEquivalentTo(eventList);
        }

        [Fact]
        public async Task GetAllEventNames_WithNoEvents_ReturnsEmptyList()
        {
            // Arrange
            var eventList = new List<EventNameDto>();

            _mockService
                .Setup(s => s.GetAllEventNamesAsync())
                .ReturnsAsync(eventList);

            // Act
            var result = await _controller.GetAllEventNames();

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be(200);
            okResult.Value.Should().BeEquivalentTo(eventList);
        }
    }
}
