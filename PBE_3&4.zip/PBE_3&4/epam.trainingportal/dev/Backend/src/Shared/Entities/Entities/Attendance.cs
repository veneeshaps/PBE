﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entities {
    public class Attendance {
        [Key, Column(Order = 0)]
        public int ScheduledEventId { get; set; }

        [Key, Column(Order = 1)]
        public int EmployeeId { get; set; }

        public bool IsPresent { get; set; }

        public ScheduledEvent? ScheduledEvent { get; set; }
        public Employee? Employee { get; set; }
    }
}
