﻿using Entities;

namespace Entities
{
    public class DeviceAttendanceLog
    {
        public int Id { get; set; }
        public int ScheduledEventId { get; set; }
        public int EmployeeId { get; set; }
        public string? VisitorId { get; set; }
        public DateTime Timestamp { get; set; }

        public Employee? Employee { get; set; }
        public ScheduledEvent? ScheduledEvent { get; set; }
    }
}

