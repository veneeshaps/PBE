﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entities {
    public class Employee {
        [Key]
        public int EmployeeId { get; set; }

        [Required, EmailAddress]
        public string? Email { get; set; }

        [Required, MaxLength(50)]
        public string? FirstName { get; set; }

        [Required, MaxLength(50)]
        public string? LastName { get; set; }

        [ForeignKey("Domain")]
        public int DomainId { get; set; }

        [ForeignKey("Role")]
        public int RoleId { get; set; }

        public DateTime DateOfJoining { get; set; }

        public bool IsDeactivated { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }

        public Domain? Domain { get; set; }

        public Role? Role { get; set; }

        public ICollection<Attendance>? Attendances { get; set; }

        public ICollection<ScheduledEvent>? CreatedScheduledEvents { get; set; }
    }
}
