﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entities {
    public class ScheduledEventDomain {
        [Key, Column(Order = 0)]
        public int ScheduledEventId { get; set; }

        [Key, Column(Order = 1)]
        public int DomainId { get; set; }

        public ScheduledEvent? ScheduledEvent { get; set; }

        public Domain? Domain { get; set; }
    }
}
