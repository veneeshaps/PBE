﻿using Entities;
using Microsoft.EntityFrameworkCore;

namespace Entities
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<ScheduledEvent> ScheduledEvents { get; set; }
        public DbSet<Attendance> Attendances { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Domain> Domains { get; set; }
        public DbSet<ScheduledEventDomain> ScheduledEventDomains { get; set; }
        public DbSet<DeviceAttendanceLog> DeviceAttendanceLogs { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ScheduledEvent>().ToTable("ScheduledEvents");
            modelBuilder.Entity<Attendance>().ToTable("Attendances");
            modelBuilder.Entity<Employee>().ToTable("Employees");
            modelBuilder.Entity<Role>().ToTable("Roles");
            modelBuilder.Entity<Domain>().ToTable("Domains");
            modelBuilder.Entity<Event>().ToTable("Events");
            modelBuilder.Entity<ScheduledEventDomain>().ToTable("ScheduledEventDomains");
            modelBuilder.Entity<DeviceAttendanceLog>().ToTable("DeviceAttendanceLogs");

            // Composite keys
            modelBuilder.Entity<ScheduledEventDomain>()
                .HasKey(se => new { se.ScheduledEventId, se.DomainId });

            modelBuilder.Entity<Attendance>()
                .HasKey(a => new { a.ScheduledEventId, a.EmployeeId });

            // Attendance FK Relationships
            modelBuilder.Entity<Attendance>()
                .HasOne(a => a.Employee)
                .WithMany(e => e.Attendances)
                .HasForeignKey(a => a.EmployeeId);

            modelBuilder.Entity<Attendance>()
                .HasOne(a => a.ScheduledEvent)
                .WithMany(se => se.Attendances)
                .HasForeignKey(a => a.ScheduledEventId);

            // Employee relationships
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Role)
                .WithMany(r => r.Employees)
                .HasForeignKey(e => e.RoleId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Domain)
                .WithMany(d => d.Employees)
                .HasForeignKey(e => e.DomainId)
                .OnDelete(DeleteBehavior.Restrict);

            // ScheduledEvent relationships
            modelBuilder.Entity<ScheduledEvent>()
                .HasOne(se => se.CreatedByEmployee)
                .WithMany(e => e.CreatedScheduledEvents)
                .HasForeignKey(se => se.CreatedByEmployeeId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<ScheduledEvent>()
                .HasOne(se => se.Event)
                .WithMany(e => e.ScheduledEvents)
                .HasForeignKey(se => se.EventId);

            modelBuilder.Entity<ScheduledEvent>()
                .Property(e => e.StartTime)
                .HasConversion(v => v, v => v);

            modelBuilder.Entity<ScheduledEvent>()
                .Property(e => e.EndTime)
                .HasConversion(v => v, v => v);

            modelBuilder.Entity<DeviceAttendanceLog>()
                .HasOne(d => d.Employee)
                .WithMany()
                .HasForeignKey(d => d.EmployeeId);

            modelBuilder.Entity<DeviceAttendanceLog>()
                .HasOne(d => d.ScheduledEvent)
                .WithMany()
                .HasForeignKey(d => d.ScheduledEventId);

            base.OnModelCreating(modelBuilder);
        }

    }
}
