export const environment = {
    production: false,
    apiBaseUrl: 'http://localhost:5085',
    apiBaseUrlForAttendance: 'https://localhost:7004',
};