export const environment = {
    production: true,
    apiBaseUrl: 'https://your-api.com',
};
  