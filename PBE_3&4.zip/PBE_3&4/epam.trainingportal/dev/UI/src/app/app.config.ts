import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { provideMsal } from './shared/components/auth/msal.provider';
import { routes } from './app.routes';
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { attendanceReducer } from './features/user/store/UserAttendance/UserAttendance.reducers';
import { AttendanceEffects } from './features/user/store/UserAttendance/UserAttendance.effects';
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { employeeReducer } from './features/admin/store/employee.reducer';
import { EmployeeEffects } from './features/admin/store';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideHttpClient(withInterceptorsFromDi()),
    provideRouter(routes),
    provideStore({
      attendance: attendanceReducer,
      employee: employeeReducer
    }),
    provideEffects([
      AttendanceEffects,
      EmployeeEffects
    ]),
    provideClientHydration(withEventReplay()),
    provideMsal()
  ]
};
