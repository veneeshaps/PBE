import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthComponent } from '../auth/auth.component';

interface MenuOption {
	label: string;
	icon: string;
	route: string;
}

@Component({
	selector: 'app-sidenav',
	imports: [CommonModule, RouterLink, AuthComponent],
	templateUrl: './sidenav.component.html',
	styleUrls: ['./sidenav.component.css'],
})
export class SidenavComponent {
	isMobileMenuOpen = false;

	role: 'admin' | 'user' = 'admin';

	// Admin menu options
	adminMenuOptions: MenuOption[] = [
		{
			label: 'Admin Dashboard',
			icon: 'M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z',
			route: 'dashboard',
		},
		{
            label: 'Search Users',
            icon: 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
            route: '/user',
        },
		{
			label: 'Profiles',
			icon: 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
			route: '/profiles',
		},
		{
			label: 'Events',
			icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
			route: 'admin/events',
		},
		{
			label: 'Attendance',
			icon: 'M9 6a3 3 0 11-6 0 3 3 0 016 0z M20 11a2 2 0 00-2-2h-2V7a4 4 0 00-8 0v4H6a2 2 0 00-2 2v7a2 2 0 002 2h12a2 2 0 002-2v-7z',
			route: 'attendance',
		},
		{
			label: 'User Dashboard',
			icon: 'M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z',
			route: 'user/dashboard',
		},
		{
			label: 'Reports',
			icon: 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
			route: '/reports',
		},
		{
			label: 'Add Profile',
			icon: 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
			route: '/users',
		},

	];

	// User menu 7 GU\ZAnoptions
	userMenuOptions: MenuOption[] = [
		{
			label: 'MarkAttendance',
			icon: 'M9 6a3 3 0 11-6 0 3 3 0 016 0z M20 11a2 2 0 00-2-2h-2V7a4 4 0 00-8 0v4H6a2 2 0 00-2 2v7a2 2 0 002 2h12a2 2 0 002-2v-7z',
			route: 'markAttendance',
		},
		{
			label: 'Dashboard',
			icon: 'M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z',
			route: '/dashboard',
		},
		{
			label: 'My Profile',
			icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0z M12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z',
			route: '/profile',
		},
		{
			label: 'Tasks',
			icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2',
			route: '/tasks',
		},
	];

	get menuOptions(): MenuOption[] {
		return this.role === 'admin'
			? this.adminMenuOptions
			: this.userMenuOptions;
	}

	toggleMobileMenu() {
		this.isMobileMenuOpen = !this.isMobileMenuOpen;
	}

	closeMobileMenu() {
		this.isMobileMenuOpen = false;
	}

	@HostListener('document:click', ['$event'])
	onClick(event: MouseEvent) {
		const target = event.target as HTMLElement;
		const clickedInsideSidebar = target.closest('#sidebar');
		const clickedMenuButton = target.closest('button');

		if (!clickedInsideSidebar && !clickedMenuButton) {
			this.closeMobileMenu();
		}
	}
}
