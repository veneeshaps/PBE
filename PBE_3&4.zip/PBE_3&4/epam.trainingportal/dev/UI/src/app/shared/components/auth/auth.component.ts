import { CommonModule } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { MsalService, MsalBroadcastService } from '@azure/msal-angular';
import { RedirectRequest, EventMessage, EventType, InteractionStatus } from '@azure/msal-browser';
import { filter, Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-auth',
  imports: [CommonModule],
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit, OnDestroy {

  isLoggedIn = false;
  showDropdown = false;
  
  private destroyed$ = new Subject<void>();

  constructor(
    private msalService: MsalService,
    private msalBroadcast: MsalBroadcastService
  ) {}

  ngOnInit(): void {
    this.msalBroadcast.inProgress$
      .pipe(
        filter(status => status === InteractionStatus.None),
        takeUntil(this.destroyed$)
      )
      .subscribe(() => {
        this.checkAuthState();
      });
  }

  handleRedirectResponse() 
  {
    this.msalService.handleRedirectObservable().subscribe({
			next: (result) => {
			  if (result && result.account) {
				console.log('Login succeeded via redirect', result);
				this.msalService.instance.setActiveAccount(result.account);
			  }
			},
			error: (error) => {
			  console.error('Redirect authentication failed', error);
			}
		  });
  }

  getUserName(): string
  {
    const activeAccount = this.msalService.instance.getActiveAccount();
    console.log('Active Account:', activeAccount);
    console.log('ID Token Claims:', activeAccount?.idTokenClaims);
    return activeAccount?.idTokenClaims?.name || activeAccount?.username || 'User';
  }

  checkAuthState() {
    return this.isLoggedIn = this.msalService.instance.getAllAccounts().length > 0;
  }

  login() {
    const loginRequest: RedirectRequest = {
      scopes: ['api://38a899eb-617d-4533-aab5-f0431a5e4329/access_as_user']
    };
    this.msalService.loginRedirect(loginRequest);
  }
  
  logout() {
    this.msalService.logoutRedirect({
      postLogoutRedirectUri: 'http://localhost:4200'
    });
  }

  toggleDropdown(show: boolean) {
    this.showDropdown = show;
  }

  ngOnDestroy(): void {
    this.destroyed$.next();
    this.destroyed$.complete();
  }
}