import { Configuration } from '@azure/msal-browser';

export const msalConfig: Configuration = {
  auth: {
    clientId: '29142079-5f52-4c18-ab00-ff09f9a52fdb',
    authority: 'https://login.microsoftonline.com/b41b72d0-4e9f-4c26-8a69-f949f367c91d',
    redirectUri: 'http://localhost:4200/',
  },
  cache: {
    cacheLocation: 'sessionStorage',
    storeAuthStateInCookie: false,
  }
};

export const protectedResources = {
  api: {
    endpoint: 'http://localhost:5085/*',
    scopes: ['api://38a899eb-617d-4533-aab5-f0431a5e4329/access_as_user'],
  },
};

export const loginRequest = {
  scopes: protectedResources.api.scopes,
};
