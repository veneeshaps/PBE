import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import {
  MsalModule,
  MsalService,
  MsalGuard,
  MsalBroadcastService,
  MsalInterceptor
} from '@azure/msal-angular';

import { PublicClientApplication, InteractionType } from '@azure/msal-browser';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { msalConfig, protectedResources, loginRequest } from './msal.config';

export function provideMsal(): ApplicationConfig['providers'] {
  return [
    importProvidersFrom(
      MsalModule.forRoot(
        new PublicClientApplication(msalConfig),
        {
          interactionType: InteractionType.Redirect,
          authRequest: loginRequest
        },
        {
          interactionType: InteractionType.Redirect,
          protectedResourceMap: new Map([
            [protectedResources.api.endpoint, protectedResources.api.scopes]
          ])
        }
      )
    ),
    MsalService,
    MsalBroadcastService,
    MsalGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    }
  ];
}
