// auth.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // Using dummy data for the logged-in user
  private currentUser = {
    id: 3,  // Dummy user ID
    name: 'John Doe',
    email: 'john.doe@example.com',
    role: 'user'     // You can add roles if needed
  };

  // Using BehaviorSubject to simulate observable state
  private currentUser$ = new BehaviorSubject<any>(this.currentUser);
  private isAuthenticated$ = new BehaviorSubject<boolean>(true);

  constructor() {
    console.log('AuthService initialized with dummy user');
  }

  // Get current user ID for QR scanning
  getCurrentUserId(): Observable<number> {
    return of(this.currentUser.id); // Just return the dummy ID
  }

  // Get current user details
  getCurrentUser(): Observable<any> {
    return of(this.currentUser); // Return the dummy user
  }

  // Check if user is authenticated (always true in this dummy implementation)
  isAuthenticated(): Observable<boolean> {
    return of(true); // Always return true for dummy implementation
  }

  // Check if user is authorized (always true in this dummy implementation)
  isAuthorized(): Observable<boolean> {
    return of(true); // Always return true for dummy implementation
  }

  // Dummy logout method (won't actually do anything in this implementation)
  logout(): void {
    console.log('Dummy logout called - no action taken');
  }

  // Dummy token getter (if your backend expects one)
  getAuthToken(): Observable<string> {
    return of('dummy-jwt-token-xyz123'); // Return dummy token
  }
}