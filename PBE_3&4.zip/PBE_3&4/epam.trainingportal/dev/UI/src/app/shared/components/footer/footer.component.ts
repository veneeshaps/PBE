import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
	selector: 'app-footer',
	standalone: true,
	imports: [CommonModule, RouterModule],
	templateUrl: './footer.component.html',
	styleUrl: './footer.component.css',
})
export class FooterComponent {
	currentYear: number = new Date().getFullYear();

	links = [
		{
			text: 'Privacy Policy',
			url: 'https://privacy.epam.com/core/interaction/showpolicy?type=CommonPrivacyPolicy',
		},
		{
			text: 'Privacy Notice',
			url: 'https://privacy.epam.com/core/interaction/showpolicy?type=CommonPrivacyNotice',
		},
		{ text: 'Cookies Policy', url: 'https://www.epam.com/cookie-policy' },
	];
}
