import { Injectable } from "@angular/core";
import { environment } from "../../../environments/environment";

interface Endpoints {
    admin: {
      adminAttendanceSummary: string;
    };
    user: {
      userProfile: string;
    };
  }
  
  interface Config {
    apiBaseUrl: string;
    endpoints: Endpoints;
  }
  
  @Injectable({
    providedIn: 'root'
  })
  export class ConfigService {
  
    private config: Config = {
      apiBaseUrl: environment.apiBaseUrl,
      endpoints: {
        admin: {
          adminAttendanceSummary: '/gateway/AdminAttendanceView/summary/{adminMail}',
        },
        user: {
          userProfile: '/gateway/UserProfile/{userId}',
        }
      }
    };
  
    constructor() { }
  
    getApiUrl<K extends keyof Endpoints>(category: K, endpointKey: keyof Endpoints[K], params: { [key: string]: string }): string {
      let url = this.config.apiBaseUrl + this.config.endpoints[category][endpointKey];
      
      Object.keys(params).forEach(param => {
        url = url.replace(`{${param}}`, params[param]);
      });
  
      return url;
    }
  }
  