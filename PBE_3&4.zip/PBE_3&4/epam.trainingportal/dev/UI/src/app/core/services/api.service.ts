import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private readonly API_BASE = 'https://localhost:7208';

  constructor(private http: HttpClient) {}

  getProfile<T = any>(): Observable<T> {
    return this.http.get<T>(`${this.API_BASE}/Auth`);
  }
}
