export interface DashboardStats {
    totalUsers: number;
    activeEvents: number;
  }
  