// src/app/core/models/employee.model.ts
export interface EmployeeDto {
    fullName: string;
    email: string;
    role: string;
    domain: string;
    status: string; // "Active" or "Inactive"
  }
  
  export interface ApiResponse<T> {
    success: boolean;
    statusCode: number;
    message: string;
    data: T;
    errors: any;
    timestamp: string;
    metadata: any;
  }
  