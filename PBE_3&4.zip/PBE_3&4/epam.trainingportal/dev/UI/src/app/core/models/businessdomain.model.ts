export interface BusinessDomain {
domainId: any;
	name: string;
  }
