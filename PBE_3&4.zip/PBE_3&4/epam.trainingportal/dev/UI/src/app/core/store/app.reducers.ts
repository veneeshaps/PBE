// // core/store/app.reducer.ts
// import { Action, ActionReducer, ActionReducerMap } from '@ngrx/store';
// import { AdminState, reducers as adminReducers } from '../../features/admin/store';

// export interface AppState {
//   admin: AdminState;
//   // Add other feature states here
// }

// export const reducers: ActionReducerMap<AppState> = {
//   admin: adminReducers as unknown as ActionReducer<AdminState, Action>
// };
import { ActionReducerMap } from '@ngrx/store';
import * as fromEmployee from '../../features/admin/store/employee.reducer';

export interface AppState {
  employee: fromEmployee.EmployeeState;
}

export const reducers: ActionReducerMap<AppState> = {
  employee: fromEmployee.employeeReducer
};

