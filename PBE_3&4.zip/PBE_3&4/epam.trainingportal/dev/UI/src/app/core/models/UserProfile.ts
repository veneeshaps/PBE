export interface UserProfile {
	employeeId: number;
	name: string;
	email: string;
	domain: string;
	role: string;
	isDeactivated: number;
}
