export interface Employee {
	email: string;
	employeeId: string;
	firstName: string;
	lastName: string;
	domainId: string;
	roleId: string;
	dateOfJoining: Date;
	isDeactivated: boolean;
	createdAt?: Date;
	updatedAt?: Date;
  }
