// src/app/core/services/employee.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { ApiResponse, EmployeeDto } from '../models/employee.model.search';


@Injectable({ providedIn: 'root' })
export class EmployeeService {
  private apiUrl = 'https://localhost:7252/api/Employee/search';

  constructor(private http: HttpClient) {}

  searchEmployees(name: string): Observable<EmployeeDto[]> {
    return this.http.get<ApiResponse<EmployeeDto[]>>(`${this.apiUrl}?name=${name}`).pipe(
      map((response) => response.data)
    );
  }
}
