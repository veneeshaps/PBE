export interface Domain {
	domainId: number;
	name: string;
  }
