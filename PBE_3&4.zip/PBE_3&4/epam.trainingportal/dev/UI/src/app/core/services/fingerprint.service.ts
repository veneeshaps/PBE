// src/app/core/services/fingerprint.service.ts
import { Injectable } from '@angular/core';
import FingerprintJS from '@fingerprintjs/fingerprintjs';

@Injectable({
  providedIn: 'root',
})
export class FingerprintService {
  private visitorId: string | null = null;

  async getFingerprint(): Promise<string> {
    if (this.visitorId) {
      return this.visitorId;
    }
    
    try {
      const fp = await FingerprintJS.load();
      const result = await fp.get();
      this.visitorId = result.visitorId;
      return this.visitorId;
    } catch (error) {
      console.error('Fingerprint error:', error);
      // Fallback to a random ID if fingerprint fails
      return this.generateFallbackId();
    }
  }

  private generateFallbackId(): string {
    return 'fallback-' + Math.random().toString(36).substring(2, 15);
  }
}