// app.routes.ts
import { RouterModule, Routes } from '@angular/router';
import { AuthComponent } from './shared/components/auth/auth.component';
import { AttendanceComponent } from './features/attendance/components/attendance/attendance.component';
import { UserAttendanceComponent } from './features/user/components/UserAttendance/UserAttendance.component';
import { UserDashBoardComponent } from './features/user/components/UserDashBoard/UserDashBoard.component'; import { QrCodeComponent } from './features/attendance/components/qr-code/qr-code.component';
import { adminRoutes } from './features/admin/admin.routes';
import { ViewProfilesComponent } from './features/admin/components/view-profiles/view-profiles.component';
import { MsalGuard } from '@azure/msal-angular';
import { DashboardComponent } from './features/admin/components/dashboard/dashboard.component';
import { ImportemployeeComponent } from './features/admin/components/importemployee/importemployee.component';
import { ATTENDANCE_ROUTES } from './features/attendance/attendance.routes';
import { EmployeeListComponent } from './features/admin/components/search-list/Search-list.component';
import { MarkAttendanceComponent } from './features/attendance/components/mark-attendance/mark-attendance.component';
import { QrScannerComponent } from './features/attendance/components/qr-scanner/qr-scanner.component';
export const routes: Routes = [
	{
		path: 'profiles',
		component: ViewProfilesComponent,
		canActivate: [MsalGuard]
	},
	{
		path : 'user',
		component : EmployeeListComponent,
		canActivate: [MsalGuard]
	},
	{
		path: 'admin',
		children: adminRoutes,
		canActivate: [MsalGuard]
	},
	{
		path: 'user/dashboard',
		component: UserDashBoardComponent,
		canActivate: [MsalGuard]
	},
	{
		path: 'attendance',
		loadChildren: () => import('./features/attendance/attendance.routes').then(m => m.ATTENDANCE_ROUTES),
		component: AttendanceComponent,
		canActivate: [MsalGuard]

	},
	{
		path: 'mark-attendance',
		component: MarkAttendanceComponent,
		canActivate: [MsalGuard],
	},
	{
		path: 'mark-attendance/qr-scan',
		component: QrScannerComponent,
		canActivate: [MsalGuard],
	},
	{
		path: 'dashboard',
		component: DashboardComponent,
		canActivate: [MsalGuard],
	},
	{
		path: 'users',
		component:ImportemployeeComponent,
		canActivate: [MsalGuard],
	},
	{
		path: 'dashboard/AttendanceHistory',
		component: UserAttendanceComponent,
		canActivate: [MsalGuard],
	},
	{
		path: 'qr',
		loadComponent: () =>
		  import('./features/attendance/components/qr-code/qr-code.component').then(
			(m) => m.QrCodeComponent
		  ),
	},
	{
		path: '**',
		loadComponent: () =>
			import('./shared/components/error/error.component').then(
				(m) => m.ErrorComponent
			),
	},
];
