import { Component, OnInit } from '@angular/core';
import { RouterOutlet, Router, NavigationStart } from '@angular/router';
import { FooterComponent } from './shared/components/footer/footer.component';
import { CommonModule } from '@angular/common';
import { SidenavComponent } from './shared/components/sidenav/sidenav.component';
import { MsalService } from '@azure/msal-angular';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from './core/services/config.service';


@Component({
	selector: 'app-root',
	imports: [RouterOutlet, CommonModule, FooterComponent, SidenavComponent],
	templateUrl: './app.component.html',
	styleUrl: './app.component.css',
})

export class AppComponent implements OnInit {

	title: string = 'EPAM • Training Portal';
	isAuthenticated: boolean = false;

	ngOnInit(): void {
		this.msalService.handleRedirectObservable().subscribe({
			next: (result) => {
				if (result && result.account) {
					console.log('Login succeeded via redirect', result);
					this.msalService.instance.setActiveAccount(result.account);
					this.isAuthenticated = true;
				}
			},
			error: (error) => {
				console.error('Redirect authentication failed', error);
			}
		});
	}

	constructor(private router: Router,
		private msalService: MsalService,
		private http: HttpClient,
		private configService: ConfigService) {

		this.router.events.subscribe((event) => {
			if (event instanceof NavigationStart) {
				this.isAuthenticated = this.msalService.instance.getAllAccounts().length > 0;
				console.log('isAuthenticated:', this.isAuthenticated);
			}
		});
	}

	// Mock function to simulate an API call
	getAdminSummary() {
		const adminMail = 'bob.dotnet@company.com';

		const Finalurl = this.configService.getApiUrl('admin', 'adminAttendanceSummary', { adminMail: adminMail });

		console.log('Final URL:', Finalurl);

		this.http.get(Finalurl).subscribe({
			next: (response) => {
				console.log('Response:', response);
				alert('Data fetched successfully! Check console.');
			},
			error: (err) => {
				console.error('Error:', err);
				alert('Failed to fetch data.');
			}
		});
	}
}
