import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';

@Component({
  selector: 'app-confirmation-dialog',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule],
  template: `
    <div class="p-6 max-w-sm">
      <h2 class="text-xl font-semibold mb-3">{{ data.title }}</h2>
      <p class="mb-6 text-gray-600">{{ data.message }}</p>
      <div class="flex justify-end space-x-3">
        <button 
          mat-button 
          (click)="onCancel()"
          class="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
          *ngIf="data.showCancel"
          type="button"
        >
          Cancel
        </button>
        <button 
          mat-button 
          (click)="onConfirm()"
          color="primary"
          class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          type="button"
        >
          {{ data.confirmText || 'OK' }}
        </button>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
    }
    button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  `]
})
export class ConfirmationDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      title: string;
      message: string;
      confirmText?: string;
      showCancel?: boolean;
    }
  ) {}

  onConfirm(): void {
    this.dialogRef.close(true);
  }

  onCancel(): void {
    this.dialogRef.close(false);
  }
}