import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { EventListComponent } from './event-list.component';
import { AdminEventsService } from '../../services/admin-events.service';
import { of, throwError } from 'rxjs';
import { ScheduledEvent } from '../../models/scheduled-event.model';
import { RouterTestingModule } from '@angular/router/testing';
import { LoadingSpinnerComponent } from '../app-loading/app-loading.component';
import { NotificationComponent } from '../notification/notification.component';
import { CommonModule } from '@angular/common';

describe('EventListComponent', () => {
  let component: EventListComponent;
  let fixture: ComponentFixture<EventListComponent>;
  let mockEventsService: jasmine.SpyObj<AdminEventsService>;

  const mockEvents: ScheduledEvent[] = [
    {
      scheduledEventId: 1,
      name: 'Event 1',
      date: '2023-01-01',
      startTime: '09:00',
      endTime: '10:00',
      domains: ['Domain 1'],
      eventType: 'Type 1',
      status: 'Scheduled'
    }
  ];

  beforeEach(async () => {
    mockEventsService = jasmine.createSpyObj('AdminEventsService', [
      'getEventsByAdmin',
      'deleteEvent',
      'exportAllEventsAsExcel'
    ]);

    await TestBed.configureTestingModule({
      imports: [CommonModule, RouterTestingModule],
      declarations: [EventListComponent, LoadingSpinnerComponent, NotificationComponent],
      providers: [
        { provide: AdminEventsService, useValue: mockEventsService }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(EventListComponent);
    component = fixture.componentInstance;
    mockEventsService.getEventsByAdmin.and.returnValue(of(mockEvents));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should load events on initialization', () => {
      expect(mockEventsService.getEventsByAdmin).toHaveBeenCalledWith(2);
      expect(component.events).toEqual(mockEvents);
    });
  });

  describe('loadEvents', () => {
    it('should load events successfully', () => {
      component.loadEvents();
      expect(component.isLoading).toBeTrue();
      expect(mockEventsService.getEventsByAdmin).toHaveBeenCalledWith(2);
    });

    it('should handle error when loading events', () => {
      const error = new Error('Failed to load events');
      mockEventsService.getEventsByAdmin.and.returnValue(throwError(() => error));
      spyOn(console, 'error');

      component.loadEvents();
      expect(component.isLoading).toBeFalse();
      expect(console.error).toHaveBeenCalledWith('Error loading events:', error);
    });
  });

  describe('deleteEvent', () => {
    it('should delete event after confirmation', () => {
      spyOn(window, 'confirm').and.returnValue(true);
      mockEventsService.deleteEvent.and.returnValue(of({}));

      component.deleteEvent(1);
      expect(mockEventsService.deleteEvent).toHaveBeenCalledWith(1);
    });

    it('should not delete event without confirmation', () => {
      spyOn(window, 'confirm').and.returnValue(false);
      component.deleteEvent(1);
      expect(mockEventsService.deleteEvent).not.toHaveBeenCalled();
    });

    it('should handle error when deleting event', () => {
      spyOn(window, 'confirm').and.returnValue(true);
      const error = new Error('Failed to delete');
      mockEventsService.deleteEvent.and.returnValue(throwError(() => error));
      spyOn(console, 'error');

      component.deleteEvent(1);
      expect(console.error).toHaveBeenCalledWith('Error deleting event:', error);
    });
  });

  describe('exportAllEvents', () => {
    it('should show notification when no events to export', () => {
      component.events = [];
      component.exportAllEvents();
      expect(component.notificationMessage).toBe('No events to export');
      expect(component.notificationType).toBe('info');
      expect(component.showNotification).toBeTrue();
    });

    it('should export events successfully', fakeAsync(() => {
      const mockBlob = new Blob(['test'], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      mockEventsService.exportAllEventsAsExcel.and.returnValue(of({
        blob: mockBlob,
        filename: 'events.xlsx'
      }));

      component.exportAllEvents();
      expect(component.isLoading).toBeTrue();
      expect(component.notificationMessage).toBe('Preparing export...');

      tick();
      expect(component.isLoading).toBeFalse();
      expect(component.notificationMessage).toBe('Export completed successfully!');
      expect(component.notificationType).toBe('success');
    }));

    it('should handle export error', () => {
      const error = new Error('Export failed');
      mockEventsService.exportAllEventsAsExcel.and.returnValue(throwError(() => error));
      spyOn(console, 'error');

      component.exportAllEvents();
      expect(console.error).toHaveBeenCalledWith('Failed to export:', error);
      expect(component.notificationMessage).toBe('Failed to export events. Please try again.');
      expect(component.notificationType).toBe('error');
    });
  });

  describe('showNotificationMessage', () => {
    it('should show notification and auto-hide', fakeAsync(() => {
      component.showNotificationMessage('Test message', 'info');
      expect(component.showNotification).toBeTrue();
      expect(component.notificationMessage).toBe('Test message');
      expect(component.notificationType).toBe('info');

      tick(2000);
      expect(component.showNotification).toBeFalse();
    }));
  });

  describe('getStatusColor', () => {
    it('should return correct color classes for each status', () => {
      expect(component.getStatusColor('Scheduled')).toBe('bg-blue-100 text-blue-800');
      expect(component.getStatusColor('In Progress')).toBe('bg-yellow-100 text-yellow-800');
      expect(component.getStatusColor('Complete')).toBe('bg-green-100 text-green-800');
      expect(component.getStatusColor('Cancelled')).toBe('bg-red-100 text-red-800');
      expect(component.getStatusColor('Unknown')).toBe('bg-gray-100 text-gray-800');
      expect(component.getStatusColor(undefined)).toBe('bg-gray-100 text-gray-800');
    });
  });
});
