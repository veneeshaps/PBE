// src/app/features/admin/admin.routes.ts
import { Routes } from '@angular/router';
import { EventListComponent } from './components/event-list/event-list.component';
import { CreateEventComponent } from './components/create-event/create-event.component';
import { EventFormComponent } from './components/event-form/event-form.component';
import { AdminBoardComponent } from './components/admin-board/admin-board.component';
import { ViewProfilesComponent } from './components/view-profiles/view-profiles.component';

export const adminRoutes: Routes = [

  {
    path: '',
    component: AdminBoardComponent,
    children: [
      { path: '', redirectTo: 'events', pathMatch: 'full' },
      { path: 'events', component: EventListComponent },
      { path: 'events/create', component: CreateEventComponent },
      { path: 'events/edit/:id', component: EventFormComponent },
    ]
  }
];
