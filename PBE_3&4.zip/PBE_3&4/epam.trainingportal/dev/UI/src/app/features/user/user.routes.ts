import { Routes } from '@angular/router';

export const USER_ROUTES: Routes = [];
