import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export interface DecryptedQrResponse {
  eventId: string;
  timestamp: string;
}

export interface QrValidationResponseDto {
  isValid: boolean;
  message?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {
  private apiUrl = 'https://localhost:7004/api/Attendance/mark';
  private validateApi = 'https://localhost:7004/api/Attendance/validate-qr';
  private decryptApi = 'https://localhost:7004/api/qrcode/decrypt';
  constructor(private http: HttpClient) {}

  /**
   * 1. Decrypts QR data.
   * 2. Validates it.
   * 3. Marks attendance if valid.
   */
  async processQrAndMarkAttendance(encryptedData: string, userId: string, deviceFingerprint: string): Promise<{success: boolean, message: string}> {
    // Step 1: Decrypt QR - if this fails, throw immediately
    const decryptedData = await this.decryptQrData(encryptedData).catch(error => {
        console.error('Decryption failed:', error);
        throw error; // Re-throw the error without proceeding further
    });
    
    // Step 2: Validate QR - if this fails, throw immediately
    const isValid = await this.validateQrData(decryptedData.eventId, decryptedData.timestamp).catch(error => {
        console.error('Validation failed:', error);
        throw error; // Re-throw the error without proceeding further
    });
    
    if (!isValid) {
        throw new Error('QR validation failed');
    }

    // Step 3: Mark attendance - if this fails, throw the error
    return await this.markAttendance(decryptedData.eventId, userId, deviceFingerprint).catch(error => {
        console.error('Failed to mark attendance:', error);
        throw error;
    });
}
  /**
   * Decrypts QR data and returns { eventId, timestamp }.
   */
  private async decryptQrData(encryptedData: string): Promise<DecryptedQrResponse> {
    const encodedData = encodeURIComponent(encryptedData);
    console.log('Decrypting QR:', encodedData);

    try {
      const response = await this.http.get<any>(
        `${this.decryptApi}?encryptedData=${encodedData}`
      ).toPromise();

      console.log('Decryption API response:', response);

      if (response.error) {
        throw new Error(response.details || response.error);
      }
      if (!response.eventId || !response.timestamp) {
        throw new Error('Invalid decrypted QR format');
      }

      return {
        eventId: response.eventId,
        timestamp: response.timestamp.toString()
      };
    } catch (error) {
      console.error('Decryption failed:', error);
      throw error;
    }
  }

  /**
   * Validates if the decrypted QR is still valid.
   */
  private async validateQrData(eventId: string, timestamp: string): Promise<boolean> {
    const timestampNumber = parseInt(timestamp, 10);
    if (isNaN(timestampNumber)) {
      throw new Error('Invalid timestamp format');
    }

    try {
      const response = await this.http.post<QrValidationResponseDto>(
        this.validateApi, 
        { 
          eventId: parseInt(eventId, 10), 
          timestamp: timestampNumber 
        }
      ).toPromise();

      console.log('Validation response:', response);
      return response?.isValid ?? false;
    } catch (error) {
      console.error('Validation failed:', error);
      throw error;
    }
  }

  /**
   * Marks attendance for the user.
   */
  private async markAttendance(eventId: string, userId: string, deviceFingerprint: string): Promise<{success: boolean, message: string}> {
    try {
      console.log('Marking attendance for event:', eventId, 'and user:', userId,'fingerprint:',deviceFingerprint);
      const response = await this.http.post<{success: boolean, message: string}>(
        this.apiUrl, 
        {eventId, employeeId: userId, fingerprint : deviceFingerprint}
      ).toPromise();

      console.log('Attendance marked successfully');
      if (!response) {
        throw new Error('Attendance API returned no response');
      }
      return response;
    } catch (error) {
      console.error('Failed to mark attendance:', error);
      throw error;
    }
  }
}