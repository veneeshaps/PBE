import { Component, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ZXingScannerModule } from '@zxing/ngx-scanner';
import { BarcodeFormat } from '@zxing/library';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AttendanceService } from '../../services/attendance.service';
import { AuthService } from '../../../../shared/services/auth.service'
import { MatDialog } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { FingerprintService } from '../../../../core/services/fingerprint.service';
@Component({
  selector: 'app-qr-scanner',
  standalone: true,
  imports: [
    CommonModule,
    ZXingScannerModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    MatSnackBarModule,
  ],
  templateUrl: './qr-scanner.component.html',
  styleUrls: ['./qr-scanner.component.css']
})
export class QrScannerComponent implements OnDestroy {
  @ViewChild('scanner', { static: true }) scanner: any;

  // Scanner configuration
  scannerEnabled = true;
  formats: BarcodeFormat[] = [BarcodeFormat.QR_CODE];
  tryHarder = true;
  torchEnabled = false;
  
  // Device management
  availableDevices: MediaDeviceInfo[] = [];
  currentDevice: MediaDeviceInfo | undefined;
  hasMultipleDevices = false;

  // Scanner states
  isProcessing = false;
  error: string | null = null;

  constructor(
    private router: Router,
    private attendanceService: AttendanceService,
    private authService: AuthService,
    private snackBar: MatSnackBar,
    private changeDetector: ChangeDetectorRef,
    private dialog: MatDialog,
    private fingerprintService: FingerprintService
  ) {}

  ngAfterViewInit() {
    setTimeout(() => {
      this.scannerEnabled = true;
      this.changeDetector.detectChanges();
    }, 500);
  }

  async handleScanSuccess(encryptedData: string): Promise<void> {
    if (this.isProcessing) {
      console.log('Already processing - ignoring scan');
      return;
    }

    this.isProcessing = true;
    this.error = null;
    this.scannerEnabled = false; // Disable scanner while processing
    try {
      const userId = await this.authService.getCurrentUserId().toPromise();
      if (userId === undefined || userId === null) {
        throw new Error('User ID is undefined. Unable to process attendance.');
      }
      
      // Get device fingerprint
      const fingerprint = await this.fingerprintService.getFingerprint();
      
      // Process QR and mark attendance
      const response = await this.attendanceService.processQrAndMarkAttendance(
        encryptedData, 
        userId.toString(), 
        fingerprint
      );
      
      // Show success dialog
      this.showDialog('Success', response.message, 'OK', false)
        .afterClosed()
        .subscribe(() => this.router.navigate(['../attendance']));
        
    } catch (error) {
      console.error('Scan processing error:', error);
      
      // Extract the most specific error message available
      const errorMessage = this.getErrorMessage(error);
      
      // Show error dialog with retry option
      this.showDialog('Error', errorMessage, 'Try Again', true)
        .afterClosed()
        .subscribe(result => result ? this.retryScan() : this.goBack());
    } finally {
      this.isProcessing = false;
    }
}

// Helper method to extract error message
private getErrorMessage(error: any): string {
  // Check for API error response structure
  if (error?.error?.message) {
    return error.error.message;
  }
  if (error?.error) {
    return typeof error.error === 'string' ? error.error : JSON.stringify(error.error);
  }
  if (error?.message) {
    return error.message;
  }
  return 'An unknown error occurred while processing the QR code';
}

// Helper method to show dialog
private showDialog(
  title: string,
  message: string,
  confirmText: string,
  showCancel: boolean
) {
  return this.dialog.open(ConfirmationDialogComponent, {
    data: {
      title,
      message,
      confirmText,
      showCancel
    }
  });
}
  retryScan(): void {
    this.error = null;
    this.scannerEnabled = true;
  }

  resetScanningState(): void {
    this.scannerEnabled = false;
    this.error = null;
  }


  goBack(): void {
    this.router.navigate(['../mark-attendance'], { relativeTo: this.router.routerState.root });
  }

  ngOnDestroy(): void {
    this.scannerEnabled = false;
  }

  // Camera handling methods
  handleCamerasFound(devices: MediaDeviceInfo[]): void {
    this.availableDevices = devices;
    this.hasMultipleDevices = devices?.length > 1;
    this.currentDevice = devices?.length ? devices[0] : undefined;
    
    if (!devices?.length) {
      this.error = 'No cameras found. Please check permissions.';
    }
    
    const rearCamera = devices.find(device => 
      device.label.toLowerCase().includes('back') || 
      device.label.toLowerCase().includes('rear')
    );
    if (rearCamera) {
      this.currentDevice = rearCamera;
    }
  }

  handleScanError(error: any): void {
    console.error('Scanner error:', error);
    if (error.name === 'NotFoundError' || error.name === 'NotAllowedError') {
      this.error = 'Camera access denied. Please enable camera permissions.';
    } else {
      this.error = 'Scanning error occurred. Try moving the QR code closer or into better light.';
    }
  }
}