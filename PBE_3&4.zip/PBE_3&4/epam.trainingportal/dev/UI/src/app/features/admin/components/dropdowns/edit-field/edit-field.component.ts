// edit-field.component.ts
import {
	Component,
	Input,
	Output,
	EventEmitter,
	HostListener,
	inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { EmployeeService } from '../../../services/admin.service';

interface DropdownOption {
	label: string;
	value: string;
}

@Component({
	selector: 'app-edit-field',
	standalone: true,
	imports: [CommonModule, HttpClientModule],
	templateUrl: './edit-field.component.html',
	styleUrls: ['./edit-field.component.css'],
})
export class EditFieldComponent {
	private employeeService = inject(EmployeeService);

	@Input() fieldType: 'Role' | 'Domain' | 'Status' = 'Role';
	@Input() employeeId!: number;
	@Input() email!: string;
	@Input() currentValue!: string;
	@Input() isActive = false;
	@Input() masterData: any;

	@Output() onUpdate = new EventEmitter<{
		employeeId: number;
		email: string;
		fieldToUpdate: string;
		newValue: string;
	}>();
	@Output() onToggle = new EventEmitter<{
		employeeId: number;
		fieldType: string;
		isOpen: boolean;
	}>();

	selectedValue: string = '';

	@HostListener('document:click', ['$event'])
	onClick(event: MouseEvent) {
		const target = event.target as HTMLElement;
		if (!target.closest('.dropdown-container') && this.isActive) {
			this.toggleDropdown(event, false);
		}
	}

	get filteredOptions(): DropdownOption[] {
		const allOptions = this.getOptions();
		return allOptions.filter(
			(option) => option.label !== this.currentValue
		);
	}

	private getOptions(): DropdownOption[] {
		switch (this.fieldType) {
			case 'Role':
				return (
					this.masterData?.roles?.map((role: any) => ({
						label: role.name,
						value: role.roleId.toString(),
					})) || []
				);
			case 'Domain':
				return (
					this.masterData?.domains?.map((domain: any) => ({
						label: domain.name,
						value: domain.domainId.toString(),
					})) || []
				);
			case 'Status':
				return (
					this.masterData?.statuses?.map((status: any) => ({
						label: status.name,
						value: status.id.toString(),
					})) || []
				);
			default:
				return [];
		}
	}

	toggleDropdown(event: MouseEvent, isOpen?: boolean) {
		event.stopPropagation();
		const shouldOpen = isOpen !== undefined ? isOpen : !this.isActive;
		this.onToggle.emit({
			employeeId: this.employeeId,
			fieldType: this.fieldType,
			isOpen: shouldOpen,
		});
	}

	selectOption(value: string, label: string, event: MouseEvent) {
		event.stopPropagation();
		this.selectedValue = value;
		this.currentValue = label;
		this.toggleDropdown(event, false);

		const payload = {
			EmployeeId: this.employeeId,
			Email: this.email,
			FieldToUpdate: this.fieldType,
			NewValue: value,
		};

		this.employeeService.updateEmployeeField(payload).subscribe({
			next: (response) => {
				alert(response.message);
				this.onUpdate.emit({
					employeeId: this.employeeId,
					email: this.email,
					fieldToUpdate: this.fieldType.toLowerCase(),
					newValue: value,
				});
			},
			error: (error) => {
				alert(error.error.message || 'Failed to update field');
				this.currentValue =
					this.getOptions().find(
						(opt) => opt.value === this.selectedValue
					)?.label || this.currentValue;
			},
		});
	}
}
