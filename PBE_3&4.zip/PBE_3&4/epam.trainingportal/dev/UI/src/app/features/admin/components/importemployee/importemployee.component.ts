import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

import * as EmployeeActions from '../../store/employee.actions';
import * as fromEmployee from '../../store/employee.selectors';

import { BusinessDomain } from '../../../../core/models/businessdomain.model';
import { Employee } from '../../../../core/models/employee.model';
import { Role } from '../../../../core/models/role.model';
import { EmployeeService } from '../../services/employee.service';
import { EmployeeExportService } from '../../services/employeeExport.service';
import { EmployeeService as EmpService } from '../../services/admin.service';

interface ImportError {
  row: number;
  field: string;
  message: string;
  value?: string;
  safeValue?: SafeHtml;
}

@Component({
  selector: 'app-importemployee',
  templateUrl: './importemployee.component.html',
  styleUrls: ['./importemployee.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class ImportemployeeComponent implements OnInit {
  @ViewChild('fileInput', { static: false }) fileInput!: ElementRef<HTMLInputElement>;

  // Import/Export state
  importStatus: string | null = null;
  importErrors: ImportError[] = [];
  isExporting: boolean = false;
  isImporting: boolean = false;
  showErrorDetails: boolean = false;

  // Form state
  employeeForm: FormGroup;
  showForm: boolean = false;

  // New state for domains and roles
  domains: BusinessDomain[] = [];
  roles: Role[] = [];
  loading$: Observable<boolean>;
  error$: Observable<string | null>;
  success$: Observable<boolean>;

  constructor(
    private fb: FormBuilder,
    private store: Store,
    private employeeService: EmployeeService,
    private exportEmployeeService: EmployeeExportService,
    private sanitizer: DomSanitizer,
    private empservice: EmpService
  ) {
    this.employeeForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      domainId: ['', Validators.required],
      roleId: ['', Validators.required],
      dateOfJoining: ['', Validators.required],
      isDeactivated: [false]
    });

    this.loading$ = this.store.select(fromEmployee.selectLoading);
    this.error$ = this.store.select(fromEmployee.selectError);
    this.success$ = this.store.select(fromEmployee.selectSuccess);
  }

  ngOnInit(): void {
    this.empservice.getMasterData().subscribe({
      next: (response) => {
        if (response.success && response.data) {
          this.domains = response.data.domains;
          this.roles = response.data.roles;
        } else {
          this.importStatus = 'Failed to load master data.';
        }
      },
      error: (err) => {
        console.error('Error fetching master data:', err);
        this.importStatus = 'Failed to load master data due to an error.';
      }
    });
  }

  createSafeEmailDisplay(value: string): SafeHtml {
    if (!value) return '';

    if (value.includes('@')) {
      const parts = value.split('@');
      const username = parts[0] || '';
      const domain = parts.length > 1 ? parts[1] : '';

      const safeHtml = this.sanitizer.bypassSecurityTrustHtml(
        `${username}<span style="color: #718096;">@</span>${domain}`
      );

      return safeHtml;
    }

    return value;
  }

  triggerFileInput(): void {
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.click();
    } else {
      console.error('File input element not found');
      this.importStatus = 'Import failed: System error';
    }
  }

  onFileSelected(event: Event): void {
    this.importStatus = null;
    this.importErrors = [];
    this.showErrorDetails = false;

    const input = event.target as HTMLInputElement;
    if (!input?.files?.length) {
      this.importStatus = 'No file selected';
      return;
    }

    const file = input.files[0];
    this.isImporting = true;

    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    if (fileExtension !== 'xlsx') {
      this.handleImportError({
        message: 'Invalid file format. Only .xlsx files are allowed.',
        errors: ['Please upload an Excel (.xlsx) file']
      });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      this.handleImportError({
        message: 'File size exceeds 5MB limit',
        errors: ['Please upload a smaller file (maximum 5MB)']
      });
      return;
    }

    this.importStatus = 'Importing employees...';
    this.employeeService.importEmployees(file).subscribe({
      next: (response) => {
        console.log('Import success response:', response);
        this.handleImportSuccess(response);
      },
      error: (err) => {
        console.error('Import error in component:', err);
        this.handleImportError(err);
      }
    });
  }

  private handleImportSuccess(response: any): void {
    this.isImporting = false;

    if (response.errors?.length > 0) {
      this.importStatus = 'Import completed with issues';
      this.processImportErrors(response.errors);
    } else {
      this.importStatus = response.message || 'Import completed successfully';
      this.store.dispatch(EmployeeActions.loadEmployees());
    }

    this.resetFileInput();
  }

  private handleImportError(error: any): void {
    this.isImporting = false;

    console.log('Import error details:', error);

    if (error.error && typeof error.error === 'object') {
      if (error.error.errors && Array.isArray(error.error.errors)) {
        this.importStatus = error.error.message || 'Import failed: Validation errors';
        this.processImportErrors(error.error.errors);
        this.resetFileInput();
        return;
      } else if (error.error.message) {
        this.importStatus = error.error.message;
      }
    }

    if (error.errors && Array.isArray(error.errors)) {
      this.importStatus = error.message || 'Import failed with validation issues';
      this.processImportErrors(error.errors);
      this.resetFileInput();
      return;
    }

    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) {
        this.importStatus = 'Import failed: Network error. Please check your connection.';
      } else if (error.status === 400) {
        const errorBody = error.error;

        if (errorBody && typeof errorBody === 'object') {
          if (errorBody.errors && Array.isArray(errorBody.errors)) {
            this.importStatus = errorBody.message || 'Import failed: Validation errors';
            this.processImportErrors(errorBody.errors);
            this.resetFileInput();
            return;
          } else if (errorBody.message) {
            this.importStatus = errorBody.message;
          } else {
            const modelStateErrors = [];
            for (const key in errorBody) {
              if (Array.isArray(errorBody[key])) {
                modelStateErrors.push(...errorBody[key].map((err: string) => `${key}: ${err}`));
              }
            }

            if (modelStateErrors.length > 0) {
              this.importStatus = 'Import failed: Validation errors';
              this.processImportErrors(modelStateErrors);
              this.resetFileInput();
              return;
            }
          }
        }

        if (!this.importStatus || this.importStatus === 'Import failed!') {
          this.importStatus = 'Import failed: Invalid data in file.';
        }
      } else if (error.status === 413) {
        this.importStatus = 'Import failed: File size too large.';
      } else {
        this.importStatus = error.error?.message || error.message || 'Import failed!';
      }
    } else if (error.message) {
      this.importStatus = error.message;
    } else {
      this.importStatus = 'Import failed due to an unknown error';
    }

    this.resetFileInput();
  }

  private processImportErrors(errors: any[]): void {
    this.importErrors = errors.map(error => {
      const errorMessage = typeof error === 'string' ? error :
                          (error.message || error.error || JSON.stringify(error));

      const rowMatch = errorMessage.match(/Row (\d+):/i);
      const row = rowMatch ? parseInt(rowMatch[1]) : 0;

      const fieldMatch = errorMessage.match(/Row \d+: ([^-]+) -/i) ||
                        errorMessage.match(/Field '([^']+)'/i) ||
                        errorMessage.match(/The ([^\s]+) field/i);
      const field = fieldMatch ? fieldMatch[1].trim() : 'General';

      let message = errorMessage;
      if (rowMatch && fieldMatch) {
        const messageMatch = errorMessage.match(/- (.+)$/);
        message = messageMatch ? messageMatch[1] : errorMessage;
      }

      let value = undefined;
      let safeValue = undefined;

      const valueMatch = message.match(/value '([^']+)'/i) ||
                        message.match(/found '([^']+)'/i) ||
                        message.match(/value is '([^']+)'/i);
      if (valueMatch) {
        value = valueMatch[1];
        safeValue = this.createSafeEmailDisplay(value);
      }

      return {
        row,
        field,
        message,
        value,
        safeValue
      };
    });

    this.showErrorDetails = this.importErrors.length > 0;
  }

  private resetFileInput(): void {
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.value = '';
    }
  }

  onExport(): void {
    if (this.isExporting) return;

    this.isExporting = true;
    this.importStatus = 'Exporting employees...';

    this.exportEmployeeService.exportEmployees().subscribe({
      next: (blob: Blob) => this.handleExportSuccess(blob),
      error: (err) => this.handleExportError(err)
    });
  }

  private handleExportSuccess(blob: Blob): void {
    try {
      if (!blob || blob.size === 0) {
        throw new Error('Received empty file');
      }

      const url = window.URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `EmployeeList_${new Date().toLocaleDateString().replace(/\//g, '-')}.xlsx`;
      document.body.appendChild(anchor);
      anchor.click();

      setTimeout(() => {
        document.body.removeChild(anchor);
        window.URL.revokeObjectURL(url);
        this.importStatus = 'Export successful!';
        this.isExporting = false;
      }, 100);
    } catch (error) {
      console.error('Error creating download:', error);
      this.importStatus = 'Failed to download file';
      this.isExporting = false;
    }
  }

  private handleExportError(err: HttpErrorResponse): void {
    this.isExporting = false;
    console.error('Export error details:', err);

    if (err.status === 0 && err.error instanceof ProgressEvent) {
      this.importStatus = 'Export failed: CORS error. Please contact the administrator.';
      console.error('CORS error detected. The backend needs to allow requests from origin:', window.location.origin);
    } else {
      this.importStatus = `Export failed: ${err.message || 'Unknown error'}`;
    }
  }

  toggleForm(): void {
    this.showForm = !this.showForm;
    // Clear all other UI elements when showing the form
    if (this.showForm) {
      this.importStatus = null;
      this.importErrors = [];
      this.showErrorDetails = false;
    } else {
      this.onClear();
    }
  }

  onSubmit(): void {
    if (this.employeeForm.valid) {
      const employee: Employee = {
        ...this.employeeForm.value,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      this.store.dispatch(EmployeeActions.createEmployee({ employee }));
    } else {
      this.markFormGroupTouched(this.employeeForm);
    }
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
    });
  }

  onClear(): void {
    this.employeeForm.reset({
      isDeactivated: false
    });
    this.store.dispatch(EmployeeActions.resetEmployeeForm());
  }
}
