import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, Observable, throwError } from 'rxjs';
import { Domain } from '../models/domain.model';
import { EventType } from '../models/event-type.model';
import { CreateEventPayload, ScheduledEvent, ScheduledEventPayload, ScheduledEventResponse } from '../models/scheduled-event.model';

@Injectable({
  providedIn: 'root'
})
export class AdminEventsService {
  private baseUrl = 'https://localhost:7252/api/ScheduledEvent'

  constructor(private http: HttpClient) { }

  getEventsByAdmin(adminId: number): Observable<ScheduledEvent[]> {
    return this.http.get<ScheduledEvent[]>(`${this.baseUrl}/allByAdmin/${adminId}`);
  }

//   getEventById(id: number): Observable<ScheduledEvent> {
//     return this.http.get<ScheduledEvent>(`${this.baseUrl}/${id}`);
//   }

getEventById(id: number): Observable<ScheduledEventResponse> {
	return this.http.get<ScheduledEventResponse>(`${this.baseUrl}/${id}`);
  }

  createEvent(payload: CreateEventPayload): Observable<any> {
	return this.http.post(`${this.baseUrl}`, payload).pipe(
	  catchError(error => {
		console.error('Create event error:', error);
		// Return the entire error object to access the response body
		return throwError(() => error);
	  })
	);
  }

//   createEvent(payload: ScheduledEventPayload): Observable<ScheduledEventPayload> {
//     return this.http.post<ScheduledEventPayload>(this.baseUrl, payload);
//   }

//   updateEvent(payload: ScheduledEvent): Observable<ScheduledEvent> {
//     return this.http.put<ScheduledEvent>(`${this.baseUrl}/update`, payload);
//   }

updateEvent(payload: ScheduledEventPayload): Observable<any> {
	return this.http.put<any>(`${this.baseUrl}/update`, payload);
  }

  deleteEvent(id: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/${id}`);
  }

  getAllDomains(): Observable<Domain[]> {
    return this.http.get<Domain[]>(`${this.baseUrl}/getAllDomains`);
  }

  getAllEventTypes(): Observable<EventType[]> {
    return this.http.get<EventType[]>(`${this.baseUrl}/getAllEventTypes`);
  }
  exportAllEventsAsExcel(adminId: number): Observable<{ blob: Blob, filename: string }> {
	return this.http.get(`${this.baseUrl}/export/${adminId}`, {
	  observe: 'response',
	  responseType: 'blob',
	  headers: new HttpHeaders({
		'Accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
	  })
	}).pipe(
	  map(response => {
		// Extract filename from content-disposition header
		const contentDisposition = response.headers.get('content-disposition');
		let filename = 'AllEvents.xlsx';

		if (contentDisposition) {
		  const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
		  const matches = filenameRegex.exec(contentDisposition);
		  if (matches != null && matches[1]) {
			filename = matches[1].replace(/['"]/g, '');
		  }
		}

		return {
		  blob: response.body as Blob,
		  filename: filename
		};
	  }),
	  catchError(error => {
		console.error('Export all error:', error);
		return throwError(() => error);
	  })
	);
  }
}
