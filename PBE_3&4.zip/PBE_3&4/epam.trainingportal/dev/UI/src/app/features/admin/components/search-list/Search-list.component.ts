// src/app/features/admin/components/employee-list/employee-list.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchEmployeeComponent } from '../searchemployee/searchemployee.component';
import { EmployeeDto } from '../../../../core/models/employee.model.search';
import { EmployeeService } from '../../../../core/services/employee.service';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule, SearchEmployeeComponent],
  templateUrl: './Search-list.component.html',
  styleUrls: ['./Search-list.component.scss']
})
export class EmployeeListComponent {
  employees: EmployeeDto[] = [];

  constructor(private employeeService: EmployeeService) {}
  onSearch(term: string) {
    if (!term || term.trim() === '') {
      this.employees = [];
      return;
    }

    this.employeeService.searchEmployees(term).subscribe({
      next: (res) => this.employees = res,
      error: () => this.employees = []
    });
  }
}
