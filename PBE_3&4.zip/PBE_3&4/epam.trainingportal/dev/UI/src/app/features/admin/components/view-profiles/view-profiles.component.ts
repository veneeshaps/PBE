import { Component, Inject, inject, OnInit } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { EditFieldComponent } from '../dropdowns/edit-field/edit-field.component';
import { EditFieldsComponent } from '../modals/edit-fields/edit-fields.component';
import { EmployeeService } from '../../services/admin.service';

interface Domain {
	domainId: number;
	name: string;
}

interface Role {
	roleId: number;
	name: string;
}

interface UserProfile {
	employeeId: number;
	name: string;
	email: string;
	domain: Domain;
	role: Role;
	isDeactivated: number;
	selected?: boolean;
}

interface ApiResponse {
	success: boolean;
	statusCode: number;
	message: string;
	data: UserProfile[];
	errors: any;
	timestamp: string;
	metadata: any;
}

interface MasterDataResponse {
	domains: Domain[];
	roles: Role[];
}

interface StatusOption {
	id: number;
	name: string;
}

@Component({
	selector: 'app-view-profiles',
	imports: [
		CommonModule,
		FormsModule,
		HttpClientModule,
		EditFieldComponent,
		EditFieldsComponent,
	],
	templateUrl: './view-profiles.component.html',
	styleUrls: ['./view-profiles.component.css'],
})
export class ViewProfilesComponent implements OnInit {
	private document = inject(DOCUMENT);
	private employeeService = inject(EmployeeService);

	userProfiles: UserProfile[] = [];
	showEditModal = false;
	activeDropdown: { employeeId: number; fieldType: string } | null = null;
	allSelected = false;
	isLoading = true;
	errorMessage = '';
	masterData: {
		domains: Domain[];
		roles: Role[];
		statuses: StatusOption[];
	} = {
		domains: [],
		roles: [],
		statuses: [
			{ id: 0, name: 'Active' },
			{ id: 1, name: 'Inactive' },
		],
	};

	get selectedCount(): number {
		return this.userProfiles.filter((user) => user.selected).length;
	}

	ngOnInit(): void {
		this.fetchEmployees();
		this.fetchMasterData();
	}

	fetchMasterData(): void {
		this.employeeService.getMasterData().subscribe({
			next: (response: any) => {
				if (response.success) {
					this.masterData.domains = response.data.domains || [];
					this.masterData.roles = response.data.roles || [];
					// Now fetch employees after we have master data
					this.fetchEmployees();
				} else {
					console.error(
						'Failed to fetch master data:',
						response.message
					);
					this.loadFallbackMasterData();
					this.fetchEmployees();
				}
			},
			error: (error) => {
				console.error('Error fetching master data:', error);
				this.loadFallbackMasterData();
				this.fetchEmployees();
			},
		});
	}

	private loadFallbackMasterData(): void {
		this.masterData.domains = [
			{ domainId: 6, name: '.NET' },
			{ domainId: 7, name: 'Java' },
			{ domainId: 8, name: 'JavaScript' },
			{ domainId: 9, name: 'Python' },
		];
		this.masterData.roles = [
			{ roleId: 6, name: 'Intern' },
			{ roleId: 7, name: 'Bench' },
			{ roleId: 8, name: 'Interviewer' },
		];
	}

	fetchEmployees(): void {
		this.isLoading = true;
		this.errorMessage = '';

		this.employeeService.getEmployees().subscribe({
			next: (response: ApiResponse) => {
				if (response.success) {
					this.userProfiles = response.data.map((user) => ({
						...user,
						selected: false,
					}));
					this.isLoading = false;
				} else {
					this.errorMessage =
						response.message || 'Failed to fetch employees';
					this.isLoading = false;
				}
			},
			error: (error) => {
				this.errorMessage =
					error.error?.message ||
					'An error occurred while fetching employees';
				this.isLoading = false;
			},
		});
	}

	onDropdownToggle(employeeId: number, fieldType: string, isOpen: boolean) {
		if (isOpen) {
			this.activeDropdown = { employeeId, fieldType };
		} else if (
			this.activeDropdown?.employeeId === employeeId &&
			this.activeDropdown?.fieldType === fieldType
		) {
			this.activeDropdown = null;
		}
	}

	isDropdownActive(employeeId: number, fieldType: string): boolean {
		return (
			!!this.activeDropdown &&
			this.activeDropdown.employeeId === employeeId &&
			this.activeDropdown.fieldType === fieldType
		);
	}

	toggleSelectAll(event: Event) {
		const isChecked = (event.target as HTMLInputElement).checked;
		this.userProfiles.forEach((user) => (user.selected = isChecked));
		this.allSelected = isChecked;
	}

	updateSelectAllState() {
		this.allSelected =
			this.userProfiles.length > 0 &&
			this.userProfiles.every((user) => user.selected);
	}

	openEditModal() {
		this.showEditModal = true;
		this.document.body.style.overflow = 'hidden';
	}

	closeEditModal() {
		this.showEditModal = false;
		this.document.body.style.overflow = '';
	}

	handleEditSubmit(event: { domain: string; role: string; status: string }) {
		const selectedEmployees = this.userProfiles
			.filter((user) => user.selected)
			.map((user) => ({
				EmployeeId: user.employeeId,
				Email: user.email,
			}));

		if (selectedEmployees.length === 0) {
			alert('Please select at least one employee to update');
			return;
		}

		// Validate against master data
		if (event.domain && !this.isValidDomain(event.domain)) {
			alert('Invalid domain selected');
			return;
		}

		if (event.role && !this.isValidRole(event.role)) {
			alert('Invalid role selected');
			return;
		}

		if (event.status && !this.isValidStatus(event.status)) {
			alert('Invalid status selected');
			return;
		}

		const payload: any = {
			Employees: selectedEmployees,
		};

		if (event.domain) payload.Domain = event.domain;
		if (event.role) payload.Role = event.role;
		if (event.status) payload.Status = event.status;

		if (!event.domain && !event.role && !event.status) {
			alert('Please select at least one field to update');
			return;
		}

		this.employeeService.bulkUpdateEmployees(payload).subscribe({
			next: (response) => {
				alert(response.message);
				this.userProfiles.forEach((user) => {
					if (user.selected) {
						if (event.domain) {
							const domainId = parseInt(event.domain);
							const domain = this.masterData.domains.find(
								(d) => d.domainId === domainId
							);
							user.domain = domain || {
								domainId,
								name: 'Unknown Domain',
							};
						}
						if (event.role) {
							const roleId = parseInt(event.role);
							const role = this.masterData.roles.find(
								(r) => r.roleId === roleId
							);
							user.role = role || {
								roleId,
								name: 'Unknown Role',
							};
						}
						if (event.status) {
							user.isDeactivated = parseInt(event.status);
						}
					}
				});
			},
			error: (error) => {
				alert(error.error?.message || 'Failed to update employees');
			},
			complete: () => {
				this.closeEditModal();
				this.userProfiles.forEach((user) => (user.selected = false));
				this.allSelected = false;
			},
		});
	}

	// Add validation methods
	private isValidDomain(domainId: string): boolean {
		return this.masterData.domains.some(
			(d) => d.domainId === parseInt(domainId)
		);
	}

	private isValidRole(roleId: string): boolean {
		return this.masterData.roles.some((r) => r.roleId === parseInt(roleId));
	}

	private isValidStatus(statusId: string): boolean {
		return this.masterData.statuses.some(
			(s) => s.id === parseInt(statusId)
		);
	}
}
