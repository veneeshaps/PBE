// features/admin/store/index.ts
import { ActionReducerMap } from '@ngrx/store';
import { employeeReducer, EmployeeState } from './employee.reducer';

export interface AdminState {
  employee: EmployeeState;
  // Add other admin feature states here if needed
}

// This should be named 'reducers' (plural) to match your import
export const reducers: ActionReducerMap<AdminState> = {
  employee: employeeReducer
};

// Export other store artifacts
export * from './employee.actions';
export * from './employee.effects';
export * from './employee.selectors';
