// admin-board.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-admin-board',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  template: `
    <div class="admin-container">
      <div class="admin-content">
        <router-outlet></router-outlet>
      </div>
    </div>
  `,
  styles: [`
    .admin-container {
      display: flex;
      min-height: 100vh;
    }
    .admin-content {
      flex: 1;
      padding: 20px;
    }
  `]
})
export class AdminBoardComponent {}
