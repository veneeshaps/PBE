// features/admin/store/employee.effects.ts
import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, mergeMap, switchMap } from 'rxjs/operators';
import * as EmployeeActions from './employee.actions';
import { HttpErrorResponse } from '@angular/common/http';
import { FormEmployeeService } from '../services/Formemployee.service';

@Injectable()
export class EmployeeEffects {
  private actions$ = inject(Actions);
  private employeeService = inject(FormEmployeeService);

  // Load Domains
  loadDomains$ = createEffect(() =>
    this.actions$.pipe(
      ofType(EmployeeActions.loadDomains),
      mergeMap(() =>
        this.employeeService.getDomains().pipe(
          map(domains => EmployeeActions.loadDomainsSuccess({ domains })),
          catchError(error => of(EmployeeActions.loadDomainsFailure({ error: error.message })))
        )
      )
    )
  );

  // Load Roles
  loadRoles$ = createEffect(() =>
    this.actions$.pipe(
      ofType(EmployeeActions.loadRoles),
      mergeMap(() =>
        this.employeeService.getRoles().pipe(
          map(roles => EmployeeActions.loadRolesSuccess({ roles })),
          catchError(error => of(EmployeeActions.loadRolesFailure({ error: error.message })))
        )
      )
    )
  );

  // Create Employee
//   createEmployee$ = createEffect(() =>
//     this.actions$.pipe(
//       ofType(EmployeeActions.createEmployee),
//       mergeMap(({ employee }) =>
//         this.employeeService.createEmployee(employee).pipe(
//           map(createdEmployee => EmployeeActions.createEmployeeSuccess({ employee: createdEmployee })),
//           catchError(error => of(EmployeeActions.createEmployeeFailure({ error: error.message })))
//         )
//       )
//     )
//   );
// Modify your createEmployee effect to handle errors properly
createEmployee$ = createEffect(() =>
	this.actions$.pipe(
	  ofType(EmployeeActions.createEmployee),
	  switchMap(({ employee }) =>
		this.employeeService.createEmployee(employee).pipe(
		  map((createdEmployee) =>
			EmployeeActions.createEmployeeSuccess({ employee: createdEmployee })
		  ),
		  catchError((error: HttpErrorResponse) => {
			let errorMessage = 'Failed to add employee. Please enter valid details.';
			if (error.error && error.error.message) {
			  errorMessage = error.error.message;
			}
			return of(EmployeeActions.createEmployeeFailure({ error: errorMessage }));
		  })
		)
	  )
	)
  );
}

