import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { BarcodeFormat } from '@zxing/library';
import { QrScannerComponent } from './qr-scanner.component';
import { ZXingScannerModule } from '@zxing/ngx-scanner';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AttendanceService } from '../../services/attendance.service';
import { AuthService } from '../../../../shared/services/auth.service';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { FingerprintService } from '../../../../core/services/fingerprint.service';
import { of, throwError } from 'rxjs';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { By } from '@angular/platform-browser';

describe('QrScannerComponent', () => {
  let component: QrScannerComponent;
  let fixture: ComponentFixture<QrScannerComponent>;
  let mockRouter: jasmine.SpyObj<Router>;
  let mockAttendanceService: jasmine.SpyObj<AttendanceService>;
  let mockAuthService: jasmine.SpyObj<AuthService>;
  let mockDialog: jasmine.SpyObj<MatDialog>;
  let mockFingerprintService: jasmine.SpyObj<FingerprintService>;

  beforeEach(async () => {
    mockRouter = jasmine.createSpyObj('Router', ['navigate']);
    mockAttendanceService = jasmine.createSpyObj('AttendanceService', ['processQrAndMarkAttendance']);
    mockAuthService = jasmine.createSpyObj('AuthService', ['getCurrentUserId']);
    mockDialog = jasmine.createSpyObj('MatDialog', ['open']);
    mockFingerprintService = jasmine.createSpyObj('FingerprintService', ['getFingerprint']);

    await TestBed.configureTestingModule({
      declarations: [QrScannerComponent],
      imports: [
        ZXingScannerModule,
        MatButtonModule,
        MatIconModule,
        FormsModule,
        MatSnackBarModule,
        MatDialogModule
      ],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: AttendanceService, useValue: mockAttendanceService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: MatDialog, useValue: mockDialog },
        { provide: FingerprintService, useValue: mockFingerprintService }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(QrScannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Initialization', () => {
    it('should initialize scanner properties', () => {
      expect(component.scannerEnabled).toBeFalse();
      expect(component.formats).toEqual([BarcodeFormat.QR_CODE]);
      expect(component.tryHarder).toBeTrue();
      expect(component.torchEnabled).toBeFalse();
    });

    it('should enable scanner after view init', fakeAsync(() => {
      component.ngAfterViewInit();
      tick(500);
      expect(component.scannerEnabled).toBeTrue();
    }));
  });

  describe('Camera Handling', () => {
    it('should handle cameras found', () => {
      const mockDevices = [
        { deviceId: '1', label: 'Front Camera' } as MediaDeviceInfo,
        { deviceId: '2', label: 'Back Camera' } as MediaDeviceInfo
      ];
      
      component.handleCamerasFound(mockDevices);
      
      expect(component.availableDevices).toEqual(mockDevices);
      expect(component.hasMultipleDevices).toBeTrue();
      expect(component.currentDevice).toEqual(mockDevices[0]);
      expect(component.error).toBeNull();
    });

    it('should select rear camera when available', () => {
      const mockDevices = [
        { deviceId: '1', label: 'Front Camera' } as MediaDeviceInfo,
        { deviceId: '2', label: 'Back Camera' } as MediaDeviceInfo,
        { deviceId: '3', label: 'Rear Camera' } as MediaDeviceInfo
      ];
      
      component.handleCamerasFound(mockDevices);
      expect(component.currentDevice).toEqual(mockDevices[2]);
    });

    it('should set error when no cameras found', () => {
      component.handleCamerasFound([]);
      expect(component.error).toBe('No cameras found. Please check permissions.');
    });
  });

  describe('Scan Error Handling', () => {
    it('should handle NotAllowedError', () => {
      const error = { name: 'NotAllowedError' };
      component.handleScanError(error);
      expect(component.error).toBe('Camera access denied. Please enable camera permissions.');
    });

    it('should handle NotFoundError', () => {
      const error = { name: 'NotFoundError' };
      component.handleScanError(error);
      expect(component.error).toBe('Camera access denied. Please enable camera permissions.');
    });

    it('should handle generic scan error', () => {
      const error = { name: 'OtherError' };
      component.handleScanError(error);
      expect(component.error).toBe('Scanning error occurred. Try moving the QR code closer or into better light.');
    });
  });

  describe('Scan Success Handling', () => {
    const mockEncryptedData = 'encrypted-qr-data';
    const mockUserId = 2;
    const mockFingerprint = 'device-fingerprint';
    const mockResponse = { success : true, message: 'Attendance marked successfully' };

    beforeEach(() => {
      mockAuthService.getCurrentUserId.and.returnValue(of(mockUserId));
      mockFingerprintService.getFingerprint.and.returnValue(Promise.resolve(mockFingerprint));
      mockAttendanceService.processQrAndMarkAttendance.and.returnValue(Promise.resolve(mockResponse));
      
      // Mock dialog
      const dialogRefMock = jasmine.createSpyObj('MatDialogRef', ['afterClosed']);
      dialogRefMock.afterClosed.and.returnValue(of(true));
      mockDialog.open.and.returnValue(dialogRefMock);
    });

    it('should not process if already processing', async () => {
      component.isProcessing = true;
      await component.handleScanSuccess(mockEncryptedData);
      expect(mockAuthService.getCurrentUserId).not.toHaveBeenCalled();
    });

    it('should process QR code successfully', fakeAsync(() => {
      component.handleScanSuccess(mockEncryptedData);
      tick();
      
      expect(component.isProcessing).toBeTrue();
      expect(mockAuthService.getCurrentUserId).toHaveBeenCalled();
      expect(mockFingerprintService.getFingerprint).toHaveBeenCalled();
      expect(mockAttendanceService.processQrAndMarkAttendance)
        .toHaveBeenCalledWith(mockEncryptedData, mockUserId.toString(), mockFingerprint);
      
      expect(mockDialog.open).toHaveBeenCalledWith(ConfirmationDialogComponent, {
        data: {
          title: 'Success',
          message: mockResponse.message,
          confirmText: 'OK'
        }
      });
      
      expect(component.isProcessing).toBeFalse();
    }));

    it('should navigate to attendance after dialog close', fakeAsync(() => {
      component.handleScanSuccess(mockEncryptedData);
      tick();
      
      expect(mockRouter.navigate).toHaveBeenCalledWith(['../attendance']);
    }));

    it('should handle error when user ID is undefined', fakeAsync(() => {
      mockAuthService.getCurrentUserId.and.returnValue(of(NaN)); // Simulate undefined user ID
      
      component.handleScanSuccess(mockEncryptedData);
      tick();
      
      expect(component.error).toBe('User ID is undefined. Unable to process attendance.');
      expect(mockDialog.open).toHaveBeenCalledWith(ConfirmationDialogComponent, jasmine.any(Object));
    }));

    it('should handle API errors', fakeAsync(() => {
      const mockError = { message: 'Invalid QR code' };
      mockAttendanceService.processQrAndMarkAttendance.and.returnValue(Promise.reject(mockError));
      
      component.handleScanSuccess(mockEncryptedData);
      tick();
      
      expect(component.error).toBe(mockError.message);
      expect(mockDialog.open).toHaveBeenCalledWith(ConfirmationDialogComponent, {
        data: {
          title: 'Error',
          message: mockError.message,
          confirmText: 'Try Again',
          showCancel: true
        }
      });
    }));

    it('should retry scan when user confirms', fakeAsync(() => {
      const dialogRefMock = jasmine.createSpyObj('MatDialogRef', ['afterClosed']);
      dialogRefMock.afterClosed.and.returnValue(of(true)); // User clicks "Try Again"
      mockDialog.open.and.returnValue(dialogRefMock);
      
      const mockError = { message: 'Error' };
      mockAttendanceService.processQrAndMarkAttendance.and.returnValue(Promise.reject(mockError));
      
      component.handleScanSuccess(mockEncryptedData);
      tick();
      
      expect(component.scannerEnabled).toBeTrue();
      expect(component.error).toBeNull();
    }));

    it('should go back when user cancels', fakeAsync(() => {
      const dialogRefMock = jasmine.createSpyObj('MatDialogRef', ['afterClosed']);
      dialogRefMock.afterClosed.and.returnValue(of(false)); // User clicks cancel
      mockDialog.open.and.returnValue(dialogRefMock);
      
      const mockError = { message: 'Error' };
      mockAttendanceService.processQrAndMarkAttendance.and.returnValue(Promise.reject(mockError));
      
      component.handleScanSuccess(mockEncryptedData);
      tick();
      
      expect(mockRouter.navigate).toHaveBeenCalledWith(['../attendance'], jasmine.any(Object));
    }));
  });

  describe('Utility Methods', () => {
    it('should reset scanning state', () => {
      component.scannerEnabled = true;
      component.error = 'Some error';
      
      component.resetScanningState();
      
      expect(component.scannerEnabled).toBeFalse();
      expect(component.error).toBeNull();
    });

    it('should retry scan', () => {
      component.error = 'Some error';
      component.scannerEnabled = false;
      
      component.retryScan();
      
      expect(component.error).toBeNull();
      expect(component.scannerEnabled).toBeTrue();
    });

    it('should disable scanner on destroy', () => {
      component.scannerEnabled = true;
      component.ngOnDestroy();
      expect(component.scannerEnabled).toBeFalse();
    });
  });
});