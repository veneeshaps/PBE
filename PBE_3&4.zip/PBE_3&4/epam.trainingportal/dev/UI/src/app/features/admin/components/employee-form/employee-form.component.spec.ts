import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeFormComponent } from './employee-form.component';
import { provideMockStore } from '@ngrx/store/testing';

describe('EmployeeFormComponent', () => {
  let component: EmployeeFormComponent;
  let fixture: ComponentFixture<EmployeeFormComponent>;

  beforeEach(async () => {
	await TestBed.configureTestingModule({
	  imports: [EmployeeFormComponent],
	  providers: [provideMockStore({})] // <-- 🔧 Add this line here
	}).compileComponents();

	fixture = TestBed.createComponent(EmployeeFormComponent);
	component = fixture.componentInstance;
	fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
