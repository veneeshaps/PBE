// import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Employee } from '../../../core/models/employee.model';
import { Role } from '../../../core/models/role.model';
import { BusinessDomain } from '../../../core/models/businessdomain.model';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FormEmployeeService {
  private apiUrl = 'https://localhost:7252/api/Employee';

  constructor(private http: HttpClient) {}

  getDomains(): Observable<BusinessDomain[]> {
    return this.http.get<BusinessDomain[]>(`${this.apiUrl}/domains`);
  }

  getRoles(): Observable<Role[]> {
    return this.http.get<Role[]>(`${this.apiUrl}/roles`);
  }

  createEmployee(employee: Employee): Observable<Employee> {
    return this.http.post<Employee>(`${this.apiUrl}/add`, employee);
  }
}
