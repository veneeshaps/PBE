  import { Component, signal } from '@angular/core';
  import { HttpClient } from '@angular/common/http';

  import { FormsModule } from '@angular/forms';
  import { CommonModule } from '@angular/common';



  @Component({
    selector: 'app-qr-code',
    standalone: true,
    imports: [FormsModule, CommonModule],
    templateUrl: './qr-code.component.html',
    styleUrls: ['./qr-code.component.css']
  })
  export class QrCodeComponent {
    generateQRCode() {
      throw new Error('Method not implemented.');
    }
    scheduledEventId: string = '';
    eventIds = signal<string[]>([]);
    qrCode = signal<string | null>(null);
    loading = signal<boolean>(false);
    error = signal<string | null>(null);
    intervalId: any = null;

    constructor(private http: HttpClient) {
      this.fetchEventIds();
    }

    fetchEventIds() {
      this.http.get<{ scheduledEventId: number }[]>('https://localhost:7004/api/qrcode/events')
      .subscribe({
        next: (response) => {
          const ids = response.map(e => e.scheduledEventId.toString());
          this.eventIds.set(ids);
        },
        error: (err) => {
          console.error('Error fetching event IDs:', err);
          this.error.set('Failed to fetch Event IDs.');
        }
      });

    }

    startQRCodeGeneration() {
      if (!this.scheduledEventId.trim()) {
        this.error.set('Please select a valid Event ID.');
        return;
      }

      this.error.set(null);
      this.qrCode.set(null);
      this.fetchQRCode();
      this.clearInterval();

      this.intervalId = setInterval(() => this.fetchQRCode(), 3000);
    }

    stopQRCodeGeneration() {
      this.clearInterval();
      this.qrCode.set(null);
      this.loading.set(false);
      this.error.set(null);
      console.log('QR Code generation stopped.');
    }

    private fetchQRCode() {
      this.loading.set(true);

      this.http
        .get<{ qrCode: string }>(`https://localhost:7004/api/qrcode/generate?eventId=${this.scheduledEventId}`)
        .subscribe({
          next: (response) => {
            this.qrCode.set(`data:image/png;base64,${response.qrCode}`);
            this.loading.set(false);
          },
          error: (err) => {
            console.error('Error fetching QR Code:', err);
            this.error.set('Failed to fetch QR Code. Please try again.');
            this.loading.set(false);
          }
        });
    }

    private clearInterval() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    }
  }
