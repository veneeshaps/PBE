// user-id-input.component.ts
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserService } from '../../../../shared/services/user.service';

@Component({
  selector: 'app-user-id-input',
  imports: [CommonModule, FormsModule],
  templateUrl: './UserDashBoard.component.html',
})
export class UserDashBoardComponent {
  userId: number = 0;

  constructor(private router: Router,
    private userService:UserService) {}

  fetchAttendance() {
    this.userService.setUserId(this.userId)
    this.router.navigate(['/dashboard/AttendanceHistory']);
  }
}
