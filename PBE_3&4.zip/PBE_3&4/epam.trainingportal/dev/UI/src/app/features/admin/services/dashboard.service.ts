import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class DashboardService {
  private readonly apiUrl = 'api/dashboard';

  constructor(private http: HttpClient) {}

  getMetrics(): Observable<{ totalUsers: number; activeEvents: number }> {
    return this.http.get<{ totalUsers: number; activeEvents: number }>(
      `${this.apiUrl}/metrics`
    );
  }
}
