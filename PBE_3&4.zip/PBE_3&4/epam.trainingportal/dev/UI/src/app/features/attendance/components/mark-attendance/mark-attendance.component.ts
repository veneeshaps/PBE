import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Router } from '@angular/router';
@Component({
  selector: 'app-mark-attendance',
  imports: [RouterLink],
  templateUrl: './mark-attendance.component.html',
  styleUrls: ['./mark-attendance.component.css']
})
export class MarkAttendanceComponent {
  constructor(private router: Router) {}
  navigateToQrScanner() {
    this.router.navigate(['markAttendance/qr-scan']);
  }
}
