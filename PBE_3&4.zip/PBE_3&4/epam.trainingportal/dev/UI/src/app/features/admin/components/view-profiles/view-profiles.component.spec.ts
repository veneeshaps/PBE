import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewProfilesComponent } from './view-profiles.component';
import { EmployeeService } from '../../services/admin.service';
import { DOCUMENT } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';

describe('ViewProfilesComponent', () => {
	let component: ViewProfilesComponent;
	let fixture: ComponentFixture<ViewProfilesComponent>;
	let mockEmployeeService: jasmine.SpyObj<EmployeeService>;
	let mockDocument: any;

	beforeEach(async () => {
		mockEmployeeService = jasmine.createSpyObj('EmployeeService', [
			'bulkUpdateEmployees',
		]);

		// Create a proper mock document
		mockDocument = document.implementation.createHTMLDocument();
		mockDocument.body.style.overflow = '';

		await TestBed.configureTestingModule({
			imports: [
				FormsModule,
				ViewProfilesComponent,
				HttpClientTestingModule,
			],
			providers: [
				{ provide: EmployeeService, useValue: mockEmployeeService },
				{ provide: DOCUMENT, useValue: mockDocument },
				provideHttpClient(),
			],
		}).compileComponents();

		fixture = TestBed.createComponent(ViewProfilesComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should initialize with default values', () => {
		expect(component.userProfiles.length).toBe(4);
		expect(component.showEditModal).toBeFalse();
		expect(component.activeDropdown).toBeNull();
		expect(component.allSelected).toBeFalse();
	});

	describe('selectedCount', () => {
		it('should return 0 when no users are selected', () => {
			expect(component.selectedCount).toBe(0);
		});

		it('should return correct count of selected users', () => {
			component.userProfiles[0].selected = true;
			component.userProfiles[1].selected = true;
			expect(component.selectedCount).toBe(2);
		});
	});

	describe('onDropdownToggle', () => {
		it('should set activeDropdown when opening', () => {
			component.onDropdownToggle(10, 'Domain', true);
			expect(component.activeDropdown).toEqual({
				employeeId: 10,
				fieldType: 'Domain',
			});
		});

		it('should clear activeDropdown when closing same dropdown', () => {
			component.activeDropdown = { employeeId: 10, fieldType: 'Domain' };
			component.onDropdownToggle(10, 'Domain', false);
			expect(component.activeDropdown).toBeNull();
		});

		it('should not clear activeDropdown when closing different dropdown', () => {
			component.activeDropdown = { employeeId: 10, fieldType: 'Domain' };
			component.onDropdownToggle(11, 'Domain', false);
			expect(component.activeDropdown).not.toBeNull();
		});
	});

	describe('isDropdownActive', () => {
		it('should return true for active dropdown', () => {
			component.activeDropdown = { employeeId: 10, fieldType: 'Domain' };
			expect(component.isDropdownActive(10, 'Domain')).toBeTrue();
		});

		it('should return false for inactive dropdown', () => {
			component.activeDropdown = { employeeId: 10, fieldType: 'Domain' };
			expect(component.isDropdownActive(11, 'Domain')).toBeFalse();
		});
	});

	describe('toggleSelectAll', () => {
		it('should select all users when checked', () => {
			const event = { target: { checked: true } } as unknown as Event;
			component.toggleSelectAll(event);
			expect(component.allSelected).toBeTrue();
			expect(component.userProfiles.every((u) => u.selected)).toBeTrue();
		});

		it('should deselect all users when unchecked', () => {
			component.userProfiles.forEach((u) => (u.selected = true));
			const event = { target: { checked: false } } as unknown as Event;
			component.toggleSelectAll(event);
			expect(component.allSelected).toBeFalse();
			expect(component.userProfiles.every((u) => !u.selected)).toBeTrue();
		});
	});

	describe('updateSelectAllState', () => {
		it('should set allSelected to true when all users are selected', () => {
			component.userProfiles.forEach((u) => (u.selected = true));
			component.updateSelectAllState();
			expect(component.allSelected).toBeTrue();
		});

		it('should set allSelected to false when not all users are selected', () => {
			component.userProfiles[0].selected = true;
			component.updateSelectAllState();
			expect(component.allSelected).toBeFalse();
		});
	});

	describe('modal operations', () => {
		it('should open modal and set body overflow', () => {
			component.openEditModal();
			expect(component.showEditModal).toBeTrue();
			expect(mockDocument.body.style.overflow).toBe('hidden');
		});

		it('should close modal and reset body overflow', () => {
			component.showEditModal = true;
			mockDocument.body.style.overflow = 'hidden';
			component.closeEditModal();
			expect(component.showEditModal).toBeFalse();
			expect(mockDocument.body.style.overflow).toBe('');
		});
	});

	describe('handleEditSubmit', () => {
		beforeEach(() => {
			component.userProfiles[0].selected = true;
			component.userProfiles[1].selected = true;
			mockEmployeeService.bulkUpdateEmployees.and.returnValue(
				of({
					message: 'Update successful',
				})
			);
			spyOn(component, 'closeEditModal');
		});

		it('should call bulkUpdateEmployees with correct payload', () => {
			const editData = { domain: '7', role: '8', status: '1' };
			component.handleEditSubmit(editData);

			expect(
				mockEmployeeService.bulkUpdateEmployees
			).toHaveBeenCalledWith({
				Employees: [
					{ EmployeeId: 10, Email: 'surajnarayan_darade@epam.com' },
					{ EmployeeId: 11, Email: 'john.doe@epam.com' },
				],
				Domain: '7',
				Role: '8',
				Status: '1',
			});
		});

		it('should update user profiles on success', () => {
			const editData = { domain: '7', role: '8', status: '1' };
			component.handleEditSubmit(editData);

			expect(component.userProfiles[0].domain).toBe('Java');
			expect(component.userProfiles[0].role).toBe('Interviewer');
			expect(component.userProfiles[0].isDeactivated).toBe(1);
			expect(component.userProfiles[1].domain).toBe('Java');
			expect(component.userProfiles[1].role).toBe('Interviewer');
			expect(component.userProfiles[1].isDeactivated).toBe(1);
		});

		it('should clear selections after submit', () => {
			const editData = { domain: '7', role: '8', status: '1' };
			component.handleEditSubmit(editData);

			expect(component.userProfiles[0].selected).toBeFalse();
			expect(component.userProfiles[1].selected).toBeFalse();
			expect(component.allSelected).toBeFalse();
		});

		it('should call closeEditModal after submit', () => {
			const editData = { domain: '7', role: '8', status: '1' };
			component.handleEditSubmit(editData);
			expect(component.closeEditModal).toHaveBeenCalled();
		});
	});

	describe('helper methods', () => {
		describe('getDomainName', () => {
			it('should return correct domain name for ID', () => {
				expect(component['getDomainName']('6')).toBe('.NET');
				expect(component['getDomainName']('7')).toBe('Java');
			});

			it('should return ID if not found', () => {
				expect(component['getDomainName']('99')).toBe('99');
			});
		});

		describe('getRoleName', () => {
			it('should return correct role name for ID', () => {
				expect(component['getRoleName']('6')).toBe('Intern');
				expect(component['getRoleName']('7')).toBe('Bench');
			});

			it('should return ID if not found', () => {
				expect(component['getRoleName']('99')).toBe('99');
			});
		});
	});
});
