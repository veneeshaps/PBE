import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface DropdownOption {
	label: string;
	value: string;
}

@Component({
	selector: 'app-edit-fields',
	standalone: true,
	imports: [CommonModule, FormsModule],
	templateUrl: './edit-fields.component.html',
	styleUrls: ['./edit-fields.component.css'],
})
export class EditFieldsComponent {
	@Input() masterData: any;
	@Output() closeModal = new EventEmitter<void>();
	@Output() submitForm = new EventEmitter<{
		domain: string;
		role: string;
		status: string;
	}>();

	selectedDomain: string = '';
	selectedRole: string = '';
	selectedStatus: string = '';

	getDropdownOptions(fieldType: string): DropdownOption[] {
		switch (fieldType) {
			case 'Role':
				return (
					this.masterData?.roles?.map((role: any) => ({
						label: role.name,
						value: role.roleId.toString(),
					})) || []
				);
			case 'Domain':
				return (
					this.masterData?.domains?.map((domain: any) => ({
						label: domain.name,
						value: domain.domainId.toString(),
					})) || []
				);
			case 'Status':
				return (
					this.masterData?.statuses?.map((status: any) => ({
						label: status.name,
						value: status.id.toString(),
					})) || []
				);
			default:
				return [];
		}
	}

	isAnyFieldSelected(): boolean {
		return (
			!!this.selectedDomain ||
			!!this.selectedRole ||
			!!this.selectedStatus
		);
	}

	onCancel() {
		this.clearForm();
		this.closeModal.emit();
	}

	onConfirm() {
		this.submitForm.emit({
			domain: this.selectedDomain,
			role: this.selectedRole,
			status: this.selectedStatus,
		});
		this.clearForm();
	}

	clearForm() {
		this.selectedDomain = '';
		this.selectedRole = '';
		this.selectedStatus = '';
	}

	onModalClick(event: MouseEvent) {
		// Close modal if clicked outside the content
		const target = event.target as HTMLElement;
		if (target.classList.contains('fixed')) {
			this.onCancel();
		}
	}
}
