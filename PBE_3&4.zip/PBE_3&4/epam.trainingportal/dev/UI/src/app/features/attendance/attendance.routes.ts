import { Routes } from '@angular/router';

export const ATTENDANCE_ROUTES: Routes = [];
