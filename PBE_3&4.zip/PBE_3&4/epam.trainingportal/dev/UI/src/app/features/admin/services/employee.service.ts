import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private apiUrl = 'https://localhost:7252/api/EmployeeImport/upload';

  constructor(private http: HttpClient) {}

  importEmployees(file: File): Observable<{ message: string, errors?: string[] }> {
    // Validate file type before sending
    if (!file.name.endsWith('.xlsx')) {
      return throwError(() => ({
        message: 'Invalid file format. Only .xlsx files are allowed.',
        errors: ['Please upload an Excel (.xlsx) file']
      }));
    }

    const formData = new FormData();
    formData.append('file', file);

    return this.http.post<{ message: string, errors?: string[] }>(this.apiUrl, formData).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error('Import error in service:', error);

        // Log the error response for debugging
        console.log('Error response body:', error.error);

        if (error.status === 400) {
          // Handle validation errors from the server
          const errorResponse = error.error;

          // Format error messages for display
          let errors: string[] = [];
          let errorMessage = 'Import failed: Invalid data';

          if (errorResponse) {
            if (typeof errorResponse === 'string') {
              // If the error is a simple string
              errors = [errorResponse];
              errorMessage = errorResponse;
            } else if (errorResponse.Errors && Array.isArray(errorResponse.Errors)) {
              // If the error has an Errors array (capitalized)
              errors = errorResponse.Errors;
              errorMessage = errorResponse.Message || errorMessage;
            } else if (errorResponse.errors && Array.isArray(errorResponse.errors)) {
              // If the error has an errors array (lowercase)
              errors = errorResponse.errors;
              errorMessage = errorResponse.message || errorMessage;
            } else if (errorResponse.Message) {
              // If the error has just a Message (capitalized)
              errors = [errorResponse.Message];
              errorMessage = errorResponse.Message;
            } else if (errorResponse.message) {
              // If the error has just a message (lowercase)
              errors = [errorResponse.message];
              errorMessage = errorResponse.message;
            } else {
              // Try to extract model state errors
              const modelStateErrors = [];
              for (const key in errorResponse) {
                if (Array.isArray(errorResponse[key])) {
                  modelStateErrors.push(...errorResponse[key].map((err: string) => `${key}: ${err}`));
                }
              }

              if (modelStateErrors.length > 0) {
                errors = modelStateErrors;
              }
            }
          }

          // Enhance error messages with more specific information
          const formattedErrors = errors.map(err => {
            // Handle empty value errors
            if (err.includes('empty') || err.includes('required')) {
              if (!err.includes('Row')) {
                return err; // Already well-formatted
              }
              // Extract field name if possible
              const fieldMatch = err.match(/field '([^']+)'/i);
              const field = fieldMatch ? fieldMatch[1] : 'Unknown field';
              return `Row ${err.match(/Row (\d+)/i)?.[1] || '?'}: ${field} - This field is empty but required`;
            }

            // Handle invalid email errors
            if (err.includes('email') && (err.includes('invalid') || err.includes('format'))) {
              if (!err.includes('Row')) {
                return err; // Already well-formatted
              }
              // Extract the invalid email if possible
              const valueMatch = err.match(/value '([^']+)'/i);
              const value = valueMatch ? valueMatch[1] : '';
              return `Row ${err.match(/Row (\d+)/i)?.[1] || '?'}: Email - Invalid email format '${value}'`;
            }

            // Handle date format errors
            if (err.includes('date') && (err.includes('invalid') || err.includes('format'))) {
              if (!err.includes('Row')) {
                return err; // Already well-formatted
              }
              // Extract the invalid date if possible
              const valueMatch = err.match(/value '([^']+)'/i);
              const value = valueMatch ? valueMatch[1] : '';
              return `Row ${err.match(/Row (\d+)/i)?.[1] || '?'}: Date - Invalid date format '${value}', use YYYY-MM-DD`;
            }

            // Handle reference errors (domain, role)
            if (err.includes('not found') || err.includes('does not exist')) {
              if (!err.includes('Row')) {
                return err; // Already well-formatted
              }
              // Determine if it's domain or role
              const isDomain = err.toLowerCase().includes('domain');
              const isRole = err.toLowerCase().includes('role');
              const field = isDomain ? 'Domain' : isRole ? 'Role' : 'Reference';

              // Extract the invalid value if possible
              const valueMatch = err.match(/value '([^']+)'/i) || err.match(/found '([^']+)'/i);
              const value = valueMatch ? valueMatch[1] : '';

              return `Row ${err.match(/Row (\d+)/i)?.[1] || '?'}: ${field} - '${value}' does not exist in the system`;
            }

            // Handle duplicate errors
            if (err.includes('duplicate') || err.includes('already exists')) {
              if (!err.includes('Row')) {
                return err; // Already well-formatted
              }
              // Extract the field and value if possible
              const fieldMatch = err.match(/field '([^']+)'/i);
              const field = fieldMatch ? fieldMatch[1] : 'Value';

              const valueMatch = err.match(/value '([^']+)'/i);
              const value = valueMatch ? valueMatch[1] : '';

              return `Row ${err.match(/Row (\d+)/i)?.[1] || '?'}: ${field} - Duplicate value '${value}' is not allowed`;
            }

            return err; // Return original error if no specific handling
          });

          return throwError(() => ({
            message: errorMessage,
            errors: formattedErrors.length > 0 ? formattedErrors : ['Invalid data in the uploaded file']
          }));
        }

        // Handle other error types
        if (error.status === 0) {
          return throwError(() => ({
            message: 'Network error. Please check your connection.',
            errors: ['Unable to connect to the server']
          }));
        } else if (error.status === 413) {
          return throwError(() => ({
            message: 'File size too large.',
            errors: ['The uploaded file exceeds the maximum allowed size']
          }));
        } else if (error.status === 401 || error.status === 403) {
          return throwError(() => ({
            message: 'You do not have permission to import employees.',
            errors: ['Authentication or authorization error']
          }));
        } else if (error.status === 500) {
          return throwError(() => ({
            message: 'Server error occurred while processing your file.',
            errors: ['The server encountered an error. Please try again later.']
          }));
        }

        return throwError(() => ({
          message: 'An unexpected error occurred during import.',
          errors: [error.message || 'Unknown error']
        }));
      })
    );
  }
}
