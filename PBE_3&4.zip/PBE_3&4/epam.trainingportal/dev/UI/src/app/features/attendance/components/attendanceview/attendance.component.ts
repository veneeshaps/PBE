import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

interface AttendanceSummary {
  eventName: string;
  totalInvited: number;
  presentCount: number;
  absentCount: number;
}

interface EventData {
  name: string;
  date: string;
  status: string;
}

interface AttendanceResponse {
  event: EventData;
  attendance: AttendanceItem[];
}

interface AttendanceItem {
  employeeId: number;
  firstName: string;
  email: string;
  isPresent: boolean;
}

@Component({
  selector: 'app-attendance',
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule, RouterModule],
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {
  private readonly adminMail = 'sarthakravindra_chaure@epam.com';
  
  // Component state
  eventName: string = '';
  data: AttendanceResponse | null = null;
  summary: AttendanceSummary[] = [];
  loading = false;
  error = '';
  activeTab: 'summary' | 'current' | 'past' = 'summary';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchSummary();
  }

  // Tab management
  selectTab(tab: 'summary' | 'current' | 'past'): void {
    this.activeTab = tab;
    this.data = null;
    this.error = '';

    if (tab === 'summary') {
      this.fetchSummary();
    } else if (tab === 'current') {
      this.fetchCurrentAttendance();
    }
  }

  // Data fetching methods
  fetchSummary(): void {
    this.http
      .get<AttendanceSummary[]>(`https://localhost:7004/api/AdminAttendanceView/summary/${this.adminMail}`)
      .subscribe({
        next: (response) => {
          this.summary = response;
        },
        error: () => {
          console.error('Failed to fetch summary data.');
        }
      });
  }

  fetchAttendance(): void {
    if (!this.eventName.trim()) return;

    this.loading = true;
    this.error = '';
    
    this.http
      .get<AttendanceResponse>(`https://localhost:7004/api/AdminAttendanceView/by-schedule-name/${this.adminMail}/${this.eventName}`)
      .subscribe({
        next: (response) => {
          this.data = response;
          this.loading = false;
        },
        error: (err) => {
          this.error = 'Check Event Name';
          this.loading = false;
          console.error(err);
        }
      });
  }

  fetchCurrentAttendance(): void {
    this.loading = true;
    this.error = '';
    this.data = null;

    this.http
      .get<AttendanceResponse>(`https://localhost:7004/api/AdminAttendanceView/current/${this.adminMail}`)
      .subscribe({
        next: (response) => {
          this.data = response;
          this.loading = false;
        },
        error: () => {
          this.error = 'No running event found.';
          this.loading = false;
        }
      });
  }

  // Helper methods
  getStatusClass(isPresent: boolean): any {
    return {
      'bg-green-100 text-green-700': isPresent,
      'bg-red-100 text-red-700': !isPresent
    };
  }

  getStatusText(isPresent: boolean): string {
    return isPresent ? 'Present' : 'Absent';
  }
}