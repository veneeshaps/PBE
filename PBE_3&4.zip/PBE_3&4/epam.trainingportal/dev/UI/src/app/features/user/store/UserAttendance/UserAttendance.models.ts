export interface AttendanceEvent {
    name: string;
    date: string;
    startTime: string;
    endTime: string;
    isPresent: boolean;
  }

  export interface EventTypeStats {
    eventId: number;
    eventName: string;
    totalEvents: number;
    eventsAttended: number;
    attendancePercentage: number;
  }

  export interface AttendanceRecord {
    name: string;
    date: string; // or Date
    startTime: string;
    endTime: string;
    isPresent: boolean;
  }
  export interface EventOption {
    name: string;
  }
  

  export interface EventTypeStats {
    eventName: string;
    count: number;
  }

  
  export interface AttendanceResponse {
    events: AttendanceRecord[];
    totalCount: number;
    eventsAttended: number;
    attendancePercentage: number;
    eventTypeStats: EventTypeStats[];
  }
  