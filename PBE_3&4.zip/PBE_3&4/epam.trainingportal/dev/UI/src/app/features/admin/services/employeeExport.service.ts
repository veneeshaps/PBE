import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeExportService {
  private apiUrl = 'https://localhost:7252/api/EmployeeExport';

  constructor(private http: HttpClient) {}

  exportEmployees(): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/export`, {
      responseType: 'blob'
    });
  }
}
