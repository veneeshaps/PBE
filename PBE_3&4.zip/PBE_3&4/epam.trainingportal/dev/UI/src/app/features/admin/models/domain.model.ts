export interface Domain {
	domainId: number;
	domainName: string;
  }
