import { Component, OnInit } from '@angular/core';
import { AdminEventsService } from '../../services/admin-events.service';
import { ScheduledEvent } from '../../models/scheduled-event.model';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { LoadingSpinnerComponent } from '../app-loading/app-loading.component';
import { NotificationComponent } from '../notification/notification.component';
import { ConfirmationModalComponent } from "../confirmation-modal/confirmation-modal.component";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-event-list',
  standalone: true,
  imports: [FormsModule,CommonModule, RouterModule, LoadingSpinnerComponent, NotificationComponent, ConfirmationModalComponent],
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css']
})
export class EventListComponent implements OnInit {
  events: ScheduledEvent[] = [];
  filteredEvents: ScheduledEvent[] = [];

  isLoading = false;
  adminId = 2; // This should come from auth service or input

  eventTypeFilter: string = '';
  statusFilter: string = '';
  searchQuery: string = '';

  showNotification = false;
  notificationMessage = '';
  notificationType: 'success' | 'error' | 'info' = 'info';
  showConfirmationModal = false;
  eventToDelete: number | null = null;
  confirmationMessage = 'Are you sure you want to delete this event?';

  get eventTypes(): string[] {
	return [...new Set(this.events.map(event => String(event.eventType)))];
  }

  // Get unique statuses for filter
  get statuses(): string[] {
	return [...new Set(this.events
	  .map(event => event.status)
	  .filter((status): status is string => !!status)
	)];
  }

  constructor(private eventsService: AdminEventsService) {}

  ngOnInit(): void {
    this.loadEvents();
  }

  loadEvents(): void {
    this.isLoading = true;
    this.eventsService.getEventsByAdmin(this.adminId).subscribe({
      next: (data) => {
        this.events = data;
		this.applyFilters();
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading events:', err);
        this.isLoading = false;
      }
    });
  }

  applyFilters(): void {
    this.filteredEvents = this.events.filter(event => {
      // Filter by event type
      const typeMatch = !this.eventTypeFilter ||
                        event.eventType === this.eventTypeFilter;

      // Filter by status
      const statusMatch = !this.statusFilter ||
                         event.status?.toLowerCase() === this.statusFilter.toLowerCase();

      // Filter by search query
      const searchMatch = !this.searchQuery ||
                         event.name.toLowerCase().includes(this.searchQuery.toLowerCase());

      return typeMatch && statusMatch && searchMatch;
    });
  }

  resetFilters(): void {
    this.eventTypeFilter = '';
    this.statusFilter = '';
    this.searchQuery = '';
    this.applyFilters();
  }

//   deleteEvent(id: number): void {
//     if (confirm('Are you sure you want to delete this event?')) {
//       this.isLoading = true;
//       this.eventsService.deleteEvent(id).subscribe({
//         next: () => {
//           this.loadEvents();
//         },
//         error: (err) => {
//           console.error('Error deleting event:', err);
//           this.isLoading = false;
//         }
//       });
//     }
//   }

  exportAllEvents(): void {
	if (this.events.length === 0) {
	  this.showNotificationMessage('No events to export', 'info');
	  return;
	}

	this.isLoading = true;
	this.showNotificationMessage('Preparing export...', 'info');

	this.eventsService.exportAllEventsAsExcel(this.adminId).subscribe({
	  next: ({ blob, filename }) => {
		this.isLoading = false;
		// Create download link
		const url = window.URL.createObjectURL(blob);
		const a = document.createElement('a');
		a.href = url;
		a.download = filename || `AllEvents_${new Date().toISOString().slice(0, 10)}.xlsx`;
		document.body.appendChild(a);
		a.click();

		// Clean up
		window.URL.revokeObjectURL(url);
		document.body.removeChild(a);

		this.showNotificationMessage('Export completed successfully!', 'success');
	  },
	  error: (err) => {
		this.isLoading = false;
		console.error('Failed to export:', err);
		this.showNotificationMessage('Failed to export events. Please try again.', 'error');
	  }
	});
  }

   showNotificationMessage(message: string, type: 'success' | 'error' | 'info'): void {
	this.notificationMessage = message;
	this.notificationType = type;
	this.showNotification = true;

	// Auto-hide after 5 seconds
	setTimeout(() => {
	  this.showNotification = false;
	}, 2000);
  }

  deleteEvent(id: number): void {
    this.eventToDelete = id;
    this.showConfirmationModal = true;
  }


  onDeleteConfirmed(confirmed: boolean): void {
    this.showConfirmationModal = false;

    if (confirmed && this.eventToDelete) {
      this.isLoading = true;
      this.eventsService.deleteEvent(this.eventToDelete).subscribe({
        next: () => {
          this.loadEvents();
          this.showNotificationMessage('Event deleted successfully', 'success');
        },
        error: (err) => {
          console.error('Error deleting event:', err);
          this.isLoading = false;
          this.showNotificationMessage('Failed to delete event', 'error');
        }
      });
    }
    this.eventToDelete = null;
  }

  getStatusColor(status: string | undefined): string {
    switch (status?.toLowerCase()) {
      case 'scheduled':
        return 'bg-blue-100 text-blue-800';
      case 'ongoing':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }
}
