import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, MatIconModule], // Add MatIconModule here
  templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements OnInit {
  totalUsers = 0;
  activeEvents = 0;

  private readonly baseUrl = 'https://localhost:7252/api/Dashboard';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.get<{ totalUsers: number; activeEvents: number }>(`${this.baseUrl}/metrics`)
      .subscribe({
        next: (data) => {
          this.totalUsers = data.totalUsers;
          this.activeEvents = data.activeEvents;
        },
        error: (err) => {
          console.error('Failed to load dashboard metrics:', err);
        }
      });
  }
}