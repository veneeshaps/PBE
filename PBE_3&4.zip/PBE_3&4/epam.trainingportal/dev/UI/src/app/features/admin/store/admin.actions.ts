import { createAction, props } from '@ngrx/store';

import { Employee } from '../../../core/models/employee.model';

export const addEmployee = createAction(
  '[Admin] Add Employee',
  props<{ employee: Employee }>()
);

export const addEmployeeSuccess = createAction(
  '[Admin] Add Employee Success',
  props<{ employee: Employee }>()
);

export const addEmployeeFailure = createAction(
  '[Admin] Add Employee Failure',
  props<{ error: any }>()
);
