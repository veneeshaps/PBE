import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AttendanceState } from './UserAttendance.reducers';

// Root feature selector
export const selectAttendanceState = createFeatureSelector<AttendanceState>('attendance');

export const selectLoading = createSelector(
  selectAttendanceState,
  (state: AttendanceState) => state.loading
);
// Select unfiltered (initial) summary values
export const selectInitialTotalCount = createSelector(
  selectAttendanceState,
  (state) => state.initialTotalCount
);

export const selectInitialEventsAttended = createSelector(
  selectAttendanceState,
  (state) => state.initialEventsAttended
);

export const selectInitialAttendancePercentage = createSelector(
  selectAttendanceState,
  (state) => state.initialAttendancePercentage
);

export const selectInitialEventTypeStats = createSelector(
  selectAttendanceState,
  (state) => state.initialEventTypeStats
);

// Select filtered or unfiltered events to display
export const selectEvents = createSelector(
  selectAttendanceState,
  (state) => state.filtersApplied ? state.filteredEvents : state.allEvents
);

// Optional: expose loading and error states
export const selectAttendanceLoading = createSelector(
  selectAttendanceState,
  (state) => state.loading
);

export const selectAttendanceError = createSelector(
  selectAttendanceState,
  (state) => state.error
);

export const selectEventOptions = createSelector(
  selectAttendanceState,
  (state) => state.eventOptions
);



