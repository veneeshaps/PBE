import { inject, Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { HttpClient } from '@angular/common/http';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { of } from 'rxjs';
import { AttendanceEvent, EventTypeStats,EventOption } from './UserAttendance.models';

import * as AttendanceActions from './UserAttendance.actions'

@Injectable()
export class AttendanceEffects {
  loadAttendance$ = createEffect(() => {
    const actions$ = inject(Actions);
    const http = inject(HttpClient);

    return actions$.pipe(
      ofType(AttendanceActions.loadAttendance),
      mergeMap(action =>
        http.get<{
          events: AttendanceEvent[],
          totalCount: number,
          eventsAttended: number,
          attendancePercentage: number,
          eventTypeStats: EventTypeStats[]
        }>(
          `http://localhost:5138/api/Attendance/${action.userId}`
        ).pipe(
          map(response =>
            AttendanceActions.loadAttendanceSuccess({
              events: response.events,
              totalCount: response.totalCount,
              eventsAttended: response.eventsAttended,
              attendancePercentage: response.attendancePercentage,
              eventTypeStats: response.eventTypeStats
            })
          ),
          catchError(error =>
            of(AttendanceActions.loadAttendanceFailure({ error: error.message }))
          )
        )
      )
    );
  });

  loadFilteredAttendance$ = createEffect(() => {
    const actions$ = inject(Actions);
    const http = inject(HttpClient);

    return actions$.pipe(
      ofType(AttendanceActions.loadFilteredAttendance),
      mergeMap(({ userId, startDate,endDate, eventName, isPresent, sortDirection }) => {
        const params: any = {};
        if (startDate) params.startDate = startDate;
        if (endDate) params.endDate = endDate;
        if (eventName) params.eventName = eventName;
        if (isPresent !== null) params.isPresent = isPresent;
        if (sortDirection) params.sortDirection = sortDirection;

        return http.get<{
          events: AttendanceEvent[]
        }>(
          `https://localhost:7004/api/Attendance/filter/${userId}`,
          { params }
        ).pipe(
          map(response =>
            AttendanceActions.loadFilteredAttendanceSuccess({
              filteredEvents: response.events
            })
          ),
          catchError(error =>
            of(AttendanceActions.loadAttendanceFailure({ error: error.message }))
          )
        );
      })
    );
  });

  loadEventOptions$ = createEffect(() => {
    const actions$ = inject(Actions);
    const http = inject(HttpClient);

    return actions$.pipe(
      ofType(AttendanceActions.loadEventOptions),
      mergeMap(() =>
        http.get<EventOption[]>('https://localhost:7004/api/Attendance/events').pipe(
          map(eventOptions =>
            AttendanceActions.loadEventOptionsSuccess({ eventOptions })
          ),
          catchError(error =>
            of(AttendanceActions.loadEventOptionsFailure({ error: error.message }))
          )
        )
      )
    );
  });


}
