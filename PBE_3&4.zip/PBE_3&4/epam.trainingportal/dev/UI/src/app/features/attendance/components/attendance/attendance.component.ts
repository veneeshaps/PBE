import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface AttendanceSummary {
  eventName: string;
  totalInvited: number;
  presentCount: number;
  absentCount: number;
}
interface EventData {
  name: string;
  date: string;
  status: string;
}

interface AttendanceResponse {
  event: EventData;
  attendance: AttendanceItem[];
}

interface AttendanceItem {
  employeeId: number;
  firstName: string;
  email: string;
  isPresent: boolean;
}3
var AdminMail = 'sarthakravindra_chaure@epam.com';
@Component({
  selector: 'app-attendance',
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule],
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})

export class AttendanceComponent implements OnInit {
  constructor(private http: HttpClient) {}

  eventName: string = '';
  data: AttendanceResponse | null = null;
  summary: AttendanceSummary[] = [];
  loading = false;
  error = '';
  activeTab: 'summary' | 'current' | 'past' = 'summary'; // 🧠 This fixes the error!

  ngOnInit(): void {
    this.fetchSummary(); 
  }
  selectTab(tab: 'summary' | 'current' | 'past') {
    this.activeTab = tab;
    this.data = null;
    this.error = '';

    if (tab === 'summary') {
      this.fetchSummary();
    } else if (tab === 'current') {
      this. fetchCurrentAttendance();
    }}
  fetchSummary() { 
    this.http
      .get<AttendanceSummary[]>(`https://localhost:7004/api/AdminAttendanceView/summary/${AdminMail}`)
      .subscribe({
        next: (response) => {
          this.summary = response;
        },
        error: () => {
          console.error('Failed to fetch summary data.');
        }
      });
  }

  fetchAttendance() {
    if (!this.eventName.trim()) return;

    this.loading = true;
    this.error = '';
    this.http
      .get<AttendanceResponse>(`https://localhost:7004/api/AdminAttendanceView/by-schedule-name/${AdminMail}/${this.eventName}`)
      .subscribe({
        next: (response) => {
          this.data = response;
          this.loading = false;
        },
        error: (err) => {
          this.error = 'Check Event Name';
          this.loading = false;
        }
      });
  }
  //https://localhost:7004/api/AdminAttendanceView/current/2
  fetchCurrentAttendance() {
    this.loading = true;
    this.error = '';
    this.data = null;
  
    this.http
      .get<AttendanceResponse>(`https://localhost:7004/api/AdminAttendanceView/current/${AdminMail}`)
      .subscribe({
        next: (response) => {
          this.data = response;
          this.loading = false;
        },
        error: () => {
          this.error = 'No running event found.';
          this.loading = false;
        }
      });
  }
  
}
