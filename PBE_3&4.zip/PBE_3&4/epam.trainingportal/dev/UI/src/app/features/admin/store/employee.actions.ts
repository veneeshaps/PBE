// features/admin/store/employee.actions.ts
import { createAction, props } from '@ngrx/store';
import { Employee } from '../../../core/models/employee.model';
import { Role } from '../../../core/models/role.model';
import { BusinessDomain } from '../../../core/models/businessdomain.model';


export const loadDomains = createAction('[Employee] Load Domains');
export const loadDomainsSuccess = createAction(
	'[Employee] Load Domains Success',
	props<{ domains: BusinessDomain[] }>()
);
export const loadDomainsFailure = createAction(
  '[Employee] Load Domains Failure',
  props<{ error: string }>()
);

export const loadRoles = createAction('[Employee] Load Roles');
export const loadRolesSuccess = createAction(
  '[Employee] Load Roles Success',
  props<{ roles: Role[] }>()
);
export const loadRolesFailure = createAction(
  '[Employee] Load Roles Failure',
  props<{ error: string }>()
);

export const createEmployee = createAction(
  '[Employee] Create Employee',
  props<{ employee: Employee }>()
);
export const createEmployeeSuccess = createAction(
  '[Employee] Create Employee Success',
  props<{ employee: Employee }>()
);
export const createEmployeeFailure = createAction(
  '[Employee] Create Employee Failure',
  props<{ error: string }>()
);

export const resetEmployeeForm = createAction('[Employee] Reset Form');

export function addEmployee(addEmployee: any): import("rxjs").OperatorFunction<import("@ngrx/store").Action<string>, any> {
	throw new Error('Function not implemented.');
}
export function addEmployeeSuccess(arg0: { employee: Employee; }): any {
	throw new Error('Function not implemented.');
}

export function addEmployeeFailure(arg0: { error: any; }): any {
	throw new Error('Function not implemented.');
}

export const setError = createAction(
	'[Employee] Set Error',
	props<{ error: string }>()
  );

export function loadEmployees(): any {
	throw new Error('Function not implemented.');
}
