import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div *ngIf="show" class="absolute right-full mr-2 top-1/2 transform -translate-y-1/2 z-10">
      <div [class]="getNotificationClasses()"
           class="px-3 py-2 rounded-md shadow-lg flex items-center whitespace-nowrap
                  animate-fade-in">
        <svg *ngIf="type === 'success'" class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
        </svg>
        <svg *ngIf="type === 'error'" class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
        </svg>
        <svg *ngIf="type === 'info'" class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
        </svg>
        <span class="text-sm font-medium">{{ message }}</span>
      </div>
    </div>
  `,
  styles: [`
    @keyframes fadeIn {
      from { opacity: 0; transform: translateX(10px) translateY(-50%); }
      to { opacity: 1; transform: translateX(0) translateY(-50%); }
    }
    .animate-fade-in {
      animation: fadeIn 0.3s ease-out forwards;
    }
  `]
})
export class NotificationComponent {
  @Input() show = false;
  @Input() message = '';
  @Input() type: 'success' | 'error' | 'info' = 'info';

  getNotificationClasses() {
    return {
      'bg-emerald-100 text-emerald-800 border border-emerald-300': this.type === 'success',
      'bg-rose-100 text-rose-800 border border-rose-300': this.type === 'error',
      'bg-sky-100 text-sky-800 border border-sky-300': this.type === 'info'
    };
  }
}
