import { createAction, props } from '@ngrx/store';

import { AttendanceEvent,EventTypeStats,EventOption } from './UserAttendance.models';

export const loadAttendance = createAction(
  '[Attendance] Load Attendance',
  props<{ userId: number }>()
);
export const loadFilteredAttendanceSuccess = createAction(
  '[Attendance] Load Filtered Attendance Success',
  props<{ filteredEvents: AttendanceEvent[] }>()
);

export const loadFilteredAttendance = createAction(
  '[Attendance] Load Filtered Attendance',
  props<{
    userId: number;
    startDate?: string | null;
    endDate?: string | null;
    eventName: string | null;
    isPresent: boolean | null;
    sortDirection?: 'asc' | 'desc';
  }>()
);

export const loadAttendanceSuccess = createAction(
  '[Attendance] Load Attendance Success',
  props<{ 
    events: AttendanceEvent[];
    totalCount: number;
    eventsAttended: number;
    attendancePercentage: number;
    eventTypeStats: EventTypeStats[]; 
  }>()
);

export const loadAttendanceFailure = createAction(
  '[Attendance] Load Attendance Failure',
  props<{ error: string }>()
);
  export const loadFilteredAttendanceFailure = createAction(
    '[Attendance] Load Filtered Attendance Failure',
    props<{ error: string }>()

);

export const loadEventOptions = createAction(
  '[Attendance] Load Event Options'
);

export const loadEventOptionsSuccess = createAction(
  '[Attendance] Load Event Options Success',
  props<{ eventOptions: EventOption[] }>()
);

export const loadEventOptionsFailure = createAction(
  '[Attendance] Load Event Options Failure',
  props<{ error: string }>()
);

