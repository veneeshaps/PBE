import { createReducer, on } from '@ngrx/store';
import * as AttendanceActions from './UserAttendance.actions';
import { AttendanceEvent, EventTypeStats,EventOption} from './UserAttendance.models';

export interface AttendanceState {
  allEvents: AttendanceEvent[];
  filteredEvents: AttendanceEvent[];
  loading: boolean;
  error: string | null;
  totalCount: number;
  eventsAttended: number;
  attendancePercentage: number;
  eventTypeStats: EventTypeStats[];
  filtersApplied: boolean;

  // Permanent summary after initial load
  initialTotalCount: number;
  initialEventsAttended: number;
  initialAttendancePercentage: number;
  initialEventTypeStats: EventTypeStats[];

  eventOptions: EventOption[];


}

export const initialState: AttendanceState = {
  allEvents: [],
  filteredEvents: [],
  loading: false,
  error: null,
  totalCount: 0,
  eventsAttended: 0,
  attendancePercentage: 0,
  eventTypeStats: [],

  filtersApplied: false,
  initialTotalCount: 0,
  initialEventsAttended: 0,
  initialAttendancePercentage: 0,
  initialEventTypeStats: [],
  eventOptions: [],

};

export const attendanceReducer = createReducer(
  initialState,

  on(AttendanceActions.loadAttendance, (state) => ({
    ...state,
    loading: true,
    error: null,
  })),

  on(AttendanceActions.loadFilteredAttendance, (state) => ({
    ...state,
    loading: true,
    error: null,
    filtersApplied: true
  })),

  on(
    AttendanceActions.loadAttendanceSuccess,
    (state, { events, totalCount, eventsAttended, attendancePercentage, eventTypeStats }) => ({
      ...state,
      loading: false,
      allEvents: events,
      filteredEvents: [],
      totalCount,
      eventsAttended,
      attendancePercentage,
      eventTypeStats,
      filtersApplied: false,

      // Store permanent summary
      initialTotalCount: totalCount,
      initialEventsAttended: eventsAttended,
      initialAttendancePercentage: attendancePercentage,
      initialEventTypeStats: eventTypeStats
    })
  ),

  on(
    AttendanceActions.loadFilteredAttendanceSuccess,
    (state, { filteredEvents }) => ({
      ...state,
      loading: false,
      filteredEvents
    })
  ),

  on(AttendanceActions.loadAttendanceFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error,
  })),

  on(AttendanceActions.loadFilteredAttendanceFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error,
  })),

  on(AttendanceActions.loadEventOptions, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  
  on(AttendanceActions.loadEventOptionsSuccess, (state, { eventOptions }) => ({
    ...state,
    loading: false,
    eventOptions
  })),
  
  on(AttendanceActions.loadEventOptionsFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  

);
