import { createReducer, on } from '@ngrx/store';
import * as EmployeeActions from './employee.actions';
import { BusinessDomain } from '../../../core/models/businessdomain.model';
import { Role } from '../../../core/models/role.model';


export interface EmployeeState {
  errorDetails: any;
  message: any;
  loading: boolean;
  error: string | null;
  success: boolean;
  domains: BusinessDomain[];
  roles: Role[];
}

export const initialState: EmployeeState = {
	loading: false,
	error: null,
	success: false,
	domains: [],
	roles: [],
	errorDetails: undefined,
	message: undefined
};

export const employeeReducer = createReducer(
  initialState,

  // ────── Load Domains ──────
  on(EmployeeActions.loadDomains, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  on(EmployeeActions.loadDomainsSuccess, (state, { domains }) => ({
    ...state,
    loading: false,
    domains
  })),
  on(EmployeeActions.loadDomainsFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),

  // ────── Load Roles ──────
  on(EmployeeActions.loadRoles, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  on(EmployeeActions.loadRolesSuccess, (state, { roles }) => ({
    ...state,
    loading: false,
    roles
  })),
  on(EmployeeActions.loadRolesFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),

  // ────── Create Employee ──────
  on(EmployeeActions.createEmployee, (state) => ({
    ...state,
    loading: true,
    success: false,
    error: null
  })),
  on(EmployeeActions.createEmployeeSuccess, (state) => ({
    ...state,
    loading: false,
    success: true
  })),
  on(EmployeeActions.createEmployeeFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error,
    success: false
  })),

  // ────── Reset Form ──────
  on(EmployeeActions.resetEmployeeForm, (state) => ({
    ...state,
    success: false,
    error: null
  }))
);
