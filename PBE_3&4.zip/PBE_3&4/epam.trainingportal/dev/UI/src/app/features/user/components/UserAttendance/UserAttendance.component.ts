import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AttendanceState } from '../../store/UserAttendance/UserAttendance.reducers';
import { AttendanceEvent, EventTypeStats, EventOption } from '../../store/UserAttendance/UserAttendance.models';
import * as AttendanceActions from '../../store/UserAttendance/UserAttendance.actions';
import {
  selectEvents,
  selectInitialTotalCount,
  selectInitialEventsAttended,
  selectInitialAttendancePercentage,
  selectInitialEventTypeStats,
  selectAttendanceState,
  selectEventOptions,
  selectLoading
} from '../../store/UserAttendance/UserAttendance.selectors';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../../../shared/services/user.service';

@Component({
  selector: 'app-attendance',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './UserAttendance.component.html',
  styleUrls: ['./UserAttendance.component.css']
})
export class UserAttendanceComponent implements OnInit {
  events$: Observable<AttendanceEvent[]>;
  totalCount$: Observable<number>;
  eventsAttended$: Observable<number>;
  attendancePercentage$: Observable<number>;
  eventTypeStats$: Observable<EventTypeStats[]>;
  state$: Observable<AttendanceState>;
  eventOptions$: Observable<EventOption[]>;
  loading$: Observable<boolean>;
  userId: number = 0;
  noAttendanceFetched = false;

  // Filter fields
  startDate: string | null = null;
  endDate: string | null = null;
  eventName: string = '';
  selectedEventName: string = '';
  presence: boolean | null = null;
  sortDirection: 'asc' | 'desc' | null = null;
  filtersApplied: boolean = false;

  constructor(private store: Store, private userService: UserService) {
    this.events$ = this.store.select(selectEvents);
    this.totalCount$ = this.store.select(selectInitialTotalCount);
    this.eventsAttended$ = this.store.select(selectInitialEventsAttended);
    this.attendancePercentage$ = this.store.select(selectInitialAttendancePercentage);
    this.eventTypeStats$ = this.store.select(selectInitialEventTypeStats);
    this.state$ = this.store.select(selectAttendanceState);
    this.eventOptions$ = this.store.select(selectEventOptions);
    this.loading$ = this.store.select(selectLoading);
  }

  ngOnInit() {
    this.userId = this.userService.getUserId();
    this.fetchAttendance();
    this.store.dispatch(AttendanceActions.loadEventOptions());
  }

  onEventNameChange(value: string) {
    this.selectedEventName = value;
    this.eventName = value === 'Custom' ? '' : value;
  }

  fetchAttendance() {
    if (this.userId) {
      this.filtersApplied = false;
      this.store.dispatch(AttendanceActions.loadAttendance({ userId: this.userId }));
    }
  }

  fetchFilteredAttendance() {
    if (this.userId) {
      this.filtersApplied = true;
     
      const finalEventName =
        this.selectedEventName === 'Custom' && !this.eventName.trim()
          ? 'Custom'
          : this.eventName.trim() || null;

      this.store.dispatch(
        AttendanceActions.loadFilteredAttendance({
          userId: this.userId,
          startDate: this.startDate,
          endDate: this.endDate,
          eventName: finalEventName,
          isPresent: this.presence !== null ? this.presence : null,
          sortDirection: this.sortDirection || undefined,
        })
      );
    }
  }

  resetFilters() {
    this.startDate = null;
    this.endDate = null;
    this.eventName = '';
    this.selectedEventName = '';
    this.presence = null;
    this.sortDirection = null;
    this.filtersApplied = false;
    this.fetchAttendance();
  }
}
