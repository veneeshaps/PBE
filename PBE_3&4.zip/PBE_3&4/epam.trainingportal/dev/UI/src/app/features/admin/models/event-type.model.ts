export interface EventType {
	eventId: number;
	eventName: string;
  }
