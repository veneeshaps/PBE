import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-searchemployee',
  standalone: true,
  templateUrl: './searchemployee.component.html',
  styleUrls: ['./searchemployee.component.scss'],
})
export class SearchEmployeeComponent {
  @Output() searchTermChanged = new EventEmitter<string>();
//making this searchTermChanged for the parent component
  handleInput(event: Event) {
    const target = event.target as HTMLInputElement;
    this.searchTermChanged.emit(target.value);
  }
}

//The input event is triggered.
//The handleInput method captures the entered text.
//The searchtermchanged event is emitted with the current value of the input field
