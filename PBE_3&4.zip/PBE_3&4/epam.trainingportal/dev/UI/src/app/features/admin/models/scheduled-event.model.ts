// models/scheduled-event.model.ts
export interface ScheduledEvent {
	scheduledEventId?: number;
	name: string;
	date: string | Date;
	startTime: string;
	endTime: string;
	domains: string[];
	createdBy?: string;
	status?: string;
	eventType: string | number;
	createdByEmployeeId?: number;
	domainIds?: number[];

  }

  export interface ScheduledEventResponse {
	scheduledEventId: number;
	name: string;
	date: string;
	startTime: string;
	endTime: string;
	domains: string[];
	createdBy?: string;
	status: string;
	eventType: string;
  }

  export interface ScheduledEventPayload {
	scheduledEventId?: number;
	name: string;
	date: string;
	startTime: string;
	endTime: string;
	domainIds: number[];
	status: string;
	eventId: number;
}

export interface CreateEventPayload {
	name: string;
	date: string;
	startTime: string;
	endTime: string;
	eventId: number;
	createdByEmployeeId: number;
	domainIds: number[];
  }

