import { createFeatureSelector, createSelector } from '@ngrx/store';
import { EmployeeState } from './employee.reducer';

// Feature key should match the one used in provideStore({ employee: employeeReducer })
export const selectEmployeeState = createFeatureSelector<EmployeeState>('employee');

// Selectors for domains and roles
export const selectDomains = createSelector(
  selectEmployeeState,
  (state: EmployeeState) => state.domains
);

export const selectRoles = createSelector(
  selectEmployeeState,
  (state: EmployeeState) => state.roles
);

// Selector for loading state
export const selectLoading = createSelector(
  selectEmployeeState,
  (state: EmployeeState) => state.loading
);

// Selector for error state
export const selectError = createSelector(
  selectEmployeeState,
  (state: EmployeeState) => state.error
);

// Selector for success state
export const selectSuccess = createSelector(
  selectEmployeeState,
  (state: EmployeeState) => state.success
);

// Selector for error details (optional based on your state structure)
export const selectErrorDetails = createSelector(
  selectEmployeeState,
  (state: EmployeeState) => state.errorDetails
);

// Selector for success message (optional based on your state structure)
export const selectMessage = createSelector(
  selectEmployeeState,
  (state: EmployeeState) => state.message
);
