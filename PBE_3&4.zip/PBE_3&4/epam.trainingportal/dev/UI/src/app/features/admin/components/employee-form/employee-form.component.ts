// // import { Component, inject, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
// import { Store } from '@ngrx/store';
// import { Observable } from 'rxjs';
// import { CommonModule } from '@angular/common';

// import * as EmployeeActions from '../../store/employee.actions';
// import * as fromEmployee from '../../store/employee.selectors';

// import { BusinessDomain } from '../../../../core/models/businessdomain.model';
// import { Employee } from '../../../../core/models/employee.model';
// import { Role } from '../../../../core/models/role.model';
// import { Component, OnInit } from '@angular/core';
// import { EmployeeService } from '../../services/employee.service';
// import { createEmployee } from '../../store/employee.actions';

// @Component({
//   selector: 'app-employee-form',
//   standalone: true,
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './employee-form.component.html',
//   styleUrls: ['./employee-form.component.css']
// })
// export class EmployeeFormComponent implements OnInit {
// toggleForm() {
// throw new Error('Method not implemented.');
// }
// employees(): any {
// throw new Error('Method not implemented.');
// }
// onEdit() {
// throw new Error('Method not implemented.');
// }
//   employeeForm: FormGroup;
//   domains$: Observable<BusinessDomain[]>;
//   roles$: Observable<Role[]>;
//   loading$: Observable<boolean>;
//   error$: Observable<string | null>;
//   success$: Observable<boolean>;
// showForm: any;
// selectedEmployee: any;

//   constructor(private fb: FormBuilder, private store: Store) {
//     this.employeeForm = this.fb.group({
//       email: ['', [Validators.required, Validators.email]],
//       employeeId: ['', Validators.required],
//       firstName: ['', Validators.required],
//       lastName: ['', Validators.required],
//       domainId: ['', Validators.required],
//       roleId: ['', Validators.required],
//       dateOfJoining: ['', Validators.required],
//       isDeactivated: [false]
//     });

//     this.domains$ = this.store.select(fromEmployee.selectDomains);
//     this.roles$ = this.store.select(fromEmployee.selectRoles);
//     this.loading$ = this.store.select(fromEmployee.selectLoading);
//     this.error$ = this.store.select(fromEmployee.selectError);
//     this.success$ = this.store.select(fromEmployee.selectSuccess);
//   }

//   ngOnInit(): void {
//     this.store.dispatch(EmployeeActions.loadDomains());
//     this.store.dispatch(EmployeeActions.loadRoles());
//   }

//   onSubmit(): void {
//     if (this.employeeForm.valid) {
//       const employee: Employee = {
//         ...this.employeeForm.value,
//         createdAt: new Date(),
//         updatedAt: new Date()
//       };
//      // this.store.dispatch(EmployeeService.createEmployee({ employee }));
// 	 this.store.dispatch(createEmployee({ employee }));

//     }
//   }

//   onClear(): void {
//     this.employeeForm.reset();
//     this.store.dispatch(EmployeeActions.resetEmployeeForm());
//   }
// }

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';

import * as EmployeeActions from '../../store/employee.actions';
import * as fromEmployee from '../../store/employee.selectors';

import { BusinessDomain } from '../../../../core/models/businessdomain.model';
import { Employee } from '../../../../core/models/employee.model';
import { Role } from '../../../../core/models/role.model';

@Component({
  selector: 'app-employee-form',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent implements OnInit {
  employeeForm: FormGroup;
  showForm: boolean = false;
  domains$: Observable<BusinessDomain[]>;
  roles$: Observable<Role[]>;
  loading$: Observable<boolean>;
  error$: Observable<string | null>;
  success$: Observable<boolean>;

  constructor(private fb: FormBuilder, private store: Store) {
    this.employeeForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      employeeId: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      domainId: ['', Validators.required],
      roleId: ['', Validators.required],
      dateOfJoining: ['', Validators.required],
      isDeactivated: [false]
    });

    this.domains$ = this.store.select(fromEmployee.selectDomains);
    this.roles$ = this.store.select(fromEmployee.selectRoles);
    this.loading$ = this.store.select(fromEmployee.selectLoading);
    this.error$ = this.store.select(fromEmployee.selectError);
    this.success$ = this.store.select(fromEmployee.selectSuccess);
  }

  ngOnInit(): void {
    this.store.dispatch(EmployeeActions.loadDomains());
    this.store.dispatch(EmployeeActions.loadRoles());
  }

  toggleForm(): void {
    this.showForm = !this.showForm;
    if (!this.showForm) {
      this.onClear();
    }
  }

//   onSubmit(): void {
//     if (this.employeeForm.valid) {
//       const employee: Employee = {
//         ...this.employeeForm.value,
//         createdAt: new Date(),
//         updatedAt: new Date()
//       };
//       this.store.dispatch(EmployeeActions.createEmployee({ employee }));
//     }
//   }

onSubmit(): void {
	if (this.employeeForm.valid) {
	  const employee: Employee = {
		...this.employeeForm.value,
		createdAt: new Date(),
		updatedAt: new Date()
	  };
	  this.store.dispatch(EmployeeActions.createEmployee({ employee }));

	  // Subscribe to the error$ observable to handle specific errors
	  this.error$.subscribe(error => {
		if (error) {
		  if (error.includes('400') || error.includes('Http failure')) {
			this.store.dispatch(EmployeeActions.setError({
			  error: 'Failed to add employee. Please enter valid details.'
			}));
		  }
		}
	  });
	}
  }

  onClear(): void {
    this.employeeForm.reset({
      isDeactivated: false
    });
    this.store.dispatch(EmployeeActions.resetEmployeeForm());
  }
}
