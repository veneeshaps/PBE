import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AdminEventsService } from '../../services/admin-events.service';
import { CreateEventPayload } from '../../models/scheduled-event.model';
import { Domain } from '../../models/domain.model';
import { EventType } from '../../models/event-type.model';
import { CommonModule } from '@angular/common';
import { ConfirmationModalComponent } from "../confirmation-modal/confirmation-modal.component";

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, ConfirmationModalComponent],
})
export class CreateEventComponent implements OnInit {
  eventForm: FormGroup;
  domains: Domain[] = [];
  eventTypes: EventType[] = [];
  isLoading = false;
  isSuccess = false;
  message = '';
  minDate = new Date().toISOString().split('T')[0];
  showCancelConfirmation = false;
  constructor(
    private fb: FormBuilder,
    private eventsService: AdminEventsService,
    private router: Router
  ) {
    this.eventForm = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(100)]],
      date: ['', [Validators.required, this.validateDate]],
      startTime: ['09:00', [Validators.required, Validators.pattern(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/)]],
      endTime: ['17:00', [Validators.required, Validators.pattern(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/)]],
      eventType: ['', Validators.required],
      domainIds: [[], [Validators.required, Validators.minLength(1)]]
    });
  }

  ngOnInit(): void {
    this.loadDomainsAndTypes();

    // Setup time validation triggers
    this.eventForm.get('startTime')?.valueChanges.subscribe(() => {
      this.eventForm.get('endTime')?.updateValueAndValidity();
    });

    this.eventForm.get('endTime')?.valueChanges.subscribe(() => {
      this.eventForm.get('startTime')?.updateValueAndValidity();
    });
  }
  private timeValidator(form: FormGroup): ValidationErrors | null {
    const date = form.get('date')?.value;
    const startTime = form.get('startTime')?.value;
    const endTime = form.get('endTime')?.value;

    if (!date || !startTime || !endTime) {
      return null;
    }

    const startDateTime = new Date(`${date}T${startTime}`);
    const endDateTime = new Date(`${date}T${endTime}`);

    if (startDateTime >= endDateTime) {
      return { timeConflict: 'End time must be after start time' };
    }

    return null;
  }

  validateDate(control: AbstractControl): {[key: string]: any} | null {
    const date = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (isNaN(date.getTime())) {
      return { invalidDate: true };
    }

    return date < today ? { pastDate: true } : null;
  }


  loadDomainsAndTypes(): void {
    this.isLoading = true;

    this.eventsService.getAllDomains().subscribe({
      next: (domains) => {
        this.domains = domains;
        this.eventsService.getAllEventTypes().subscribe({
          next: (types) => {
            this.eventTypes = types;
            this.isLoading = false;
          },
          error: (err) => {
            this.showMessage('Failed to load event types', false);
          }
        });
      },
      error: (err) => {
        this.showMessage('Failed to load domains', false);
      }
    });
  }

//   validateDate(control: any): {[key: string]: any} | null {
//     const date = new Date(control.value);
//     return isNaN(date.getTime()) ? { invalidDate: true } : null;
//   }

onSubmit(): void {
    // Mark all fields as touched to show errors
    this.eventForm.markAllAsTouched();

    // Manually validate time again in case the validator didn't trigger
    const timeError = this.timeValidator(this.eventForm);
    if (timeError) {
      this.eventForm.setErrors(timeError);
      return;
    }

    if (this.eventForm.invalid) {
      return;
    }

    this.isLoading = true;
    this.message = '';
    const formValue = this.eventForm.value;

    const payload: CreateEventPayload = {
      name: formValue.name,
      date: new Date(formValue.date).toISOString(),
      startTime: formValue.startTime,
      endTime: formValue.endTime,
      eventId: +formValue.eventType,
      domainIds: formValue.domainIds,
      createdByEmployeeId: 2 // Should come from auth service
    };

    this.eventsService.createEvent(payload).subscribe({
      next: () => {
        this.showMessage('Event created successfully! Redirecting...', true);
        setTimeout(() => this.router.navigate(['/admin/events']), 1500);
      },
      error: (err) => {
        this.isLoading = false;

        // Check if it's a 409 conflict error
        if (err.status === 409) {
          const conflict = err.error.conflicts[0];
          this.showMessage(
            `Scheduling conflict: "${conflict.name}" is already scheduled from ${conflict.startTime.substring(0, 5)} to ${conflict.endTime.substring(0, 5)} on ${conflict.date.substring(0,10)}`,
            false
          );
        } else {
          // Fallback to generic error message
          this.showMessage(err.error?.message || 'Failed to create event. Please try again.', false);
        }
      }
    });
  }


  onDomainChange(domainId: number, isChecked: boolean): void {
    const domainsControl = this.eventForm.get('domainIds');
    let currentDomains = domainsControl?.value as number[] || [];

    if (isChecked) {
      currentDomains = [...currentDomains, domainId];
    } else {
      currentDomains = currentDomains.filter(id => id !== domainId);
    }

    domainsControl?.setValue(currentDomains);
    domainsControl?.markAsTouched();
  }


//   onCancel(): void {
//     if (this.eventForm.dirty) {
//       if (confirm('Are you sure you want to cancel? Any unsaved changes will be lost.')) {
//         this.router.navigate(['/events']);
//       }
//     } else {
//       this.router.navigate(['/events']);
//     }
//   }

onCancel(): void {
    if (this.eventForm.dirty) {
      this.showCancelConfirmation = true;
    } else {
      this.router.navigate(['/events']);
    }
  }

  handleCancelConfirmation(confirmed: boolean): void {
    this.showCancelConfirmation = false;
    if (confirmed) {
      this.router.navigate(['/events']);
    }
  }

  private showMessage(message: string, isSuccess: boolean): void {
    this.isLoading = false;
    this.isSuccess = isSuccess;
    this.message = message;
  }

  // Helper method to check field validity
  isFieldInvalid(field: string): boolean {
    const control = this.eventForm.get(field);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  // Helper method to get field error message
  getFieldError(field: string): string {
    const control = this.eventForm.get(field);
    if (!control || !control.errors) return '';

    if (control.hasError('required')) return 'This field is required';
    if (control.hasError('pattern')) return 'Invalid time format (HH:MM)';
    if (control.hasError('minlength')) return 'Select at least one domain';
    if (control.hasError('invalidDate')) return 'Invalid date format';
    if (control.hasError('pastDate')) return 'Date cannot be in the past';
    if (this.eventForm.hasError('timeConflict') && (field === 'startTime' || field === 'endTime')) {
      return this.eventForm.getError('timeConflict');
    }

    return '';
  }
}
