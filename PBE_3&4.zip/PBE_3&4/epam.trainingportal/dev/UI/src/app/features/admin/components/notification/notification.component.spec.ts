import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NotificationComponent } from './notification.component';
import { CommonModule } from '@angular/common';

describe('NotificationComponent', () => {
  let component: NotificationComponent;
  let fixture: ComponentFixture<NotificationComponent>;
  let element: HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CommonModule],
      declarations: [NotificationComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(NotificationComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not show notification by default', () => {
    expect(element.querySelector('div[class*="absolute"]')).toBeNull();
  });

  it('should show notification when show input is true', () => {
    component.show = true;
    component.message = 'Test message';
    component.type = 'success';
    fixture.detectChanges();

    const notification = element.querySelector('div[class*="absolute"]');
    expect(notification).toBeTruthy();
    expect(notification?.textContent).toContain('Test message');
  });

  describe('Notification Types', () => {
    it('should apply success styling', () => {
      component.show = true;
      component.type = 'success';
      fixture.detectChanges();

      const notificationDiv = element.querySelector('div[class*="absolute"] > div');
      expect(notificationDiv?.classList).toContain('bg-emerald-100');
      expect(notificationDiv?.classList).toContain('text-emerald-800');
      expect(notificationDiv?.classList).toContain('border-emerald-300');
      expect(element.querySelector('svg')).toBeTruthy();
    });

    it('should apply error styling', () => {
      component.show = true;
      component.type = 'error';
      fixture.detectChanges();

      const notificationDiv = element.querySelector('div[class*="absolute"] > div');
      expect(notificationDiv?.classList).toContain('bg-rose-100');
      expect(notificationDiv?.classList).toContain('text-rose-800');
      expect(notificationDiv?.classList).toContain('border-rose-300');
    });

    it('should apply info styling', () => {
      component.show = true;
      component.type = 'info';
      fixture.detectChanges();

      const notificationDiv = element.querySelector('div[class*="absolute"] > div');
      expect(notificationDiv?.classList).toContain('bg-sky-100');
      expect(notificationDiv?.classList).toContain('text-sky-800');
      expect(notificationDiv?.classList).toContain('border-sky-300');
    });
  });

  it('should display the correct icon based on type', () => {
    component.show = true;

    component.type = 'success';
    fixture.detectChanges();
    expect(element.querySelector('svg path[d="M5 13l4 4L19 7"]')).toBeTruthy();

    component.type = 'error';
    fixture.detectChanges();
    expect(element.querySelector('svg path[d="M6 18L18 6M6 6l12 12"]')).toBeTruthy();

    component.type = 'info';
    fixture.detectChanges();
    expect(element.querySelector('svg path[d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"]')).toBeTruthy();
  });

  it('should display the provided message', () => {
    component.show = true;
    component.message = 'Custom test message';
    fixture.detectChanges();

    expect(element.textContent).toContain('Custom test message');
  });

  it('should have animation classes', () => {
    component.show = true;
    fixture.detectChanges();

    const notificationDiv = element.querySelector('div[class*="absolute"] > div');
    expect(notificationDiv?.classList).toContain('animate-fade-in');
  });
});
