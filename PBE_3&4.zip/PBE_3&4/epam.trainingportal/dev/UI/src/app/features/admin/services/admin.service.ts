import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class EmployeeService {
	private apiUrl = 'https://localhost:7252/api/v1/Employees';

	constructor(private http: HttpClient) {}

	updateEmployeeField(payload: {
		EmployeeId: number;
		Email: string;
		FieldToUpdate: string;
		NewValue: string;
	}): Observable<any> {
		return this.http.patch(`${this.apiUrl}/edit`, payload);
	}

	bulkUpdateEmployees(payload: {
		Employees: { EmployeeId: number; Email: string }[];
		Domain?: string;
		Role?: string;
		Status?: string;
	}): Observable<any> {
		return this.http.patch(`${this.apiUrl}/edit-multiple`, payload);
	}

	getEmployees(): Observable<any> {
		return this.http.get(`${this.apiUrl}`);
	}

	getMasterData(): Observable<any> {
		return this.http.get(`${this.apiUrl}/masterdata`);
	}
}
