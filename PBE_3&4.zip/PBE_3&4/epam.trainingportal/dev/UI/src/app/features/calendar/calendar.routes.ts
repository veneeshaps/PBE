import { Routes } from '@angular/router';

export const CALENDAR_ROUTES: Routes = [];
