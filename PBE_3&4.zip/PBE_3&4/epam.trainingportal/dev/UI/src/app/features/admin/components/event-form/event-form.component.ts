import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { AdminEventsService } from '../../services/admin-events.service';
import { Domain } from '../../models/domain.model';
import { EventType } from '../../models/event-type.model';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ScheduledEvent, ScheduledEventPayload, ScheduledEventResponse } from '../../models/scheduled-event.model';
import { LoadingSpinnerComponent } from '../app-loading/app-loading.component';
import { ConfirmationModalComponent } from "../confirmation-modal/confirmation-modal.component";
@Component({
  selector: 'app-event-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, LoadingSpinnerComponent, ConfirmationModalComponent],
  templateUrl: './event-form.component.html',
  styleUrls: ['./event-form.component.css']
})
export class EventFormComponent implements OnInit {
  eventForm: FormGroup;
  domains: Domain[] = [];
  eventTypes: EventType[] = [];
  isEditMode = false;
  eventId?: number;
  isLoading = false;
  minDate = new Date().toISOString().split('T')[0]; // Today's date for min validation
  showCancelConfirmation = false;
  constructor(
    private fb: FormBuilder,
    private eventsService: AdminEventsService,
    private route: ActivatedRoute,
    private router: Router

  ) {
    this.eventForm = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(100)]],
      date: ['', Validators.required],
      startTime: ['', [Validators.required, Validators.pattern(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$/)]],
      endTime: ['', [Validators.required, Validators.pattern(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$/)]],
      eventType: ['', Validators.required],
      domainIds: [[], [Validators.required, Validators.minLength(1)]],
      status: ['Scheduled']
    });
  }

  ngOnInit(): void {
    this.loadDomainsAndTypes();

    this.route.params.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.eventId = +params['id'];
        this.loadEvent(this.eventId);
      }
    });
  }


  createPayload(formValue: any): ScheduledEventPayload {
	// Convert the form date to ISO format
	const isoDate = new Date(formValue.date).toISOString();
	const normalizeTime = (time: string) =>
		time.includes(':') ? time : `${time}:00`;
	return {
	  scheduledEventId: this.eventId,
	  name: formValue.name,
	  date: isoDate,
	  startTime: normalizeTime(formValue.startTime),
	  endTime: normalizeTime(formValue.endTime),
	  domainIds: formValue.domainIds,
	  status: formValue.status,
	  eventId: formValue.eventType
	  // Note: eventType is not included as it's not in the PUT payload schema
	};
  }


  loadDomainsAndTypes(): void {
    this.isLoading = true;

    this.eventsService.getAllDomains().subscribe({
      next: (domains) => {
        this.domains = domains;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading domains:', err);
        this.isLoading = false;
      }
    });

    this.eventsService.getAllEventTypes().subscribe({
      next: (types) => {
        this.eventTypes = types;
      },
      error: (err) => {
        console.error('Error loading event types:', err);
      }
    });
  }

//   loadEvent(id: number): void {
//     this.isLoading = true;
//     this.eventsService.getEventById(id).subscribe({
//       next: (event) => {
//         // Format the date for the input field
//         const eventDate = new Date(event.date);
//         const formattedDate = eventDate.toISOString().split('T')[0];

//         // Convert domain names to IDs
//         const domainIds = this.domains
//           .filter(d => event.domains.includes(d.domainName))
//           .map(d => d.domainId);

//         this.eventForm.patchValue({
//           name: event.name,
//           date: formattedDate,
//           startTime: event.startTime,
//           endTime: event.endTime,
//           eventType: this.eventTypes.find(t => t.eventName === event.eventType)?.eventId,
//           domainIds: domainIds,
//           status: event.status
//         });
//         this.isLoading = false;
//       },
//       error: (err) => {
//         console.error('Error loading event:', err);
//         this.isLoading = false;
//       }
//     });
//   }

loadEvent(id: number): void {
	this.isLoading = true;
	this.eventsService.getEventById(id).subscribe({
	  next: (event) => {
		const formData = this.transformEventToFormData(event);
		this.eventForm.patchValue(formData);
		this.isLoading = false;
		console.log('Form valid:', this.eventForm.valid);
		console.log('Form errors:', this.eventForm.errors);
		console.log('Form value:', this.eventForm.value);
		console.log('Loading state:', this.isLoading);
	  },
	  error: (err) => {
		console.error('Error loading event:', err);
		this.isLoading = false;
	  }
	});
  }
  ngAfterViewInit() {
	this.debugFormValidation();
  }
  debugFormValidation() {
	console.group('Form Validation Debug');
	console.log('Form Valid:', this.eventForm.valid);
	console.log('Form Errors:', this.eventForm.errors);

	Object.keys(this.eventForm.controls).forEach(key => {
	  const control = this.eventForm.get(key);
	  console.group(`Control: ${key}`);
	  console.log('Value:', control?.value);
	  console.log('Valid:', control?.valid);
	  console.log('Errors:', control?.errors);
	  console.log('Touched:', control?.touched);
	  console.groupEnd();
	});

	console.groupEnd();
  }

  onDomainChange(domainId: number, event: Event): void {
	const target = event.target as HTMLInputElement;
	const isChecked = target.checked;
	const domainsControl = this.eventForm.get('domainIds');

	if (!domainsControl) {
	  console.error('Domain IDs form control not found');
	  return;
	}

	const currentDomains: number[] = domainsControl.value || [];
	const updatedDomains = isChecked
	  ? [...currentDomains, domainId]
	  : currentDomains.filter(id => id !== domainId);

	domainsControl.setValue(updatedDomains);
	domainsControl.markAsTouched();
  }

  private timeValidator(form: FormGroup): ValidationErrors | null {
	const date = form.get('date')?.value;
	const startTime = form.get('startTime')?.value;
	const endTime = form.get('endTime')?.value;

	if (!date || !startTime || !endTime) {
	  return null;
	}

	const startDateTime = new Date(`${date}T${startTime}`);
	const endDateTime = new Date(`${date}T${endTime}`);

	if (startDateTime >= endDateTime) {
	  return { timeConflict: 'End time must be after start time' };
	}

	return null;
  }

  onSubmit(): void {
	// Mark all fields as touched to show errors
	this.eventForm.markAllAsTouched();

	// Manually validate time again in case the validator didn't trigger
	const timeError = this.timeValidator(this.eventForm);
	if (timeError) {
	  this.eventForm.setErrors(timeError);
	  return;
	}

	if (this.eventForm.invalid) {
	  return;
	}

	this.isLoading = true;
	const formValue = this.eventForm.value;
	const payload = this.createPayload(formValue);

	if (this.isEditMode) {
	  this.eventsService.updateEvent(payload).subscribe({
		next: () => {
		  this.router.navigate(['/admin/events']);
		},
		error: (err) => {
		  console.error('Error updating event:', err);
		  this.isLoading = false;
		}
	  });
	}
  }

  isFieldInvalid(field: string): boolean {
    const control = this.eventForm.get(field);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  getFieldError(field: string): string {
    const control = this.eventForm.get(field);
    if (!control || !control.errors) return '';

    if (control.hasError('required')) return 'This field is required';
    if (control.hasError('pattern')) return 'Invalid format';
    if (control.hasError('minlength')) return 'Select at least one domain';

    return '';
  }

//   onCancel(): void {
// 	if (this.eventForm.dirty) {
// 	  if (confirm('Are you sure you want to cancel? Any unsaved changes will be lost.')) {
// 		this.router.navigate(['/events']);
// 	  }
// 	} else {
// 	  this.router.navigate(['/events']);
// 	}
//   }
onCancel(): void {
    if (this.eventForm.dirty) {
      this.showCancelConfirmation = true;
    } else {
      this.router.navigate(['/events']);
    }
  }

  handleCancelConfirmation(confirmed: boolean): void {
    this.showCancelConfirmation = false;
    if (confirmed) {
      this.router.navigate(['/events']);
    }
  }

private transformEventToFormData(event: ScheduledEventResponse): any {
	// Convert domain names to IDs
	const domainIds = this.domains
	  .filter(d => event.domains.includes(d.domainName))
	  .map(d => d.domainId);

	// Convert date to format expected by date input (YYYY-MM-DD)
	const date = new Date(event.date);
	const formattedDate = date.toISOString().split('T')[0];

	return {
	  name: event.name,
	  date: formattedDate,
	  startTime: event.startTime,
	  endTime: event.endTime,
	  eventType: this.eventTypes.find(t => t.eventName === event.eventType)?.eventId,
	  domainIds: domainIds,
	  status: event.status
	};
  }

}
