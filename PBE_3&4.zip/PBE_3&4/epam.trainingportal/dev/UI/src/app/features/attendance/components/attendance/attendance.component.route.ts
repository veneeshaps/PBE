import { Route } from '@angular/router';
import { AttendanceComponent } from './attendance.component';

export const ATTENDANCE_ROUTES: Route[] = [
  {
    path: '',
    component: AttendanceComponent,
  }
];